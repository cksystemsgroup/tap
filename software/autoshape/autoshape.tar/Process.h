/*
 *  The TAP Project: Traffic Shaping System Calls
 *  Copyright (c) Harald Roeck (hroeck@cs.uni-salzburg.at), Silviu Craciunas (scraciunas@gmail.com)
 *
 *  University Salzburg, www.uni-salzburg.at
 *  Department of Computer Science, cs.uni-salzburg.at
 *
 *  This project is funded by the Austrian Science Fund project nummer P18913
 *
 *  This program is free software; you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation; either version 2 of the License, or
 *  (at your option) any later version.
 *
 *  This program is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 *
 *  You should have received a copy of the GNU General Public License
 *  along with this program; if not, write to the Free Software
 *  Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 *
 */
#include <stdio.h>
#include <sys/time.h>
#include <sys/resource.h>
#include <sys/param.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <unistd.h>
#include <signal.h>
#include <string.h>
#include <stdbool.h>
#include <pwd.h>
#include <unistd.h>
#include <time.h>


#define NUM_RESOURCES 4
#define MAX_PROCESSES 500
#define MAX_NAME 255
#define P_COMM_LEN 300
#define MIN_RATE 20



struct ShapingTable_ {
    int rate_read;
    int limit_read;
    int count_read;
    int rate_write;
    int limit_write;
    int count_write;
	long consumed_tokens;
	long bucket_consumed_tokens;
	long consumed_tokens_cache;
	long bucket_consumed_tokens_cache;
};

struct Process_Table_{
	int pid;
	char* user;
	char home_dir[MAX_NAME+1];
	int shaping;
	int smode;
	long consume_rate[NUM_RESOURCES];
	long bucket_consume_rate[NUM_RESOURCES];
	long consume_rate_cache;
	long bucket_consume_rate_cache;
	struct ShapingTable_ stable[NUM_RESOURCES];
	int resource;
}Process_Table;

struct Process_List_
{
	int count;
	struct Process_Table_* processes[MAX_PROCESSES];
}Process_List;

static int Process_readShapingInt( const char* dirname, const char* filename, int* dest);
static int Process_readShapingLong( const char* dirname, const char* filename, long* dest);
static int Process_readShapingTable( const char* dirname, const char* filename, struct ShapingTable_ *table, bool read_consumed);
static int Process_writeShapingInt( const char* dirname, const char* filename, int value );
static int Process_writeShapingTable(  const char *dirname, const char* filename, struct ShapingTable_ *table, int fuzzy_b_value );
void Process_readShaping( struct Process_Table_ *pt, char* dirname );
void Process_writeShaping( struct Process_Table_ *pt, char* dirname, int fuzzy_b_value, int resource );
void Process_loadList(struct Process_List_* pl, char* dirname, int master);
void Process_findResource(struct Process_Table_ *this );
