/*
 *  The TAP Project: Traffic Shaping System Calls
 *  Copyright (c) Harald Roeck (hroeck@cs.uni-salzburg.at), Silviu Craciunas (scraciunas@gmail.com)
 *
 *  University Salzburg, www.uni-salzburg.at
 *  Department of Computer Science, cs.uni-salzburg.at
 *
 *  This project is funded by the Austrian Science Fund project nummer P18913
 *
 *  This program is free software; you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation; either version 2 of the License, or
 *  (at your option) any later version.
 *
 *  This program is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 *
 *  You should have received a copy of the GNU General Public License
 *  along with this program; if not, write to the Free Software
 *  Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 *
 */
#include <stdio.h>
#include <sys/time.h>
#include <sys/resource.h>
#include <sys/param.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <unistd.h>
#include <signal.h>
#include <string.h>
#include <stdbool.h>
#include <pwd.h>
#include <unistd.h>
#include <time.h>
#include <sys/types.h>
#include <dirent.h>
#include "Process.h"
#include <stdlib.h>


static int Process_readShapingInt( const char* dirname, const char* filename, int* dest) {
	FILE *file;
	char name[MAX_NAME+1];
	int retval = -1;
	snprintf( name, MAX_NAME, "%s/%s", dirname, filename);
	
	file = fopen( name, "r" );
	if( file != NULL )
	{
		fscanf( file, "%d", dest );
		fclose( file );
		retval = 0;
	}
	return retval;
}

static int Process_readShapingLong( const char* dirname, const char* filename, long* dest) {
	FILE *file;
	char name[MAX_NAME+1];
	int retval = -1;
	snprintf( name, MAX_NAME, "%s/%s", dirname, filename);
	file = fopen( name, "r" );
	if( file != NULL )
	{
		fscanf( file, "%ld", dest );
		fclose( file );
		retval = 0;
	}
	return retval;
}


static int Process_readShapingTable( const char* dirname, const char* filename, struct ShapingTable_ *table, bool read_consumed) {
	char name[MAX_NAME + 1];

	snprintf( name, MAX_NAME, "%s/%s", dirname, filename );
	Process_readShapingInt( name, "rate_read", &table->rate_read );
	Process_readShapingInt( name, "limit_read", &table->limit_read );
	Process_readShapingInt( name, "count_read", &table->count_read );
	Process_readShapingInt( name, "rate_write", &table->rate_write );
	Process_readShapingInt( name, "limit_write", &table->limit_write );
	Process_readShapingInt( name, "count_write", &table->count_write );
	if(read_consumed) 
	{
		Process_readShapingLong( name, "bucket_consumed_tokens", &table->bucket_consumed_tokens);
		Process_readShapingLong( name, "consumed_tokens", &table->consumed_tokens);
		Process_readShapingLong( name, "bucket_consumed_tokens_cache", &table->bucket_consumed_tokens_cache);
		Process_readShapingLong( name, "consumed_tokens_cache", &table->consumed_tokens_cache);
	}
	return 0;
}

void Process_readShaping( struct Process_Table_ *pt, char* dirname ) {
	DIR* dir;
	pt->smode = -1;
	pt->shaping = 0;
	time_t now;
	double diff_time;

	struct ShapingTable_ oldTable;

	dir = opendir(dirname);
	if( dir )
	{
		if( readdir( dir ) != NULL ) 
		{
			char table_dir[16 + 1];
			int i;
			pt->shaping = 1;
			Process_readShapingInt( dirname, "mode", &pt->smode );
			for(i=0; i< NUM_RESOURCES; ++i )
			{
				snprintf( table_dir, 16, "table/%d", i);
				Process_readShapingTable( dirname, table_dir, &pt->stable[i], false );
			}
		}
		else
		{
			pt->shaping = 0;
			pt->smode = -1;
		}
		closedir( dir );
	}
}

static int Process_writeShapingInt( const char* dirname, const char* filename, int value ) {
	FILE *file;
	char name[MAX_NAME+1];
	int retval = -1;
	snprintf( name, MAX_NAME, "%s/%s", dirname, filename);
	
	file = fopen( name, "w" );
	if( file != NULL )
	{
		fprintf( file, "%d", value );
		fclose( file );
		retval = 0;
	}
	return retval;
}

static int Process_writeShapingTable(  const char *dirname, const char* filename, struct ShapingTable_ *table, int fuzzy_b_value ) {
	char name[MAX_NAME + 1];

	snprintf( name, MAX_NAME, "%s/%s", dirname, filename );
	table->rate_read = table->rate_read - fuzzy_b_value;
	if(table->rate_read < MIN_RATE)
		table->rate_read = MIN_RATE;
	table->limit_read = table->limit_read - fuzzy_b_value;
	table->rate_write = table->rate_write - fuzzy_b_value;
	if(table->rate_write < MIN_RATE)
		table->rate_write = MIN_RATE;
	table->limit_write = table->limit_write - fuzzy_b_value;

	Process_writeShapingInt( name, "rate_read", table->rate_read);
	Process_writeShapingInt( name, "limit_read", table->limit_read);
	//Process_writeShapingInt( name, "count_read", table->count_read);
	Process_writeShapingInt( name, "rate_write", table->rate_write);
	Process_writeShapingInt( name, "limit_write", table->limit_write);
	//Process_writeShapingInt( name, "count_write", table->count_write);
	return 0;
}

void Process_writeShaping( struct Process_Table_ *this, char* dirname, int fuzzy_b_value, int resource ) {
	DIR* dir;

	dir = opendir(dirname);
	if( dir )
	{
		if( readdir( dir ) != NULL ) 
		{
			char table_dir[16 + 1];
			int i;
			Process_writeShapingInt( dirname, "mode", this->smode );

			for(i=0; i< NUM_RESOURCES; ++i )
			{
				snprintf( table_dir, 16, "table/%d", i);
				if(i == resource)
					Process_writeShapingTable( dirname, table_dir, &this->stable[i], fuzzy_b_value );
				else
					Process_writeShapingTable( dirname, table_dir, &this->stable[i], 0 );
			}
		}
		closedir( dir );
	}
}

void Process_loadList(struct Process_List_* pl, char* dirname, int master){
	DIR* dir;
	DIR* dir2;
	struct dirent* dentry;
	int i;
	char* name;
	int pid;
	char subdirname[MAX_NAME+1];
	char statusfilename[MAX_NAME+1];
	char command[P_COMM_LEN + 1];
	
	
	dir = opendir(dirname);
	if (dir)
	{
		while ((dentry = readdir(dir)) != NULL) 
		{
			name = dentry->d_name;
			
			pid = atoi(name);
			if (pid > 0 && pid != master) 
			{
				snprintf(subdirname, MAX_NAME, "%s/%s/task", dirname, name);
				if (access(subdirname, X_OK) == 0) 
				{
					Process_loadList(pl, subdirname, master);
				}
				snprintf(statusfilename, MAX_NAME,  "%s/%s/shaping", dirname, name);
				dir2 = opendir(statusfilename);
				
				if( !dir2 )
				{
					return;
				}
				
				if( readdir( dir2 ) != NULL ) 
				{
					bool ilist = false;
					closedir(dir2);
					for( i=0 ; i < pl->count ; i++) 
					{
						if(pl->processes[i]->pid == pid) 
						{
							ilist = true;
							Process_readShaping( pl->processes[i],  statusfilename );
						}
					}
					if(!ilist)
					{
						pl->processes[pl->count] = malloc(sizeof(Process_Table));
						pl->processes[pl->count]->pid = pid;
						snprintf( pl->processes[pl->count]->home_dir, MAX_NAME, "%s", statusfilename);
						Process_readShaping( pl->processes[pl->count],  statusfilename );
						pl->count++;
					}
				}
			}
		}
		closedir(dir);
	}
}

void Process_findResource(struct Process_Table_ *this ){

	Process_readShaping( this, this->home_dir);
	if(!this->shaping)
		this->resource = 0;	
		
}
//--------------------------------------------------------------------------
