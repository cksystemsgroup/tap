/*
 *  The TAP Project: Traffic Shaping System Calls
 *  Copyright (c) Harald Roeck (hroeck@cs.uni-salzburg.at), Silviu Craciunas (scraciunas@gmail.com)
 *
 *  University Salzburg, www.uni-salzburg.at
 *  Department of Computer Science, cs.uni-salzburg.at
 *
 *  This project is funded by the Austrian Science Fund project nummer P18913
 *
 *  This program is free software; you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation; either version 2 of the License, or
 *  (at your option) any later version.
 *
 *  This program is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 *
 *  You should have received a copy of the GNU General Public License
 *  along with this program; if not, write to the Free Software
 *  Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 *
 */

#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <string.h>
#include <sys/types.h>
#include <sys/wait.h>
#include <time.h>
#include <curses.h>
#include <sys/syscall.h>
#include <Process.h>
#include <stdbool.h>

#define FUZZY_PERIOD 5
#define TOKEN_BASE 100

char *Fuzzy_A_fieldNames[] = {
   "Normal", "Ok", "Insufficient", "Bad", "Critical", "Tilt"};

int Fuzzy_B_Values[6] = {-30,70,150,250,500,1000};
#define EXEC_CMD "./prof.stp -x "
        
#define PROC_DIR "/proc"
#define BUFFER_SIZE 16
        
#define SLEEP_MILLIS 1

        
int call_count,avg_time,total_time;
int current_getch;
int doloop = 1;
int pid_master;
char *pid_master_string;
static WINDOW *mainForm;
static WINDOW *scr_inst;
static WINDOW *clie_list;
WINDOW *auto_win;
FILE *f1;
int fuzzy_time;
int fuzzy_temp_value;
int fuzzy_a_value;
int fuzzy_b_value;


static char time_str[12] = {0};
struct tm *now2 = NULL;
int hour = 0;
time_t time_value = 0;

bool enable_control = false;

int n_sec, n_min, n_hour, n_day, n_wday, n_month, n_year;
time_t now;
struct tm *n_time;
char stap_command[20] = EXEC_CMD;

#define C_RED          1
#define C_GREEN        2
#define C_WHITE        3



struct Process_Table_ *master;
struct Process_List_ *slave;
void analyze(char buffer[BUFFER_SIZE]);
void update_display(void);



void init_Processes()
{
	char svalue[MAX_NAME + 1];

	master = malloc(sizeof(Process_Table));
	master->pid = pid_master;
	master->resource = 0;
	snprintf(svalue, MAX_NAME, "%s/%d/shaping", PROC_DIR, master->pid );
	snprintf(master->home_dir, MAX_NAME, "%s/%d/shaping", PROC_DIR, master->pid );
	Process_readShaping( master, svalue);
	slave = malloc(sizeof(Process_List));
	slave->count = 0;
	Process_loadList(slave, PROC_DIR, pid_master);
}

void destroy_Processes()
{
	int i;
	free(master);
	for(i=0;i<slave->count;i++)
	{
		free(slave->processes[i]);
	}
	free(slave);
}

void fuzzy_control(int call_count)
{
	int i;
	if(call_count == 0)
	{
		fuzzy_temp_value++;
	}
	
	if(fuzzy_time == FUZZY_PERIOD) 
	{
		fuzzy_a_value = fuzzy_temp_value;
		fuzzy_b_value = Fuzzy_B_Values[fuzzy_a_value];

		if(enable_control) 
		{
			time_value = time(NULL);
			now2 = localtime(&time_value);
  			hour = now2->tm_hour;

 			int x = hour * 3600 + now2->tm_min * 60 + now2->tm_sec;
			fprintf (f1, "%d,%d,", x, fuzzy_b_value);
			for(i = 0; i < slave->count; i++) 
			{
				Process_writeShaping( slave->processes[i], slave->processes[i]->home_dir, fuzzy_b_value, master->resource );
				fprintf (f1, "%d,%d,", slave->processes[i]->pid, slave->processes[i]->stable[master->resource].rate_write);
				refresh();
			}
			fprintf (f1, "\n");
		}
		fuzzy_time = 0;
		fuzzy_temp_value = 0;
	} else {
		fuzzy_time++;
	}
}

void runServ(int writeFd) 
{
	FILE *fd;
	int rB, wB;
	char buffer[BUFFER_SIZE];

	strcat(stap_command, pid_master_string);
	fd = popen(stap_command, "r");

	if ( fd == NULL )
	{
        exit(EXIT_FAILURE);
	}
	
    while ( !feof(fd) )
    {
        rB = fread(buffer, sizeof(char), BUFFER_SIZE, fd);
        if ( rB < 0 )
        {
            exit(EXIT_FAILURE);
        }
        if ( (wB = write(writeFd, buffer, rB) != rB) )
        {
            exit(EXIT_FAILURE);
        }
        usleep(SLEEP_MILLIS);
    }
    pclose(fd);
}

void runClie(int readFd)
{
    int rB,ch;
	int i;
    char buffer[BUFFER_SIZE];
	
	sleep(20);
	system("clear");

    do
    {
		ch = getch();
		if (ch == 113) 
		{
			destroy_Processes();
			endwin();
			fclose (f1);
			printf("Autoshape session ended.\n");
			exit(1);
		}

		if (ch == 'a') 
		{
			if(enable_control)
				enable_control = false;
			else
				enable_control = true;
		}
		if (ch == 'r') 
		{
			for(i=0;i<slave->count;i++)
				free(slave->processes[i]);
			free(slave);
			slave = malloc(sizeof(Process_List));
			slave->count = 0;
			Process_loadList(slave, PROC_DIR, pid_master);
		}

		if (ch == '1')
			master->resource = 0;
		if (ch == '2')
			master->resource = 1;
		if (ch == '3')
			master->resource = 2;
		
        rB = read(readFd, buffer, BUFFER_SIZE);
        if ( rB < 0 )
        {
            exit(EXIT_FAILURE);
        }

		analyze(buffer);
    } while ( rB > 0 );

}

void maketime(void) 
{
	now = time (NULL);
	n_time = localtime (&now);
   	n_sec = n_time->tm_sec;
	n_min = n_time->tm_min;
	n_hour = n_time->tm_hour;
	n_day = n_time->tm_mday;
	n_wday = n_time->tm_wday;
	n_month = n_time->tm_mon + 1;
	n_year = n_time->tm_year + 1900;
}

void analyze(char buffer[BUFFER_SIZE])
{
	char *sub_string;
	
	sub_string = strtok(buffer, ",");
	call_count = atoi(sub_string);
	
	while ( (sub_string=strtok(NULL, ",")) != NULL)
	{
		if(avg_time == 0) 
		{
			avg_time = atoi(sub_string);
		} else {
			total_time = atoi(sub_string);
		}
	}

	fuzzy_control(call_count);
	maketime();
	update_display();

	avg_time = 0;
	total_time = 0;
	call_count = 0;
}

void update_display(void) 
{
	int i;
	
	curs_set(0);
	mvwprintw(scr_inst,1,1,"----------------------- AUTOSHAPE ------------------------");
	mvwprintw(scr_inst,2,2,"TIME: %2d:%2d:%2d | DATE: %2d-%2d-%4d", n_hour, n_min, n_sec, n_day, n_month, n_year);
	mvwprintw(scr_inst,3,2,"Calls : %4d Average Time: %4d Total Time: %5d", call_count, avg_time, total_time);
	mvwprintw(scr_inst,4,2,"Process ID: [ %d ] | Shaping : [ %d ] | Mode : [ %d ]", master->pid, master->shaping, master->smode);
	mvwprintw(scr_inst,5,2,"Device : [ %d ]", master->resource);
	
	if(call_count != 0)
	{
		wattron(scr_inst, COLOR_PAIR(C_GREEN));
		mvwprintw(scr_inst,6,2,"Process status: [  ok  ]");
		wattroff(scr_inst, COLOR_PAIR(C_GREEN));
	} else {
		wattron(scr_inst, COLOR_PAIR(C_RED));
		mvwprintw(scr_inst,6,2,"Process status: [failed]");
		wattroff(scr_inst, COLOR_PAIR(C_RED));
	}

	mvwprintw(scr_inst,7,2,"Fuzzy A Value : %14s", Fuzzy_A_fieldNames[fuzzy_a_value]);
	mvwprintw(scr_inst,8,2,"Fuzzy B Value : %5d", fuzzy_b_value);
	if(enable_control)
		mvwprintw(scr_inst,9,2,"Autoshaping : [  enabled ] ");
	else
		mvwprintw(scr_inst,9,2,"Autoshaping : [ disabled ] ");

	mvwprintw(scr_inst,21,4,"[ press q to end ]");

	wattron(clie_list, COLOR_PAIR(C_WHITE));
	mvwprintw(clie_list,1,1,"TASK LIST");
	mvwprintw(clie_list,2,2," PID |Shp|Mode|RRate |RCount|WRate |WCount");
	for( i=0 ; i < slave->count ; i++ ) 
	{
		mvwprintw(clie_list,3+i,2,"%5d|%3d|%4d|%6d|%6d|%6d|%6d", slave->processes[i]->pid, slave->processes[i]->shaping, 
				slave->processes[i]->smode,slave->processes[i]->stable[master->resource].rate_read,slave->processes[i]->stable[master->resource].count_read,
				slave->processes[i]->stable[master->resource].rate_write,slave->processes[i]->stable[master->resource].count_write);
	}
	wattroff(clie_list, COLOR_PAIR(C_WHITE));

	wrefresh(clie_list);	
	wrefresh(scr_inst);
	
	refresh();
}

void scr_inst_init(void) 
{
	mainForm = initscr();
	if(has_colors() == FALSE)
	{
		endwin();
		exit(1);
	}
	start_color();
	init_pair(C_GREEN, 2, 0);
     	init_pair(C_RED, 1, 0);
     	init_pair(C_WHITE, 7, 0);
	noecho();
	cbreak();
	nodelay(mainForm, TRUE);
	refresh(); 
	wrefresh(mainForm);
	scr_inst = newwin(23, 60, 1, 1);
	clie_list = newwin(53, 50, 1, 61);
	box(scr_inst, ACS_VLINE, ACS_HLINE);
	box(clie_list, ACS_VLINE, ACS_HLINE);
}


void scr_inst_end(void) 
{
	int i;
	endwin();
	for(i=0; i< slave->count; i++)
	{
		printf("PID : %d\n", slave->processes[i]->pid);
	}
}

void usage(char *name)
{
	printf("usage: %s pid\n", name );
}

int main(int argc, char **argv)
{
    pid_t pid;
    int pFd[2];

	if(argc < 2 || argc > 3)
	{
		usage(argv[0]);
		exit(1);
	}
	pid_master_string = argv[1];
	pid_master = atoi( argv[1] );
	if(pid_master == 0)
	{
		usage(argv[0]);
		exit(1);
	}

	f1 = fopen ("out.lis", "wt"); 	
	
	scr_inst_init();
	init_Processes();
    if ( pipe(pFd) == -1 )
    {
        exit(EXIT_FAILURE);
    }

    pid = fork();
    if ( pid < 0 )
    {
        exit(EXIT_FAILURE);
    }
    else if ( pid == 0 ) 
    {
        close(pFd[0]); 
        runServ(pFd[1]);
        close(pFd[1]); 
    } else {
        close(pFd[1]); 
        runClie(pFd[0]);
        close(pFd[0]); 

        if ( waitpid(pid, NULL, 0) == -1 )
        {
            exit(EXIT_FAILURE);
        }
    }
	destroy_Processes();
	scr_inst_end();
    return EXIT_SUCCESS;
}

