/* $Id: threads_private.h,v 1.7 2006/04/28 16:50:33 hroeck Exp $*/

/* 
 * Copyright (c) Harald Roeck hroeck@cs.uni-salzburg.at 
 *
 * University Salzburg, www.uni-salzburg.at
 * Department of Computer Science, cs.uni-salzburg.at
 */

/*  
 *  This program is free software; you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation; either version 2 of the License, or
 *  (at your option) any later version.
 *
 *  This program is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 *
 *  You should have received a copy of the GNU General Public License
 *  along with this program; if not, write to the Free Software
 *  Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 *
 */

#ifndef THREADLIB_PRIVATE_H
#define THREADLIB_PRIVATE_H

#include "threads.h"
#include "ctx.h"
#include "list.h"
#include "stack.h"
#include "timeoutq.h"
#include "timing.h"
#include <libaio.h>
#include <stdlib.h>
#include <errno.h>

#define MAX_THREADS  512        // never use more than 512 threads

#define MAX_PRIORITY 10
#define MIN_PRIORITY 0

#define _EPOLL_QUEUE_SIZE  MAX_THREADS
#define _EPOLL_MAX_EVENTS  MAX_THREADS

#define TOKENS_PER_PRIORITY  5

#define CONF_FILE "tap.conf"

enum
{
    INCREASE = 1,
    DECREASE = 2,
    CONSTANT = 3,
} priority_policy;

static inline const char *const get_policy_name(int id)
{
	switch(id)
	{
		case INCREASE:
			return "INCREASE";
		case DECREASE:
			return "DECREASE";
		case CONSTANT:
			return "CONSTANT";
	}
	return NULL;
}
typedef struct
{
    enum
    {
        APP_COMMIT = 1,
        APP_READ,
        APP_WRITE,
        APP_ACCEPT,
        APP_SOCKOP,
    } type;
    enum
    {
        RES_DISK = 1,
        RES_NET,
        RES_CPU,                /* for commit, and others */
    } resource;
} appointment_t;

typedef enum
{
    READ = 1,
    WRITE,
    PREAD,
    PWRITE,
    ACCEPT,
} tap_io_t;

struct _fdesc;
typedef long ( *sys_func ) ( int fd, long arg1, long arg2 );

/*
 * do not change the structure
 * of theses *cb structures unless you
 * know what you do!!!!
 */
struct _cb
{
    tap_io_t op;
    sys_func callback;
    struct _fdesc *fd;
    ssize_t result;
    struct
    {
        long arg1;
        long arg2;
    } args;
};
struct netcb
{
    tap_io_t op;
    sys_func callback;
    struct _fdesc *fd;
    ssize_t result;
    union
    {
        struct
        {
            void *buf;
            size_t count;
        } rw;
        struct
        {
            struct sockaddr *addr;
            socklen_t *addrlen;
        } accept;
        struct
        {
            long arg1;
            long arg2;
        } args;
    };
};
struct diskcb
{
    tap_io_t op;
    sys_func callback;
    struct _fdesc *fd;
    ssize_t result;
    union
    {
        struct
        {
            void *buf;
            size_t count;
        } rw;
        struct
        {
            long arg1;
            long arg2;
        } args;
    };
};

struct _thread;
typedef struct _thread
{
    int tid;
    /*
     * cpu context 
     */
    struct ctx_context ctx;

    /*
     * stack segment 
     */
    tap_stack_t *stk;

    /*
     * when we support SMP 
     */
    char cpu_id;

    /*
     * the state of the thread 
     */
    enum
    {
        RUNNING = 1,
        RELEASED,
        BLOCKED,
        WAITING,
        ZOMBIE,
        DESTROYED,
    } state:8;

    /*
     * internal flags, e.g. joinable, detached 
     */
    char flags;
#define TAP_JOINABLE         0x01       // not supported
#define TAP_CANCELED         0x02
#define TAP_TIMEDOUT         0x04
#define TAP_DETACHED         0x08

#define TAP_RUN_ON_APP       0x10
#define TAP_ON_NEXT_APP      0x20
#define TAP_ON_NEXT_CLOCK    0x40

    /*
     * priority 
     */
    char priority;

    int consumed_tokens;
    /*
     * the private errno 
     */
    int _errno;

    /*
     * start function and arguments 
     */
    void *( *start_func ) ( void *data );
    void *start_data;
    void *retval;

    /*
     * joining thread 
     */
    struct _thread *joining_thread;

    /*
     * for the family tree 
     * FIXME: not yet supported     
     * parent thread 
     */
    struct _thread *parent;
    /*
     * childs and siblings 
     */
    struct list_head childs;
    struct list_head siblings;

    /*
     * for inserting the thread in the queue
     * run queue, zombie queue, timeout queue, I/O queues
     */
    struct list_head queue;

    /*
     * for queueing the accepts
     */
    struct list_head io_q;
    /*
     * timeout queue 
     */
    timeoutq_t tq;

    union
    {
        struct _cb cb;
        struct netcb ncb;
        struct diskcb dcb;

    };
} _thread_t;

/* forward declarations of some basic functions */

/*
 * constructor and destructor;
 * called by the main thread, before and
 * after main() resp.
 */
void main_init(  ) __attribute__ ( ( constructor ) );
void main_exit(  );

/*
 * if time -1 blocks indefinetly or until an
 * other event wakes the thread
 * return the current time 
 * i.e. when the thread continues
 *
 */
tap_utime_t block( tap_utime_t time );

/*
 * add current thread to the timeout queue
 */
int thread_timeout( tap_utime_t time );

/*
 * kill/destroy a thread
 */
void tap_kill( _thread_t * thr );

/*
 * increase priority of a thread
 */
static inline void _thread_inc_priority( _thread_t * thr )
{
    switch ( priority_policy )
    {
    case CONSTANT:
        break;
    case INCREASE:
        if( thr->priority < MAX_PRIORITY-1 )
            ++thr->priority;
        break;
    case DECREASE:
        if( thr->priority > MIN_PRIORITY )
            --thr->priority;
        break;
    }

}

/*
 * decrease priority
 */
static inline void _thread_dec_priority( _thread_t * thr )
{
    switch ( priority_policy )
    {
    case CONSTANT:
        break;
    case INCREASE:
        if( thr->priority > MIN_PRIORITY )
            --thr->priority;
        break;
    case DECREASE:
        if( thr->priority < MAX_PRIORITY-1 )
            ++thr->priority;
        break;
    }
	
}

static inline void _thread_reset_priority( _thread_t * thr )
{

    switch ( priority_policy )
    {
    case CONSTANT:
     
        break;
    case INCREASE:
        thr->priority = MAX_PRIORITY - 1;
        break;
    case DECREASE:
        thr->priority = MIN_PRIORITY;
        break;
    }

}

/**********************************************************
 *          public tap functions 
 **********************************************************/

/* yields to reactor */
void tap_yield(  );
void tap_yield_thread( _thread_t * thread );

/* returns the current thread */
_thread_t *tap_thread_self(  );

/* exit current thread */
void tap_thread_exit( void *retval );

/* create a new thread */
_thread_t *tap_thread_create( void *( *start ) ( void *arg ), void *arg, int flags );

/* cancel a thread */
int tap_thread_cancel( _thread_t * thr );

/****************************************************** 
 *                         I/O
 ******************************************************/

void tap_io_init( int id );
void tap_io_destroy( int id );

/*
 * check aio queue and epoll for ready threads
 */
int tap_io_poll( struct list_head *list );

void calc_throughput(  );

#endif
