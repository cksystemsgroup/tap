/* $Id: runq.h,v 1.4 2006/04/28 16:50:33 hroeck Exp $ */

/* 
 * Copyright (c) Harald Roeck hroeck@cs.uni-salzburg.at 
 *
 * University Salzburg, www.uni-salzburg.at
 * Department of Computer Science, cs.uni-salzburg.at
 */

/*
 *  This program is free software; you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation; either version 2 of the License, or
 *  (at your option) any later version.
 *
 *  This program is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 *
 *  You should have received a copy of the GNU General Public License
 *  along with this program; if not, write to the Free Software
 *  Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 *
 */

#ifndef RUNQ_H
#define RUNQ_H

#include "list.h"
#include "threads_private.h"

#define LENGTH (MAX_PRIORITY - MIN_PRIORITY)

/* the runqueue */
typedef struct
{
    struct list_head list[LENGTH];
    int len;
} runq_t;

/* traverse a run queue 
 *	runq is a pointer to a queue
 *	thr is the pointer to the actual thread
 */
#define runq_foreach(runq, thr)	\
		list_for_each_entry(thr, &runq->list, queue)

/*
 * init the runq;
 */
static inline void runq_init( runq_t * run_q )
{
    int i;
    for( i = 0; i < LENGTH; ++i )
        INIT_LIST_HEAD( run_q->list + i );

    run_q->len = 0;
}

/*
 *	return the length of the queue
 */
static inline int runq_length( runq_t * run_q )
{
    return run_q->len;
}

/* 
 * returns true if runq is empty
 */
static inline int runq_empty( runq_t * run_q )
{
    return !runq_length( run_q );
}

/*
 * append a thread at the end of the runqueue
 *
 */
static inline void runq_append( runq_t * run_q, _thread_t * thr )
{
    int prio = thr->priority - MIN_PRIORITY;

    list_add_tail( run_q->list + prio, &thr->queue );
    run_q->len++;
}

/*
 * get the next thread 
 * and remove it from the runqueue
 */
static inline _thread_t *runq_next( runq_t * run_q )
{
    _thread_t *thr = NULL;
    int i;

    for( i = 0; i < LENGTH; ++i )
        if( !list_empty( run_q->list + i ) )
            break;

    if( i < LENGTH )
    {
        thr = list_entry( ( run_q->list + i )->next, _thread_t, queue );
        list_del_init( &thr->queue );
        run_q->len--;
    }
    return thr;
}

/* 
 * return the highest priority of all threads in the queue 
 * returns -1 if runq is empty
 */
static inline int runq_priority(runq_t *run_q)
{
	int i;
	for( i=0; i< LENGTH; ++i )
		if( !list_empty( run_q->list +i ) )
			break;
	if( i < LENGTH )
		return MIN_PRIORITY + i;
	else
		return -1;
}

/*
 * print the runq
 * for debugging
 */
static inline void runq_print( runq_t * run_q )
{
#ifndef NDEBUG
   
    if( run_q->len )
    {
        internal( 0, " queue length %d: ", run_q->len );

    }
#endif
}

#undef LENGTH
#endif
