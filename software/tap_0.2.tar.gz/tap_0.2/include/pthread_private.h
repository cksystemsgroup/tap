/* $Id: pthread_private.h,v 1.3 2006/04/28 16:50:33 hroeck Exp $*/

/* 
 * Copyright (c) Petru Flueras petru.flueras@cs.uni-salzburg.at 
 *
 * University Salzburg, www.uni-salzburg.at
 * Department of Computer Science, cs.uni-salzburg.at
 */

/*  
 *  This program is free software; you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation; either version 2 of the License, or
 *  (at your option) any later version.
 *
 *  This program is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 *
 *  You should have received a copy of the GNU General Public License
 *  along with this program; if not, write to the Free Software
 *  Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 *
 */

#ifndef PTHREADLIB_PRIVATE_H
#define PTHREADLIB_PRIVATE_H

#ifdef _pthread_t
#undef _pthread_t
#endif

#include "threads.h"
#include "list.h"

typedef struct _pthread_st
{
    int tap_thread_id;
    tap_thread_t tap_thread;
    struct list_head queue;
} _pthread_t;

typedef struct _pthread_attr_st
{
	int flags;
#define PTHREAD_ATTR_DETACH 0x00000001
	int stack_size;
	int spare[2];
} _pthread_attr_t;

void pthread_initialize(  );
void pthread_finalize(  );

// functions for hashtable
unsigned get_hash( int key );

#endif // PTHREAD_PRIVATE_H
