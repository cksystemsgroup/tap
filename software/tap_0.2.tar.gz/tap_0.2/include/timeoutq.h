/* $Id: timeoutq.h,v 1.1.1.1 2006/04/11 14:01:21 hroeck Exp $ */

/* 
 * Copyright (c) Harald Roeck hroeck@cs.uni-salzburg.at 
 *
 * University Salzburg, www.uni-salzburg.at
 * Department of Computer Science, cs.uni-salzburg.at
 */

/*  
 *  This program is free software; you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation; either version 2 of the License, or
 *  (at your option) any later version.
 *
 *  This program is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 *
 *  You should have received a copy of the GNU General Public License
 *  along with this program; if not, write to the Free Software
 *  Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 *
 */

#ifndef THEAP_H
#define THEAP_H

#include "timing.h"
#include "list.h"
#include <assert.h>

        /*
         * Timeout queue 
         */
typedef struct timeoutq
{
    tap_utime_t timeout;
    struct list_head queue;
} timeoutq_t;

/*
 * initialize tq, to save 
 * max_elements at most
 */
static inline int tq_init( timeoutq_t * tq )
{
    INIT_LIST_HEAD( &tq->queue );
    tq->timeout = 0;
    return 0;
}

static inline int tq_empty( timeoutq_t * tq )
{
    return list_empty( &tq->queue );
}
static inline timeoutq_t *tq_next( timeoutq_t * tq )
{
    return list_entry( tq->queue.next, timeoutq_t, queue );
}

#define tq_entry(ptr, type, member) \
	container_of(ptr, type, member)

static inline void tq_print( timeoutq_t * tq )
{
    timeoutq_t *p, *pp;
    if( !list_empty( &tq->queue ) )
    {
        p = tq;
        pp = tq_next( tq );
        internal( 5, " print timeoutq %p", tq );
        while ( pp != tq ) ;
        {
            assert( p->timeout < pp->timeout );
            internal( 5, "   --> %15lld  ", p->timeout );
            p = pp;
            pp = tq_next( p );
        }

        internal( 5, " done " );
    }
}

/****************
 * insert a thread with some timeout to the the tq 
 */
static inline int tq_push( timeoutq_t * tq, timeoutq_t * n )
{
    timeoutq_t *p;

    internal( 5, " tq add entry at %lld", n->timeout );

    p = tq;
    while ( p->timeout < n->timeout )
    {
        p = list_entry( p->queue.next, timeoutq_t, queue );
        if( p == tq )
            break;
    }
    if( p == tq )
        list_add_tail( &p->queue, &n->queue );
    else
        list_add( &p->queue, &n->queue );

//      tq_print(tq);
    return 0;
}

static inline int tq_push_back( timeoutq_t * tq, timeoutq_t * n )
{
    return -1;
}

/* get the first element of the tq */
static inline void tq_pop( timeoutq_t * tq )
{

    if( !list_empty( &tq->queue ) )
    {
        internal( 5, " remove element from timeoutq; %p ", tq );
        list_del_init( &tq->queue );
    }

}

/* get the time of the first thread which timeouts */
static inline tap_utime_t tq_gettime( timeoutq_t * tq )
{
    return tq_next( tq )->timeout;
}

#endif
