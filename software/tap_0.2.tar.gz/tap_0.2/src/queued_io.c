/* $Id: queued_io.c,v 1.2 2006/04/28 13:18:16 hroeck Exp $ */

/***************************************************************************
 *             queued_io.c
 *
 *  Fri Apr 14 13:30:29 2006
 *  Copyright  2006  Harald Roeck
 *  
 * University Salzburg, www.uni-salzburg.at
 * Department of Computer Science, cs.uni-salzburg.at
 ****************************************************************************/

/*
 *  This program is free software; you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation; either version 2 of the License, or
 *  (at your option) any later version.
 *
 *  This program is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 *
 *  You should have received a copy of the GNU General Public License
 *  along with this program; if not, write to the Free Software
 *  Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA 02111-1307, USA.
 */

#include "threads_private.h"
#include "runq.h"
#include "process.h"
#include "fd.h"
#include "timer.h"

#include <stdio.h>
#include <unistd.h>

static int __do_callback( struct _cb *cb )
{
    _fd_t *fd = cb->fd;

    if( fd->type == FD_SOCKET && sock_err( fd ) )
    {
        errno = EPIPE;
        fd->thread->_errno = EPIPE;
        cb->result = -1;
        return -1;
    }

    if( !cb->callback )
    {
        fprintf( stderr, "ERROR: no callback registered\n" );
        return -1;
    }

    cb->result = cb->callback( fd->osfd, cb->args.arg1, cb->args.arg2 );
    cb->callback = NULL;

    return cb->result;
}

int do_queued_io( int queue_id, runq_t * run_q )
{
    int tokens = tk_get_token( queue_id );
    runq_t *queue = get_token_queue( get_id(  ), queue_id );
    struct _cb *cb;
    _thread_t *thread;
    int value, tokens_needed;

    while ( !runq_empty( queue )
            && tokens
            && runq_priority( queue ) <= get_max_priority( get_id(  ) ) )
    {
        internal( 5, "process IO requests" );
        thread = runq_next( queue );
        internal( 4, " got thread %d from token queue\n", thread->tid );
        cb = &thread->cb;

        // check if we have enough tokens
        if( cb->op == READ || cb->op == WRITE )
        {
            if( cb->args.arg2 >> TOKEN_BITS > tokens )
                cb->args.arg2 = tokens << TOKEN_BITS;
        }

        value = __do_callback( cb );
        if( value < 0 )
        {
            internal( 5, "__do_callback returned an error" );
        }
        else
        {
            internal( 5, " __do_callback value %d", value );
            tokens_needed = value >> TOKEN_BITS ? value >> TOKEN_BITS : 1;

            tokens -= tokens_needed;
            thread->consumed_tokens += tokens_needed;
            if( thread->consumed_tokens > TOKENS_PER_PRIORITY )
            {
                _thread_dec_priority( thread );
                thread->consumed_tokens = 0;
            }
        }
        /*
         * move thread from IO queue to CPU queue 
         */
        thread->state = RELEASED;
        thread->flags &= ~TAP_TIMEDOUT;
        runq_append( run_q, thread );
    }
    if( tokens )
    {
        internal( 5, "add %d tokens to resource %d", tokens, queue_id );
        tk_add_token( queue_id, tokens );
    }
/* 
 *     else
 *     {
 *         static int x;
 *         if( !runq_empty( queue ) )
 *         {
 *             printf( " %c run out of tokens but queue is not empty!!\n",
 *                     "/-\\|"[x] );
 *             ++x;
 *             x &= 0x3;
 *         }
 *     }
 */
    return 0;
}
