/* $Id: threads.c,v 1.7 2006/04/28 16:50:33 hroeck Exp $ */

/* 
 * Copyright (c) Harald Roeck hroeck@cs.uni-salzburg.at 
 *
 * University Salzburg, www.uni-salzburg.at
 * Department of Computer Science, cs.uni-salzburg.at
 */

/*  
 *  This program is free software; you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation; either version 2 of the License, or
 *  (at your option) any later version.
 *
 *  This program is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 *
 *  You should have received a copy of the GNU General Public License
 *  along with this program; if not, write to the Free Software
 *  Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 *
 */

#include "threads_private.h"
#include "process.h"
#include "runq.h"
#include "stack.h"
#include "timer.h"
#include "pthread_private.h"

#include <stdlib.h>
#include <stdio.h>
#include <unistd.h>
#include <string.h>
#include <assert.h>
#include <syscall.h>
#include <sys/time.h>
#include <sys/resource.h>

#define STK_SIZE 1024*24

/* holds the main thread */
static _thread_t main_thread;

/* the process vector */
process_t processes[MAX_PROC];

/* forward declarations */
/* start up routine for the reactor */
static void start_reactor( void *args );
/* the reactor loop */
static void react(  );
/* the scheduler */
static void sched( int id );
/* creates a thread object with a given stack size */
static _thread_t *create_thread_object( size_t stk_size );

static void thread_destroy( _thread_t * thr );

extern int do_queued_io( int queue_id, runq_t * run_q );

/* 
 * initialize a process
 * i.e. create a reactor, run queue and set 
 * the current thread
 */
static void process_init( int id, _thread_t * curr_thread )
{
    _thread_t *reactor;
    process_t *process = &processes[id];
    int i;
    /*
     * zero the process vector 
     */
    memset( process, 0, sizeof( process_t ) );
    /*
     * init the first process 
     */
    process->pid = getpid(  );

    runq_init( &process->run_q );
    runq_init( &process->zombie_q );
    runq_init( &process->joining_q );

    /*
     * runq_init(&process->finished_q);
     */
    /*
     * create reactor 
     */
    reactor = create_thread_object( STK_SIZE * 2 );
    assert( reactor );
    internal( 0, "reactor created!" );

    if( ctx_create( &reactor->ctx, start_reactor, NULL, reactor->stk ) )
        tap_error( "ctx_create" );
    reactor->tid = -1;
    INIT_LIST_HEAD( &reactor->queue );
    process->reactor = reactor;

    process->curr_thread = curr_thread;
    process->active_threads = 1;

    tq_init( &process->timeout_q );

    for( i = 0; i < MAX_RESOURCE; ++i )
    {
        runq_init( process->token_wait + i );

    }

    internal( 0, "reactor initialized" );
    internal( 0, "reactor at %p, queue at %p", process->reactor,
              &process->reactor->queue );
    internal( 0, "runq at %p, list at %p", &process->run_q,
              &process->run_q.list );

}

/***********************************************************/
/*                 switching threads                       */
/***********************************************************/
/* switch to an other thread; */
static inline int switch_thread( _thread_t * from, _thread_t * to )
{
    return ctx_switch( &from->ctx, &to->ctx );
}

/*
 * stops thread "from" and resumes thread "to"
 *
 * checks threads and handles errno
 */
static inline void yield_to( _thread_t * from, _thread_t * to )
{
    assert( from );
    assert( to );
    internal( 2, " yielding from %d to %d ...", from->tid, to->tid );

    from->_errno = errno;
    /*
     * FIXME check for errors 
     */
    switch_thread( from, to );
    errno = from->_errno;
}

int thread_timeout( tap_utime_t time )
{
    int id = get_id(  );
    tap_utime_t now = tap_utime(  );
    _thread_t *thread = get_thread( id );
    timeoutq_t *tq = get_timeoutq( id );

    if( !tq_empty( &thread->tq ) )
    {
        internal( 4, "already a timeout installed" );
        return -1;
    }

    internal( 4, " WAITING til %lld", now + time );
    thread->tq.timeout = now + time;
    tq_push( tq, &thread->tq );

    return 0;
}

tap_utime_t block( tap_utime_t time )
{
    int id = get_id(  );
    tap_utime_t now = tap_utime(  );
    _thread_t *thread = get_thread( id );
    _thread_t *reactor = get_reactor( id );

    internal( 4, " in block: timeout of %lld", time );
    if( time == 0 )
    {
        internal( 4, " timeout of 0 block immediatelly returns" );
        yield_to( thread, reactor );
        return now;
    }
    if( time > 0 )
    {
        thread_timeout( time );
        thread->state = WAITING;
    }
    else
    {
        internal( 4, " BLOCKED" );
        thread->state = BLOCKED;
    }

    processes[id].curr_thread = NULL;
    yield_to( thread, reactor );

    internal( 4, " resumes after BLOCKED " );

    if( time > 0 && thread->flags & TAP_TIMEDOUT )
    {
        internal( 4, " remove from timeout queue " );
        tq_pop( &thread->tq );
    }

    return tap_utime(  );
}

/*
 * yields to the reactor
 */
static inline void yield(  )
{
    int id = get_id(  );
    _thread_t *curr_thread = get_thread( id );
    _thread_t *reactor = get_reactor( id );

    yield_to( curr_thread, reactor );

    assert( curr_thread->state == RUNNING );
}

/* 
 * public yield
 */
void tap_yield(  )
{
    yield(  );
}

void tap_yield_thread( _thread_t * thread )
{
    _thread_t *reactor = get_reactor( get_id(  ) );

    yield_to( thread, reactor );
}

/*
 *	public function returns reference 
 *	to currently running thread
 */
_thread_t *tap_thread_self(  )
{
    return get_thread( get_id(  ) );
}

int tap_getid(  )
{
    return get_thread( get_id(  ) )->tid;
}

int tap_thread_getid( _thread_t * thr )
{
    internal( 5, "thr is %p", thr );
    if( thr )
        return thr->tid;

    return -1;
}

/*
 * override system errno location function 
 */
//int *__errno_location()
//{
//      return &get_thread(get_id())->_errno;
//}
/********************************************************
 *                   RSP modell
 ********************************************************/
/* start function for the reactor */
static void start_reactor( void *args )
{
    react(  );                  /* returns when all threads are gone */
    /*
     * switch back to the main thread to do
     * the final clean up
     */
    internal( 1, " no more threads; switch back to main thread ..." );
    ctx_resume( &main_thread.ctx );
}

/*
 * The Reactor
 */
static void react(  )
{
    int id;
    runq_t *run_q, *zombie_q, *network_q, *disk_q;
    _thread_t *curr_thread;
    _thread_t *reactor;
    timeoutq_t *timeoutq;
    tap_utime_t now;

    id = get_id(  );
    run_q = get_runq( id );
    zombie_q = get_zombieq( id );
    network_q = get_token_queue( id, NETWORK_TOKEN );
    disk_q = get_token_queue( id, DISK_TOKEN );
    reactor = get_reactor( id );
    timeoutq = get_timeoutq( id );

    /*
     * update clock
     */
    clock_tick(  );
    /*
     * run while the run queue is not empty and 
     * the current thread is valid 
     */
    while ( process_active_threads( id ) )
    {
        /*
         * get the current_thread 
         */
        curr_thread = get_thread( id );

        internal( 1, "reactor ..., current_thread %p", curr_thread );

        /*
         * if there is a valid current thread
         * * append it to the end of the run queue 
         * * b/c it wants to run but it got interrupted
         */
        if( curr_thread && curr_thread->state == RUNNING )
        {
            curr_thread->state = RELEASED;
            internal( 1, "inserting %p in runq", curr_thread );
            runq_append( run_q, curr_thread );
            curr_thread = NULL;
        }

        /*
         * check for zombies 
         */
        if( !runq_empty( zombie_q ) )
        {
            _thread_t *thr;
            internal( 1, "destroying zombies" );
            while ( !runq_empty( zombie_q ) )
            {
                thr = runq_next( zombie_q );
                thread_destroy( thr );
            }
        }

        /*
         * get ready threads and push them 
         * * directly into the runq
         */
        while ( runq_empty( run_q )
                || runq_priority( run_q ) > get_max_priority( id ) )
        {
            /*
             * poll for finished IO 
             */
            internal( 1, " check for finished io" );
            /*
             * optimizations 
             */
            // if( runq_empty( network_q ) || tk_empty( NETWORK_TOKEN ) )
            tap_io_poll( NULL );

            clock_tick(  );
            now = tap_utime(  );

            do
            {
                tk_tick(  );
                if( tk_empty( NETWORK_TOKEN ) || tk_empty( DISK_TOKEN ) )
                {
                    tap_usleep( 500 );
                }
                else
                    break;
            }
            while ( 1 );

            /*
             * now that we have new tokens
             * process requests first
             * 
             */

            do_queued_io( NETWORK_TOKEN, run_q );
            do_queued_io( DISK_TOKEN, run_q );

            /*
             * check for timeout threads 
             */
            internal( 1, " check timeout queue " );
            if( !tq_empty( timeoutq ) && tq_gettime( timeoutq ) < now )
            {
                _thread_t *thr;
                internal( 1, " timeout queue time %lld",
                          tq_gettime( timeoutq ) );
                do
                {
                    thr = tq_entry( tq_next( timeoutq ), _thread_t, tq );
                    internal( 1, " thread %d timedout", thr->tid );
                    tq_pop( &thr->tq );
                    assert( thr->tq.timeout <= now );
                    thr->flags |= TAP_TIMEDOUT;
                    runq_append( run_q, thr );
                }
                while ( !tq_empty( timeoutq ) && tq_gettime( timeoutq ) < now );
            }

            calc_throughput(  );
        }

        /*
         * print the run_queue 
         */
        runq_print( run_q );
        /*
         * start the scheduler for this process 
         */
        sched( id );
    }                           /* end reactor loop */

}

/*
 *	the Scheduler
 *
 *	runq must not be empty
 */
static void sched( int id )
{
    runq_t *run_q = &processes[id].run_q;
    _thread_t *curr_thread = get_thread( id );
    _thread_t *reactor = get_reactor( id );
    internal( 1, "scheduler ..." );
    /*
     * get next thread 
     */
    curr_thread = runq_next( run_q );
    assert( curr_thread );
    internal( 1, " restart thread %p %d", curr_thread, curr_thread->tid );
    assert( curr_thread->state == RELEASED || curr_thread->flags & TAP_TIMEDOUT );
    curr_thread->state = RUNNING;
    processes[id].curr_thread = curr_thread;
    switch_thread( reactor, curr_thread );
    internal( 1, " return to reactor" );
}

/*****************************************************
 *                Library routines
 *****************************************************/

static inline void _init_thread_lists( _thread_t * new_thread )
{
    INIT_LIST_HEAD( &new_thread->queue );
    INIT_LIST_HEAD( &new_thread->io_q );
    INIT_LIST_HEAD( &new_thread->childs );
    INIT_LIST_HEAD( &new_thread->siblings );
}

/*
 * Library initialisierung
 *
 * called by the compiler before main()
 */

static void sighandler( int sig )
{
    struct rusage ru;
    printf( "got SIGINT, exiting 22 ...\n" );
	internal(1, "got SIGINT");
	
    if( getrusage( RUSAGE_SELF, &ru ) == 0 )
    {

        double user_time = ( double )ru.ru_utime.tv_sec +
            ( double )ru.ru_utime.tv_usec / 1000000;
        double system_time = ( double )ru.ru_stime.tv_sec +
            ( double )ru.ru_stime.tv_usec / 1000000;
        fprintf( stdout, "usage user: %f; system: %f ", user_time,
                 system_time );
        fprintf( stdout, " [ %2.2f user, %2.2f system ]\n",
                 100 * user_time / ( user_time + system_time ),
                 100 * system_time / ( user_time + system_time ) );
    }

    tap_kill( NULL );
    exit( 0 );
}

void main_init(  )
{

    clock_tick(  );
    signal( SIGINT, sighandler );
    /*
     * init the output 
     */
    debug_init(  );
    /*
     * init the first process 
     */
    process_init( 0, &main_thread );
    /*
     * set main as current thread 
     */
    memset( &main_thread, 0, sizeof( _thread_t ) );
    ctx_init( &main_thread.ctx );
    main_thread.tid = 0;
    _init_thread_lists( &main_thread );
    tap_io_init( 0 );
    main_thread.state = RUNNING;
    internal( 0, "main at %p, queue at %p", &main_thread, &main_thread.queue );
    timer_init(  );
    pthread_initialize(  );
}

void tap_kill( _thread_t * thr )
{

	main_exit();
//ctx_resume( &main_thread.ctx );
}

/*
 * called by the compiler after main returns
 */
void main_exit(  )
{
    int id = get_id(  );
    runq_t *zombie_q;
	_thread_t *thread;
   
    internal( 0, "exit TAP" );
    pthread_finalize(  );
    timer_exit(  );
    /*
     * FIXME do some final clean up 
     * like: delete reactor thread, close files ...
     *
     * join other processes if SMP is activated
     */
    /*
     * destroy zombies 
     */
    zombie_q = get_zombieq( id );
	while( !runq_empty(zombie_q) )
	{
		thread = runq_next( zombie_q );
		thread_destroy( thread );
	}
	zombie_q = get_joiningq( id );
	while( !runq_empty(zombie_q) )
	{
		thread = runq_next( zombie_q );
		thread_destroy( thread );
	}
    /*
     * runq_foreach( zombie_q, thr ) { thread_destroy( thr ); } 
     */
    internal( 0, "destroy io system" );
    tap_io_destroy( 0 );
    internal( 0, "destroy reactor" );
    /*
     * destroy reactor thread 
     */
    thread_destroy( get_reactor( id ) );
    debug_exit(  );
    exit( 0 );
}

/*********************************************************
 *                Thread handling
 *********************************************************/

/*
 * create a thread stub with stack
 * but no context
 * returned thread object is zeroed
 * and the stack pointer is set
 */
static _thread_t *create_thread_object( size_t stk_size )
{
    _thread_t *retval;
    tap_stack_t *stk;
    /*
     * allocate and init stack 
     */
    stk = stack_create( stk_size );
    if( !stk )
        return NULL;
    retval = ( _thread_t * ) stack_shift( stk, sizeof( _thread_t ) );
    memset( retval, 0, sizeof( _thread_t ) );
    retval->stk = stk;
    return retval;
}

/*
 * delete thread object and the stack
 *
 * checks for NULL pointers
 */
static void thread_destroy( _thread_t * thr )
{
    if( thr == NULL )
        return;
    internal( 0, " %p id %d going to be destroyed", thr, thr->tid );
    thr->state = DESTROYED;
    stack_destroy( thr->stk );
}

/*
 * start function for new threads
 * entry point of new thread
 */
static void dump_stack( _thread_t * thread ) __attribute__ ( ( unused ) );
static void dump_stack( _thread_t * thread )
{
    tap_stack_t *stk = thread->stk;
    char *p = ( char * )stk->top;
    printf( " thread at %p, stk %p at %p, p %p at %p\n", thread, stk, &stk, p,
            &p );
    while ( p > ( char * )stk->top - 250 )      // (char*)thread 
        // +
        // sizeof(*thread))
    {
        printf( "   %p  %p\n", p, *( long ** )p );
        p -= 4;
    }

}

static void starter( void *arg )
{
    void *retval;
    _thread_t *this = ( _thread_t * ) arg;
    /*
     * stop backtraking here  
     */
    memset( ( char * )&this + 4, 0,
            ( char * )this->stk->top - ( char * )&this - 1 );
    internal( 2, " %p start user function %p args %p",
              this, this->start_func, this->start_data );
    retval = this->start_func( this->start_data );
    tap_thread_exit( retval );
}

/*
 * get next thread id
 * FIXME: recycle old thread ids
 */
static int next_tid(  )
{
    static int last_tid = 1;
    return last_tid++;
}

/*
 * exit the current thread
 * and destroy all data
 */
void tap_thread_exit( void *retval )
{
    int id = get_id(  );
    _thread_t *curr_thread = get_thread( id );
    _thread_t *reactor = get_reactor( id );
    internal( 2, " exiting with %p ...", retval );
    /*
     * update family tree 
     */
    list_del( &curr_thread->siblings );   
	
    curr_thread->retval = retval;
    curr_thread->state = ZOMBIE;
    
    process_dec_threads( id );
    /*
     * check for a joining thread 
     */
    if( curr_thread->joining_thread )
    {
        _thread_t *jthr = curr_thread->joining_thread;
		internal(1, " thread %d is already joining me", jthr->tid);
		processes[id].curr_thread = NULL;
		jthr->state = RELEASED;
        process_release( jthr );
    }
    else if( curr_thread->flags & TAP_DETACHED )
    {
        /*
         * move thread to zombie queue queue 
         */
		internal(1, "I am detached");
        if( curr_thread != &main_thread )
            runq_append( &processes[id].zombie_q, curr_thread );
		
		processes[id].curr_thread = NULL;
		
    }
    else
    {
        /*
         * wait until an other thread collects me 
         */
		internal(1, " waiting for a thread to join me ");
        if( curr_thread != &main_thread )
            runq_append( &processes[id].joining_q, curr_thread );
		processes[id].curr_thread = NULL;
		
	}
    switch_thread( curr_thread, reactor );
}

int tap_thread_detach( tap_thread_t thread)
{
	if( !thread || !thread->joining_thread )
	{
		errno = EINVAL;
		return -EINVAL;
	}

	thread->flags |= TAP_DETACHED;
	return 0;
}

/*
 * thread creation
 */
_thread_t *tap_thread_create( void *( *start ) ( void *arg ), void *arg,
                              int flags )
{
    _thread_t *new_thread, *this;
    runq_t *run_q;
    int id;

	tap_yield();

    assert( start );
    id = get_id(  );
    /*
     * get run queue 
     */
    run_q = get_runq( id );
    this = get_thread( id );
    internal( 2, " create thread " );
    /*
     * create a thread object 
     */
    new_thread = create_thread_object( STK_SIZE );
    if( !new_thread )
        return NULL;
    /*
     * get a new context 
     */
    if( ctx_create( &new_thread->ctx, starter, ( void * )new_thread,
                    new_thread->stk ) )
    {
        internal( 0, " ctx_create failed !" );
        thread_destroy( new_thread );
        return NULL;
    }
    /*
     * init thread structure 
     */
    new_thread->tid = next_tid(  );
    new_thread->start_func = start;
    new_thread->start_data = arg;
    new_thread->parent = this;

	if(flags & TAP_DETACHED)
		new_thread->flags |= TAP_DETACHED;
    /*
     * init lists 
     */
    _init_thread_lists( new_thread );
    list_add_tail( &this->childs, &new_thread->siblings );
    /*
     * make thread runnable and insert it into the runqueue 
     */
    new_thread->state = RELEASED;
    runq_append( run_q, new_thread );
    process_inc_threads( id );
    internal( 0, "new thread %p, start %p, args %p", new_thread,
              new_thread->start_func, new_thread->start_data );
        
    return new_thread;
}

/*
 * wait for a thread and get its return value
 */
int tap_thread_join( _thread_t * thread, void **value )
{
    _thread_t *this = tap_thread_self(  );

	tap_yield();

	internal(1, "join thread %d %p", thread->tid, thread);
    if( !thread )
    {
        errno = ESRCH;
        return errno;
    }

    if( thread->state == DESTROYED || thread->flags & TAP_DETACHED  )
    {
        errno = EINVAL;
        return errno;
    }

    if( thread->joining_thread )
    {
        errno = EINVAL;
        return errno;
    }

    if( thread == this )
    {
        errno = EDEADLK;
        return errno;
    }

	if( thread->state != ZOMBIE )
	{
		internal(1, "thread not finished yet");
		thread->joining_thread = this;
		block( -1 );
	}
	
	internal(1, " thread is finished, joining retval %p", thread->retval);
	*value = thread->retval;
    thread_destroy( thread );
    return 0;
}

int tap_thread_cancel( _thread_t * thread )
{
    if( !thread )
    {
        errno = EINVAL;
        return -1;
    }

    thread->flags |= TAP_CANCELED;
    return 0;
}

void tap_thread_testcancel(  )
{
    _thread_t *this = tap_thread_self(  );
    if( this->flags & TAP_CANCELED )
    {
        tap_thread_exit( TAP_RETURN_CANCELED );
    }
}

int tap_setpriority( _thread_t * thread, int value )
{
    if( value > MAX_PRIORITY - 1 )
        value = MAX_PRIORITY - 1;
    else if( value < MIN_PRIORITY )
        value = MIN_PRIORITY;
    thread->priority = ( char )( 0xff & value );
    return 0;
}

int tap_getmaxpriority(  )
{
    return MIN_PRIORITY;
}

int tap_getminpriority(  )
{
    return MAX_PRIORITY - 1;
}
