/* Created by Anjuta version 1.2.4 */
/*	This file will not be overwritten */

#include <stdio.h>
int main(  )
{
    printf( "Hello world\n" );
    return ( 0 );
}
