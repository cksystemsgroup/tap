/* $Id: io.c,v 1.7 2006/04/28 13:18:16 hroeck Exp $ */

/* 
 * Copyright (c) Harald Roeck hroeck@cs.uni-salzburg.at 
 *
 * University Salzburg, www.uni-salzburg.at
 * Department of Computer Science, cs.uni-salzburg.at
 */

/*  
 *  This program is free software; you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation; either version 2 of the License, or
 *  (at your option) any later version.
 *
 *  This program is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 *
 *  You should have received a copy of the GNU General Public License
 *  along with this program; if not, write to the Free Software
 *  Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 *
 */
#ifndef _GNU_SOURCE
#define _GNU_SOURCE
#endif

//#ifndef _POSIX_SOURCE
//#define _POSIX_SOURCE
//#endif

#include "debug.h"
#include "threads_private.h"
#include "fd.h"

#include "process.h"
#include "timer.h"

#include <fcntl.h>
#include <errno.h>
#include <assert.h>

#include <libaio.h>             /* disc aio */
#include <sys/epoll.h>          /* new linux event polling */

// EPOLLONESHOT is sometimes(e.g. Debian) not defined
#ifndef EPOLLONESHOT
#define EPOLLONESHOT  (1<<30)
#endif

#include <sys/syscall.h>        /* syscall interface */
#include <unistd.h>
#include <asm/unistd.h>
#include <sys/socket.h>         /* socket calls */
#include <linux/net.h>
#include <stdio.h>

ssize_t tap_do_io( tap_io_t type, _fd_t * fd, void *buf, size_t count );

/* set the fd nonblocking */
static inline void fd_set_nb( int fd )
{
    int val = fcntl( fd, F_GETFL, 0 );
    fcntl( fd, F_SETFL, val | O_NONBLOCK );
}

/* set the fd blocking */
static inline void fd_set_bl( int fd )
{
    int val = fcntl( fd, F_GETFL, 0 );
    fcntl( fd, F_SETFL, val & ~O_NONBLOCK );
}

/*********************************************
 * internal wrappers for the socket system calls
 *********************************************/
#define __socketcall(call, args)	\
		syscall(SYS_socketcall, call, args)

static inline int _socket( int family, int type, int protocol )
{
    unsigned long args[3];

    args[0] = family;
    args[1] = type;
    args[2] = ( unsigned long )protocol;
    return __socketcall( SYS_SOCKET, args );
}

static inline int _accept( int s, struct sockaddr *addr, socklen_t * addrlen )
{
    unsigned long args[3];

    args[0] = s;
    args[1] = ( unsigned long )addr;
    args[2] = ( unsigned long )addrlen;
    return __socketcall( SYS_ACCEPT, args );
}

long os_accept( int fd, long sockaddr, long addrlen )
{
    return _accept( fd, ( struct sockaddr * )sockaddr,
                    ( socklen_t * ) addrlen );
}

static inline int _listen( int sockfd, int backlog )
{
    unsigned long args[2];

    args[0] = sockfd;
    args[1] = backlog;
    return __socketcall( SYS_LISTEN, args );
}

static inline int
_bind( int sockfd, const struct sockaddr *myaddr, socklen_t addrlen )
{
    unsigned long args[3];

    args[0] = sockfd;
    args[1] = ( unsigned long )myaddr;
    args[2] = addrlen;
    return __socketcall( SYS_BIND, args );
}

static inline int
_connect( int sockfd, const struct sockaddr *saddr, socklen_t addrlen )
{
    unsigned long args[3];

    args[0] = sockfd;
    args[1] = ( unsigned long )saddr;
    args[2] = addrlen;
    return __socketcall( SYS_CONNECT, args );
}

static inline int
_getpeername( int sockfd, struct sockaddr *addr, socklen_t * paddrlen )
{
    unsigned long args[3];

    args[0] = sockfd;
    args[1] = ( unsigned long )addr;
    args[2] = ( unsigned long )paddrlen;
    return __socketcall( SYS_GETPEERNAME, args );
}

static inline int
_getsockname( int sockfd, struct sockaddr *addr, socklen_t * paddrlen )
{
    unsigned long args[3];

    args[0] = sockfd;
    args[1] = ( unsigned long )addr;
    args[2] = ( unsigned long )paddrlen;
    return __socketcall( SYS_GETSOCKNAME, args );
}

static inline int
_getsockopt( int fd, int level, int optname, __ptr_t optval,
             socklen_t * optlen )
{
    unsigned long args[5];

    args[0] = fd;
    args[1] = level;
    args[2] = optname;
    args[3] = ( unsigned long )optval;
    args[4] = ( unsigned long )optlen;
    return ( __socketcall( SYS_GETSOCKOPT, args ) );
}

static inline ssize_t _recv( int sockfd, __ptr_t buffer, size_t len, int flags )
{
    unsigned long args[4];

    args[0] = sockfd;
    args[1] = ( unsigned long )buffer;
    args[2] = len;
    args[3] = flags;
    return ( __socketcall( SYS_RECV, args ) );
}

static inline ssize_t
_recvfrom( int sockfd, __ptr_t buffer, size_t len,
           int flags, struct sockaddr *to, socklen_t * tolen )
{
    unsigned long args[6];

    args[0] = sockfd;
    args[1] = ( unsigned long )buffer;
    args[2] = len;
    args[3] = flags;
    args[4] = ( unsigned long )to;
    args[5] = ( unsigned long )tolen;
    return ( __socketcall( SYS_RECVFROM, args ) );
}

static inline ssize_t _recvmsg( int sockfd, struct msghdr *msg, int flags )
{
    unsigned long args[3];

    args[0] = sockfd;
    args[1] = ( unsigned long )msg;
    args[2] = flags;
    return ( __socketcall( SYS_RECVMSG, args ) );
}

static inline ssize_t
_send( int sockfd, const void *buffer, size_t len, int flags )
{
    unsigned long args[4];

    args[0] = sockfd;
    args[1] = ( unsigned long )buffer;
    args[2] = len;
    args[3] = flags;
    return ( __socketcall( SYS_SEND, args ) );
}

static inline ssize_t
_sendmsg( int sockfd, const struct msghdr *msg, int flags )
{
    unsigned long args[3];

    args[0] = sockfd;
    args[1] = ( unsigned long )msg;
    args[2] = flags;
    return ( __socketcall( SYS_SENDMSG, args ) );
}

static inline ssize_t
_sendto( int sockfd, const void *buffer, size_t len,
         int flags, const struct sockaddr *to, socklen_t tolen )
{
    unsigned long args[6];

    args[0] = sockfd;
    args[1] = ( unsigned long )buffer;
    args[2] = len;
    args[3] = flags;
    args[4] = ( unsigned long )to;
    args[5] = tolen;
    return ( __socketcall( SYS_SENDTO, args ) );
}

static inline int
_setsockopt( int fd, int level, int optname,
             const void *optval, socklen_t optlen )
{
    unsigned long args[5];

    args[0] = fd;
    args[1] = level;
    args[2] = optname;
    args[3] = ( unsigned long )optval;
    args[4] = optlen;
    return ( __socketcall( SYS_SETSOCKOPT, args ) );
}

static inline int _shutdown( int sockfd, int how )
{
    unsigned long args[2];

    args[0] = sockfd;
    args[1] = how;
    return __socketcall( SYS_SHUTDOWN, args );
}

static inline int
_socketpair( int family, int type, int protocol, int sockvec[2] )
{
    unsigned long args[4];

    args[0] = family;
    args[1] = type;
    args[2] = protocol;
    args[3] = ( unsigned long )sockvec;
    return __socketcall( SYS_SOCKETPAIR, args );
}

static long os_read( int fd, long buf, long count )
{
    return syscall( __NR_read, fd, buf, count );
}

static long os_write( int fd, long buf, long count )
{
    return syscall( __NR_write, fd, buf, count );
}

static long os_open( long path, long flags, long mode )
{
    long retval;

    retval = syscall( SYS_open, path, flags, mode );

    return retval;
}

_fd_t *tap_open( const char *path, int flags, mode_t mode )
{
    _fd_t *fd;
    int osfd;
    int my_flags = 0;           // = O_DIRECT;

    internal( 4, "open file %s", path );

    osfd = os_open( ( long )path, ( long )( flags | my_flags ), ( long )mode );
    if( osfd < 0 )
    {
        internal( 4, "ERROR open file: %d %s", errno, strerror( errno ) );
        return NULL;
    }

    fd = fd_create( osfd, FD_FILE );
    if( !fd )
    {
        osfd = syscall( SYS_close, osfd );
        return NULL;
    }

    return fd;
}

ssize_t tap_close( _fd_t * fd )
{
    ssize_t retval;

    retval = syscall( SYS_close, fd->osfd );
    fd_destroy( fd );
    return retval;
}

/********************************************************
 *                net IO
 ********************************************************/
static inline int submit_accept( _fd_t * s )
{
    int op;
    struct epoll_event *event;
    int ret, epfd;

    epfd = get_epoll_fd( get_id(  ) );
    event = &s->u.sock.event;
    event->data.ptr = s;
    event->events = EPOLLIN | EPOLLONESHOT;

    if( !fd_submitted( s ) )
        op = EPOLL_CTL_ADD;
    else
        op = EPOLL_CTL_MOD;

    internal( 4, "submit fd %d to epoll", s->osfd );
    ret = epoll_ctl( epfd, op, s->osfd, event );
    if( ret )
    {
        internal( 4, " ERROR epoll_ctl %d: %d %s", ret, errno,
                  strerror( errno ) );
        return -1;
    }
    fd_set_submitted( s );
    internal( 4, "epoll_ctl returned %d", ret );
    fd_clear_done( s );
    return ret;
}

int tap_connect( tap_fd_t s, const struct sockaddr *saddr, socklen_t addrlen )
{
    return -1;
}

 /*
  * blocks current thread
  */
_fd_t *tap_accept( _fd_t * s, struct sockaddr * addr, socklen_t * addrlen )
{
    _fd_t *retval;
    int new_socket = -1;
    _thread_t *this = tap_thread_self(  );

    _thread_reset_priority( this );
	this->consumed_tokens = 0;

    assert( s->type == FD_SOCKET );

    internal( 4, "in tap_accept" );

    this->ncb.accept.addr = addr;
    this->ncb.accept.addrlen = addrlen;
    this->ncb.op = ACCEPT;
    this->ncb.fd = s;
    this->ncb.callback = os_accept;

    if( !s->thread )
    {
        s->thread = this;
        submit_accept( s );
    }
    else
        list_add_tail( &s->u.sock.accept_q, &this->io_q );

    block( -1 );

    assert( fd_done( s ) );

    /*
     * syscall is already done 
     */
    new_socket = this->ncb.result;

    if( new_socket == -1 )
    {
        internal( 4, "ERROR: systemcall accept failed: %d %s",
                  errno, strerror( errno ) );

        retval = NULL;
        goto out;
    }

    fd_set_nb( new_socket );
    retval = fd_create( new_socket, FD_SOCKET );

  out:

    if( list_empty( &s->u.sock.accept_q ) )
    {                           /* no other threads are accepting */
        internal( 4, "accept queue empty" );
        s->thread = NULL;
    }
    else
    {
        internal( 4, "get next thread from accept queue" );
        /*
         * connect next thread with this fd 
         */
        s->thread = list_entry( s->u.sock.accept_q.next, _thread_t, io_q );
        list_del_init( &s->thread->io_q );
        /*
         * resubmit accept for the next thread 
         */
        submit_accept( s );
    }

    if( !retval && new_socket > 0 )
    {
        internal( 4, "create FD failed" );
        syscall( SYS_close, new_socket );
        retval = NULL;
    }

    return retval;
}

/*
 * don't block
 */
int tap_listen( _fd_t * s, int backlog )
{
    return _listen( tap_osfd( s ), backlog );
}

/*
 * don't block
 */
_fd_t *tap_socket( int domain, int type, int protocol )
{
    _fd_t *retval;
    int socket;

    socket = _socket( domain, type, protocol );
    if( socket == -1 )
    {
        internal( 4, "ERROR: syscall socket failed, %d %s", errno,
                  strerror( errno ) );
        return NULL;
    }

    fd_set_nb( socket );
    retval = fd_create( socket, FD_SOCKET );
    if( !retval )
    {
        internal( 4, "create FD failed" );
        syscall( SYS_close, socket );
        return NULL;
    }

    return retval;
}

/*
 * don't block
 */
int tap_bind( _fd_t * s, const struct sockaddr *myaddr, socklen_t addrlen )
{
    return _bind( tap_osfd( s ), myaddr, addrlen );
}

ssize_t tap_read( tap_fd_t fd, void *buf, size_t count )
{
    ssize_t retval;

    retval = tap_do_io( READ, fd, buf, count );
    return retval;

}

ssize_t tap_write( tap_fd_t fd, const void *buf, size_t count )
{
    ssize_t retval;

    retval = tap_do_io( WRITE, fd, ( void * )buf, count );
    return retval;
}

/***********************************************************
 *                      socket epoll                       *
 ***********************************************************/
/* called by tap_io_init()
 * which is called by main_init
 */
static inline void epoll_init( int id )
{
    internal( 4, "epoll_init" );
    int epfd = epoll_create( _EPOLL_QUEUE_SIZE );
    struct epoll_event *events =
        malloc( sizeof( struct epoll_event ) * _EPOLL_MAX_EVENTS );

    process_set_epoll( id, epfd, events );
}

/* called by tap_io_destroy
 * which is called by main_exit
 */
static inline void epoll_destroy( int id )
{
    int epfd = get_epoll_fd( id );
    syscall( SYS_close, epfd );

    free( get_epoll_events( id ) );
}

static inline int epoll_cancel( int epfd, _fd_t * fd )
{
    struct epoll_event *event = NULL;
    int ret;
    internal( 4, "epoll remove fd %d", fd->osfd );
    ret = epoll_ctl( epfd, EPOLL_CTL_DEL, fd->osfd, event );
    if( ret )
    {
        internal( 4, " ERROR epoll_ctl %d: %d %s", ret, errno,
                  strerror( errno ) );
        return -1;
    }

    return 0;
}

/*
 * called by tap_do_rw(...)
 * which is called by a user thread
 */
static ssize_t epoll_rw( tap_io_t type, _fd_t * fd, void *buf, size_t count )
{

    _thread_t *thread = tap_thread_self(  );
    struct epoll_event *event;
    int op, ret, epfd;

    internal( 4, "in epoll_rw" );
    epfd = get_epoll_fd( get_id(  ) );

    /*
     * connect thread to this fd 
     */
    fd->thread = thread;
    /*
     * get the event mask for this fd 
     */
    event = &fd->u.sock.event;

    /*
     * check if fd was previously submitted 
     */
    if( fd_submitted( fd ) )
        op = EPOLL_CTL_MOD;     /* reactivate the fd */
    else
    {
        op = EPOLL_CTL_ADD;     /* add fd to event list */
        event->data.ptr = fd;
    }

    /*
     * is it input or output 
     */
    if( type == READ )
    {
        event->events = EPOLLIN;
        thread->ncb.callback = os_read;
    }
    else
    {
        event->events = EPOLLOUT;
        thread->ncb.callback = os_write;
    }
    /*
     * after the the event is collect
     * * the fd is internally disabled 
     */
    event->events |= EPOLLONESHOT | EPOLLERR | EPOLLHUP;

    internal( 4, "send fd %d to epoll ctl", fd->osfd );
    ret = epoll_ctl( epfd, op, fd->osfd, event );
    if( ret )
    {
        internal( 4, " ERROR epoll_ctl %d: %d %s", ret, errno,
                  strerror( errno ) );
        return -1;
    }
    fd_set_submitted( fd );
    fd_clear_done( fd );

    thread->ncb.op = type;
    thread->ncb.fd = fd;
    thread->ncb.rw.buf = buf;
    thread->ncb.rw.count = count;

    block( -1 );

    fd->thread = NULL;
    return thread->ncb.result;

}

static inline _thread_t *epoll_parse_event( struct epoll_event *event )
{

    _fd_t *fd;
    int events = event->events;

    fd = ( _fd_t * ) event->data.ptr;
    fd_set_done( fd );

    if( events & EPOLLIN || events & EPOLLPRI )
        sock_set_in( fd );
    else
        sock_clear_in( fd );

    if( events & EPOLLOUT )
        sock_set_out( fd );
    else
        sock_clear_out( fd );

    if( events & EPOLLERR || events & EPOLLHUP )
        sock_set_err( fd );
    else
        sock_clear_err( fd );

    return fd->thread;
}


static int disk_io_pending(  )
{
    return !token_queue_empty( get_id(  ), DISK_TOKEN );
}
static int net_io_pending(  )
{
    return !token_queue_empty( get_id(  ), NETWORK_TOKEN );
}

static int epoll_poll( struct list_head *list )
{
    int ready, i, timeout;
    _thread_t *thread;
    int epfd = get_epoll_fd( get_id(  ) );
    runq_t *net_token_wait, *disc_token_wait;
    struct epoll_event *_epoll_events = get_epoll_events( get_id(  ) );
    

    net_token_wait = get_token_queue( get_id(  ), NETWORK_TOKEN );
    disc_token_wait = get_token_queue( get_id(  ), DISK_TOKEN );

    if( net_io_pending(  ) || disk_io_pending(  ) )
    {
        if( tk_empty( NETWORK_TOKEN ) && tk_empty( DISK_TOKEN ) )
		{
		//	tap_usleep( 500 );
            timeout = 1;
		}
        else
            timeout = 0;
    }
    else
        timeout = -1;

    internal( 4, "use a timeout of %d for epoll_wait", timeout );
    ready = epoll_wait( epfd, _epoll_events, _EPOLL_MAX_EVENTS, timeout );

    if( ready == -1 )
        return -1;

    for( i = 0; i < ready; ++i )
    {
        thread = epoll_parse_event( _epoll_events + i );
        if( thread )
            runq_append( net_token_wait, thread );
    }
    
    return ready;
}

static inline ssize_t
disk_rw( tap_io_t type, _fd_t * fd, void *buf, size_t count )
{
    ssize_t retval = -1;
#if 0
    if( !tk_empty( DISK_TOKEN ) )
    {
        count = tk_allowed( DISK_TOKEN, count );

        switch ( type )
        {
        case READ:
            retval = os_read( fd->osfd, ( long )buf, ( long )count );
            break;
        case WRITE:
            retval = os_write( fd->osfd, ( long )buf, ( long )count );
            break;
        default:
            printf( "Error: %s line %d\n", __FUNCTION__, __LINE__ );
        }

        tk_del_token( DISK_TOKEN,
                      retval >> TOKEN_BITS ? retval >> TOKEN_BITS : 1 );

    }
    else
#endif
    {

        _thread_t *thread = tap_thread_self(  );
        runq_t *disc_token_wait =
            get_token_queue( get_id(  ), DISK_TOKEN );

        thread->dcb.fd = fd;
        thread->dcb.rw.buf = buf;
        thread->dcb.rw.count = count;
        thread->dcb.op = type;
        switch ( type )
        {
        case READ:
            thread->dcb.callback = os_read;
            break;
        case WRITE:
            thread->dcb.callback = os_write;
            break;
        default:
            printf( "Error: %s line %d\n", __FUNCTION__, __LINE__ );
        }

        runq_append( disc_token_wait, thread );
        block( -1 );
        retval = thread->dcb.result;
    }
    return retval;
}

#ifdef CALC_THROUGHPUT
static long disk_byte_count = 0;
static long net_byte_count = 0;
void calc_throughput(  )
{
    static tap_utime_t last;
    tap_utime_t new = tap_utime(  );
    tap_utime_t diff = new - last;

    if( diff > 500000 )         /* only update every half second */
    {
        long avg_disk, avg_net;
        diff = diff / 500000;
        last = new;

        avg_net = 2 * net_byte_count / diff;
        avg_disk = 2 * disk_byte_count / diff;

        fprintf( stderr, "disk %10ld\t net %10ld\n",
                 avg_disk>>10, avg_net>>10);
        disk_byte_count = 0;
        net_byte_count = 0;
    }
}
#else
void calc_throughput()
{

}
#endif
/*
 * the io multiplexer:
 *
 * push the threads in the io state machine
 * files -> aio
 * sockets/pipes -> epoll
 */
ssize_t tap_do_io( tap_io_t type, _fd_t * fd, void *buf, size_t count )
{
    ssize_t retval = -1;
    internal( 4, "do IO" );
    switch ( fd->type )
    {
    case FD_SOCKET:
    case FD_PIPE:
        internal( 4, " operation on socket/pipe " );
        retval = epoll_rw( type, fd, buf, count );
	#ifdef CALC_THROUGHPUT
        if( retval > 0 )
            disk_byte_count += retval;
	#endif
        break;
    case FD_FILE:
        internal( 4, " operation on file " );
        retval = disk_rw( type, fd, buf, count );
	#ifdef CALC_THROUGHPUT
        if( retval > 0 )
            net_byte_count += retval;
	#endif
        break;
    default:
        internal( 4, "unkown file type" );
    }

    fd->thread = NULL;
    return retval;
}

/***********************************************************
 *                  public io functions                    *
 ***********************************************************/
void tap_io_init( int id )
{    
    epoll_init( id );
}

void tap_io_destroy( int id )
{
    epoll_destroy( id );   
}

int tap_io_poll( struct list_head *list )
{
    int retval;
    internal( 4, "poll for finished threads" );
    retval = epoll_poll( list );

    
    return retval;
}
