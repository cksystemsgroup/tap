/* $Id: timer.c,v 1.5 2006/04/28 13:18:16 hroeck Exp $ */

/* 
 * Copyright (c) Harald Roeck hroeck@cs.uni-salzburg.at 
 *
 * University Salzburg, www.uni-salzburg.at
 * Department of Computer Science, cs.uni-salzburg.at
 */

/*  
 *  This program is free software; you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation; either version 2 of the License, or
 *  (at your option) any later version.
 *
 *  This program is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 *
 *  You should have received a copy of the GNU General Public License
 *  along with this program; if not, write to the Free Software
 *  Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 *
 */

#include "threads_private.h"
#include "timing.h"
#include "timer.h"
#include "process.h"

#include <syscall.h>
#include <string.h>

static int __tokens_per_second[MAX_RESOURCE] = { 10000, 10000 };
static tap_utime_t __last_tick[MAX_RESOURCE] = { 0, 0 };

static int limits[MAX_RESOURCE] = { 10000, 10000 };
static int tokens[MAX_RESOURCE];


static enum {
	TOKEN_BUCKET = 1,
	LEAKY_BUCKET,
} bucket;

#define  TOKENS_PER_SECOND  __tokens_per_second

#include <time.h>
#include <sys/time.h>

#include <stdio.h>
#include <unistd.h>
#include <errno.h>

static const char *const get_bucket_policy_name(int method)
{
	switch(method)
	{
		case TOKEN_BUCKET:
			return "Token Bucket";
		case LEAKY_BUCKET:
			return "Leaky Bucket";
		default:
			return "unknown";
	}
}

static char __filename_buf[64];
static void read_env(  )
{
    int result, value;
    char *env;
    int fd;
    FILE *file;
    char *filename = __filename_buf;
    char variable[16];

    env = getenv( "HOME" );
    if( env )
        snprintf( filename, sizeof( __filename_buf ), "%s/.%s", env,
                  CONF_FILE );
    else
        snprintf( filename, sizeof( __filename_buf ), "/etc/%s", CONF_FILE );

    fd = syscall( __NR_open, filename, O_RDONLY, 0 );
    if( fd == -1 )
    {
        perror( "ERROR in open configuration file" );
        return;
    }

    file = fdopen( fd, "r" );
    while ( ( result = fscanf( file, "%s = %d", variable, &value ) ) != EOF )
    {
        if( result != 2 )
            continue;
        if( !strncmp( variable, "TOKENS_NET", sizeof( variable ) ) )
        {
            TOKENS_PER_SECOND[0] = value;
            limits[0] = value;
			tokens[0] = value;
            printf( "set tokens for NET to %d\n", TOKENS_PER_SECOND[0] );
        }
        else if( !strncmp( variable, "TOKENS_DISK", sizeof( variable ) ) )
        {
            TOKENS_PER_SECOND[1] = value;
            limits[1] = value;
			tokens[1] = value;
            printf( "set tokens for DISK to %d\n", TOKENS_PER_SECOND[1] );
        }
        else if( !strncmp( variable, "PRIORITY_POLICY", sizeof( variable) ) )
		{
			if(value > 0 && value < 4 )
			{
				priority_policy = value;			
				printf(" set priority policy to %s\n", get_policy_name(value) );
			}
		}
		else if( !strncmp( variable, "BUCKET", sizeof( variable) ) )
		{
		
			if(value > 0 && value < 3 )
			{
				bucket = value;			
				printf(" set traffic shaping policy to %s\n", get_bucket_policy_name(value) );
			}
		}
		else
            printf( "unknown variable\n" );
    }
    fclose( file );
}

static void sig_usr1( int sig, siginfo_t * siginfo, void *uctx )
{
    read_env(  );
}

/* install signal handler
 * to read the TOKENS env variables
 */
static void install_sigusr1(  )
{
    struct sigaction act;
    stack_t stk;
    memset( &stk, 0, sizeof( stk ) );
    stk.ss_sp = malloc( MINSIGSTKSZ );
    if( !stk.ss_sp )
        perror( "malloc" );
    stk.ss_size = MINSIGSTKSZ;
    if( sigaltstack( &stk, NULL ) )
        perror( "sigaltstack" );
    memset( &act, 0, sizeof( act ) );
    act.sa_sigaction = sig_usr1;
    act.sa_flags = SA_SIGINFO | SA_ONSTACK;
    if( sigaction( SIGUSR1, &act, NULL ) )
        perror( "sigaction" );
}

void timer_init(  )
{
    tap_utime_t now = tap_utime(  );
    int i;
    read_env(  );
    install_sigusr1(  );
    for( i = 0; i < MAX_RESOURCE; ++i )
        __last_tick[i] = now;
}

/*
 * increases the tokens since the last call
 */
int tk_tick(  )
{
    tap_utime_t now = tap_utime(  );
    tap_utime_t diff;
    int add_tokens;
    int i;

    for( i = 0; i < MAX_RESOURCE; ++i )
    {
        diff = now - __last_tick[i];
        add_tokens = ( diff * TOKENS_PER_SECOND[i] ) / 1000000;
        if( add_tokens )
        {
			//tokens[i] = 0;
            tk_add_token( i, add_tokens );
			
            __last_tick[i] = now;
            internal( 5, " added %d; resource %d has %d tokens",
                      add_tokens, i, tokens[i] );

        }
    }
    return 0;
}

void timer_exit(  )
{

}

/*
 * returns true if there are no tokens for 
 * a specified resource
 */
int tk_empty( int resource )
{
    return tokens[resource] == 0;
}

/*
 * set the maximum number of tokens for a resource
 */
int tk_set_limit( int resource, int limit )
{
    int oldval;
    if( resource < 0 || resource > MAX_RESOURCE )
        return -EINVAL;
    oldval = limits[resource];
    limits[resource] = limit;
    return oldval;
}

/* return the number of tokens available
 * reset internal token count to zero
 */
int tk_get_token( int id )
{
    int retval;
    if( id >= MAX_RESOURCE || id < 0 )
        return -EINVAL;

    retval = tokens[id];
    tokens[id] = 0;

    return retval;
}

/*
 * add tokens to a resource
 */
int tk_add_token( int resource, int val )
{
    if( resource >= MAX_RESOURCE || resource < 0 )
        return -EINVAL;
    if( val < 0 )
    {
        internal( 5, " val negative" );
        return -EINVAL;
    }

	if(bucket == TOKEN_BUCKET)
		tokens[resource] += val;
	else if(bucket == LEAKY_BUCKET)
		tokens[resource] = val;
    
	if( tokens[resource] > limits[resource] )
        tokens[resource] = limits[resource];

    return 0;
}

int tk_allowed( int resource, int val )
{
    return tokens[resource] <
        val >> TOKEN_BITS ? tokens[resource] << TOKEN_BITS : val;
}

int tk_del_token( int resource, int val )
{
    int oldvalue;
    if( resource >= MAX_RESOURCE || resource < 0 )
        return -EINVAL;
    if( val < 0 )
    {
        internal( 5, " val negative" );
        return -EINVAL;
    }

    oldvalue = tokens[resource];
    tokens[resource] -= val;
    if( tokens[resource] < 0 )
        tokens[resource] = 0;

    return 0;
}
