/* $Id: timing.c,v 1.1.1.1 2006/04/11 14:01:22 hroeck Exp $ */

/* 
 * Copyright (c) Harald Roeck hroeck@cs.uni-salzburg.at 
 *
 * University Salzburg, www.uni-salzburg.at
 * Department of Computer Science, cs.uni-salzburg.at
 */

/*  
 *  This program is free software; you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation; either version 2 of the License, or
 *  (at your option) any later version.
 *
 *  This program is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 *
 *  You should have received a copy of the GNU General Public License
 *  along with this program; if not, write to the Free Software
 *  Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 *
 */

#define _POSIX_TIMERS

#include "timing.h"
#include "threads_private.h"
#include "posix_time.h"
#include <sys/time.h>
#include <time.h>
#include <stdio.h>

static tap_utime_t _clock;

static inline tap_utime_t get_utime(  )
{
    struct timeval tv;
    gettimeofday( &tv, NULL );
    return ( tv.tv_sec * 1000000LL + tv.tv_usec );
}

tap_utime_t tap_utime(  )
{
#ifdef NDEBUG
    return _clock;
#else
    return get_utime(  );
#endif
}

tap_utime_t tap_thread_sleep( tap_utime_t time )
{
    if( time <= 0 )
        return tap_utime(  );

    return block( time );
}

int clock_tick(  )
{
    _clock = get_utime(  );
    return 0;
}

int tap_usleep( tap_utime_t usecs )
{
    struct timespec _t;
    int retval;
    /*
     * just return for a certain threshold 
     */
    if( usecs < 20 )
        return 0;

    _t.tv_sec = usecs / 1000000LL;
    _t.tv_nsec = ( long )( 1000 * ( usecs % 1000000LL ) );

    internal( 2, " sleeping for %lld usecs", usecs );
    retval = nanosleep( &_t, NULL );

    clock_tick(  );
    return retval;
}

#ifdef __i386__
typedef long long _tap_clock_t;
_tap_clock_t _tap_clock(  )
{
    _tap_clock_t x;
    __asm__ volatile ( ".byte 0x0f, 0x31":"=A" ( x ) );
    return x;
}
#endif /* __i386__ */
