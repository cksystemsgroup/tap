
/* $Id: timer.h,v 1.3 2006/08/23 16:38:10 hroeck Exp $ */

/* 
 * Copyright (c) Harald Roeck hroeck@cs.uni-salzburg.at 
 *
 * University Salzburg, www.uni-salzburg.at
 * Department of Computer Science, cs.uni-salzburg.at
 */

/*  
 *  This program is free software; you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation; either version 2 of the License, or
 *  (at your option) any later version.
 *
 *  This program is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 *
 *  You should have received a copy of the GNU General Public License
 *  along with this program; if not, write to the Free Software
 *  Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 *
 */

#ifndef TIMER_H_
#define TIMER_H_

#define TOKEN_BITS      12      // a token is worth 4k i.e. 2^12

void timer_init(  );
void timer_exit(  );

/* return the frequency of the timer */
int timer_get_freq(  );

/* returns true if no tokens for resource are available */
int tk_empty( int resource );
/*
 * set the maximum number of tokens
 * for a resource
 */
int tk_set_limit( int resource, int limit );

/*
 * returns tokens for resource id;
 *  
 */
int tk_get_token( int id );

/* add val tokens to a resource */
int tk_add_token( int resource, int val );

/* delete val tokens from a resource */
int tk_del_token( int resource, int val );

int tk_allowed( int resource, int val );

int tk_rate(int resource );
/*
 * update tokens since last call
 */
int tk_tick(  );

/* wait until we have at least num tokens on any token queue */
tap_utime_t tk_wait( int num );
#endif /* TIMER_H_ */
