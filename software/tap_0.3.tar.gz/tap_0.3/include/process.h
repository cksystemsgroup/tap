/* $Id: process.h,v 1.2 2006/08/22 16:47:39 hroeck Exp $ */

/* 
 * Copyright (c) Harald Roeck hroeck@cs.uni-salzburg.at 
 *
 * University Salzburg, www.uni-salzburg.at
 * Department of Computer Science, cs.uni-salzburg.at
 */

/*  
 *  This program is free software; you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation; either version 2 of the License, or
 *  (at your option) any later version.
 *
 *  This program is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 *
 *  You should have received a copy of the GNU General Public License
 *  along with this program; if not, write to the Free Software
 *  Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 *
 */

#ifndef PROCESS_H
#define PROCESS_H

#include "threads.h"
#include "runq.h"
#include "timeoutq.h"

#include "list.h"

#include <libaio.h>             /* disc aio */
#include <sys/epoll.h>          /* new linux event polling */

#define MAX_PROC 1              /* support only one cpu */
#define MAX_RESOURCE 2
/*
 * representation of a process 
 */
typedef struct
{
    pid_t pid;
    int cpu_id;
    int active_threads;

    _thread_t *reactor;         /* a reactor per process */

    _thread_t *curr_thread;     /* running thread */

    runq_t run_q;               /* runq per process */
    runq_t zombie_q;            /* finished threads, waiting for clean up */

	runq_t joining_q;
    /*
     * list of threads waiting for tokens
     */
    runq_t token_wait[MAX_RESOURCE];
#define NETWORK_TOKEN   0
#define DISK_TOKEN      1

    /*
     * Timeout queue 
     */
    timeoutq_t timeout_q;

    /*
     * IO descriptors 
     */
    /*
     * for epoll;
     * network io 
     */
    int epoll_fd;
    struct epoll_event *epoll_events;

    /*
     * for linux aio;
     * disc io
     
     io_context_t aio_ctx;
     struct io_event *aio_events;
     struct iocb **aio_cbs;
     int active_cbs;
     */
} process_t;

extern process_t processes[MAX_PROC];

static inline int get_id(  )
{
    return 0;                   /* support only one process */
}

static inline void process_release( _thread_t * thread )
{
    internal( 3, " release thread [%d]", thread->tid );
	
		runq_append( &processes[get_id(  )].run_q, thread );
}

static inline int process_active_threads( int id )
{
    return processes[id].active_threads;
}

static inline void process_inc_threads( int id )
{
    ++processes[id].active_threads;
}

static inline void process_dec_threads( int id )
{
    --processes[id].active_threads;
}

/*
 * get the active thread of a specific process 
 */
static inline _thread_t *get_thread( int id )
{
    return processes[id].curr_thread;
}

static inline void clear_thread( int id )
{
    processes[id].curr_thread = NULL;
}

static inline timeoutq_t *get_timeoutq( int id )
{
    return &processes[id].timeout_q;
}

/*
 * get the reactor thread of a specific process 
 */
static inline _thread_t *get_reactor( int id )
{
    return processes[id].reactor;
}

/*
 * get the runqueue of a specific process 
 */
static inline runq_t *get_runq( int id )
{
    return &processes[id].run_q;
}

static inline runq_t *get_token_queue( int id, int resource )
{
    if( resource < 0 || resource > MAX_RESOURCE )
        return NULL;

    return &processes[id].token_wait[resource];
}

static inline int get_max_priority( int id )
{
    int retval, i;

    retval = runq_priority( get_runq( id ) );

    for( i = 0; i < MAX_RESOURCE; ++i )
    {
        if( runq_priority( processes[id].token_wait + i ) > retval )
            retval = runq_priority( processes[id].token_wait + i );
    }
    return retval;
}

static inline int token_queue_empty( int id, int resource )
{
    if( resource < 0 || resource > MAX_RESOURCE )
        return -EINVAL;

    return runq_empty( processes[id].token_wait + resource );
}

/*
 * get the runqueue of a specific process 
 */
static inline runq_t *get_zombieq( int id )
{
    return &processes[id].zombie_q;
}

static inline runq_t *get_joiningq( int id )
{
	return &processes[id].joining_q;
}

static inline int get_epoll_fd( int id )
{
    return processes[id].epoll_fd;
}

static inline struct epoll_event *get_epoll_events( int id )
{
    return processes[id].epoll_events;
}

static inline void process_set_epoll( int id, int epfd, struct epoll_event *ev )
{
    processes[id].epoll_fd = epfd;
    processes[id].epoll_events = ev;

}

#endif
