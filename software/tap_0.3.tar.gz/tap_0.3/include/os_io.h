/* $Id: os_io.h,v 1.1.1.2 2006/08/14 18:04:44 hroeck Exp $ */

/* 
 * Copyright (c) Harald Roeck hroeck@cs.uni-salzburg.at 
 *
 * University Salzburg, www.uni-salzburg.at
 * Department of Computer Science, cs.uni-salzburg.at
 */

/*  
 *  This program is free software; you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation; either version 2 of the License, or
 *  (at your option) any later version.
 *
 *  This program is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 *
 *  You should have received a copy of the GNU General Public License
 *  along with this program; if not, write to the Free Software
 *  Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 *
 */

#ifndef _OS_IO_H
#define _OS_IO_H

#include <sys/syscall.h>        /* syscall interface */
#include <unistd.h>
#include <asm/unistd.h>
#include <sys/socket.h>         /* socket calls */
#include <linux/net.h>
#include <stdio.h>

/* set the fd nonblocking */
static inline void fd_set_nb( int fd )
{
    int val = fcntl( fd, F_GETFL, 0 );
    fcntl( fd, F_SETFL, val | O_NONBLOCK );
}

/* set the fd blocking */
static inline void fd_set_bl( int fd )
{
    int val = fcntl( fd, F_GETFL, 0 );
    fcntl( fd, F_SETFL, val & ~O_NONBLOCK );
}

/*********************************************
 * internal wrappers for the socket system calls
 *********************************************/
#define __socketcall(call, args)	\
		syscall(SYS_socketcall, call, args)

static inline int _socket( int family, int type, int protocol )
{
    unsigned long args[3];

    args[0] = family;
    args[1] = type;
    args[2] = ( unsigned long )protocol;
    return __socketcall( SYS_SOCKET, args );
}

static inline int _accept( int s, struct sockaddr *addr, socklen_t * addrlen )
{
    unsigned long args[3];

    args[0] = s;
    args[1] = ( unsigned long )addr;
    args[2] = ( unsigned long )addrlen;
    return __socketcall( SYS_ACCEPT, args );
}

static inline int _listen( int sockfd, int backlog )
{
    unsigned long args[2];

    args[0] = sockfd;
    args[1] = backlog;
    return __socketcall( SYS_LISTEN, args );
}

static inline int
_bind( int sockfd, const struct sockaddr *myaddr, socklen_t addrlen )
{
    unsigned long args[3];

    args[0] = sockfd;
    args[1] = ( unsigned long )myaddr;
    args[2] = addrlen;
    return __socketcall( SYS_BIND, args );
}

static inline int
_connect( int sockfd, const struct sockaddr *saddr, socklen_t addrlen )
{
    unsigned long args[3];

    args[0] = sockfd;
    args[1] = ( unsigned long )saddr;
    args[2] = addrlen;
    return __socketcall( SYS_CONNECT, args );
}

static inline int
_getpeername( int sockfd, struct sockaddr *addr, socklen_t * paddrlen )
{
    unsigned long args[3];

    args[0] = sockfd;
    args[1] = ( unsigned long )addr;
    args[2] = ( unsigned long )paddrlen;
    return __socketcall( SYS_GETPEERNAME, args );
}

static inline int
_getsockname( int sockfd, struct sockaddr *addr, socklen_t * paddrlen )
{
    unsigned long args[3];

    args[0] = sockfd;
    args[1] = ( unsigned long )addr;
    args[2] = ( unsigned long )paddrlen;
    return __socketcall( SYS_GETSOCKNAME, args );
}

static inline int
_getsockopt( int fd, int level, int optname, __ptr_t optval,
             socklen_t * optlen )
{
    unsigned long args[5];

    args[0] = fd;
    args[1] = level;
    args[2] = optname;
    args[3] = ( unsigned long )optval;
    args[4] = ( unsigned long )optlen;
    return ( __socketcall( SYS_GETSOCKOPT, args ) );
}

static inline ssize_t _recv( int sockfd, __ptr_t buffer, size_t len, int flags )
{
    unsigned long args[4];

    args[0] = sockfd;
    args[1] = ( unsigned long )buffer;
    args[2] = len;
    args[3] = flags;
    return ( __socketcall( SYS_RECV, args ) );
}

static inline ssize_t
_recvfrom( int sockfd, __ptr_t buffer, size_t len,
           int flags, struct sockaddr *to, socklen_t * tolen )
{
    unsigned long args[6];

    args[0] = sockfd;
    args[1] = ( unsigned long )buffer;
    args[2] = len;
    args[3] = flags;
    args[4] = ( unsigned long )to;
    args[5] = ( unsigned long )tolen;
    return ( __socketcall( SYS_RECVFROM, args ) );
}

static inline ssize_t _recvmsg( int sockfd, struct msghdr *msg, int flags )
{
    unsigned long args[3];

    args[0] = sockfd;
    args[1] = ( unsigned long )msg;
    args[2] = flags;
    return ( __socketcall( SYS_RECVMSG, args ) );
}

static inline ssize_t
_send( int sockfd, const void *buffer, size_t len, int flags )
{
    unsigned long args[4];

    args[0] = sockfd;
    args[1] = ( unsigned long )buffer;
    args[2] = len;
    args[3] = flags;
    return ( __socketcall( SYS_SEND, args ) );
}

static inline ssize_t
_sendmsg( int sockfd, const struct msghdr *msg, int flags )
{
    unsigned long args[3];

    args[0] = sockfd;
    args[1] = ( unsigned long )msg;
    args[2] = flags;
    return ( __socketcall( SYS_SENDMSG, args ) );
}

static inline ssize_t
_sendto( int sockfd, const void *buffer, size_t len,
         int flags, const struct sockaddr *to, socklen_t tolen )
{
    unsigned long args[6];

    args[0] = sockfd;
    args[1] = ( unsigned long )buffer;
    args[2] = len;
    args[3] = flags;
    args[4] = ( unsigned long )to;
    args[5] = tolen;
    return ( __socketcall( SYS_SENDTO, args ) );
}

static inline int
_setsockopt( int fd, int level, int optname,
             const void *optval, socklen_t optlen )
{
    unsigned long args[5];

    args[0] = fd;
    args[1] = level;
    args[2] = optname;
    args[3] = ( unsigned long )optval;
    args[4] = optlen;
    return ( __socketcall( SYS_SETSOCKOPT, args ) );
}

static inline int _shutdown( int sockfd, int how )
{
    unsigned long args[2];

    args[0] = sockfd;
    args[1] = how;
    return __socketcall( SYS_SHUTDOWN, args );
}

static inline int
_socketpair( int family, int type, int protocol, int sockvec[2] )
{
    unsigned long args[4];

    args[0] = family;
    args[1] = type;
    args[2] = protocol;
    args[3] = ( unsigned long )sockvec;
    return __socketcall( SYS_SOCKETPAIR, args );
}

static inline long _read( int fd, void *buf, long count )
{
    return syscall( __NR_read, fd, buf, count );
}

static inline long _write( int fd, const void *buf, long count )
{
    return syscall( __NR_write, fd, buf, count );
}

static inline long _open( long path, long flags, long mode )
{
    return syscall( SYS_open, path, flags, mode );
}

static inline long _close( int fd )
{
    return syscall( SYS_close, fd );
}

#undef __socketcall

#endif /* _OS_IO_H */
