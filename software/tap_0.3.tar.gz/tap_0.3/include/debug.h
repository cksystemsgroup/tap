/* $Id: debug.h,v 1.1.1.1 2006/08/14 08:49:03 hroeck Exp $ */

/* 
 * Copyright (c) Harald Roeck hroeck@cs.uni-salzburg.at 
 *
 * University Salzburg, www.uni-salzburg.at
 * Department of Computer Science, cs.uni-salzburg.at
 */

/*  
 *  This program is free software; you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation; either version 2 of the License, or
 *  (at your option) any later version.
 *
 *  This program is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 *
 *  You should have received a copy of the GNU General Public License
 *  along with this program; if not, write to the Free Software
 *  Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 *
 */

#ifndef DEBUG_H
#define DEBUG_H

#include "threads.h"

#ifndef NDEBUG
int debug_init(  );
int debug_exit(  );
int debug( int level, const char *format, ... )
    __attribute__ ( ( format( printf, 2, 3 ) ) );

int __internal( int level, const char *format, ... )
    __attribute__ ( ( format( printf, 2, 3 ) ) );

#define internal(level,form, ...) __internal(level, "%s %d\t" form, __FILE__, __LINE__, ##__VA_ARGS__)

void tap_error( char *str );
#else
/* don't use any debug output */

/* all functions do nothing */
static inline int debug_init(  )
{
    return 0;
}

static inline int debug_exit(  )
{
    return 0;
}

static inline int debug( int level, const char *format, ... )
{
    return 0;
}

static inline int internal( int level, const char *format, ... )
{
    return 0;
}

static inline void tap_error( char *str )
{

}

#endif

#endif
