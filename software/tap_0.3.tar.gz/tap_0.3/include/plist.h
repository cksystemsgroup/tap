/* $Id: plist.h,v 1.1.1.1 2006/08/14 08:49:03 hroeck Exp $ */

/* 
 * Copyright (c) Harald Roeck hroeck@cs.uni-salzburg.at 
 *
 * University Salzburg, www.uni-salzburg.at
 * Department of Computer Science, cs.uni-salzburg.at
 */

/*
 *  This program is free software; you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation; either version 2 of the License, or
 *  (at your option) any later version.
 *
 *  This program is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 *
 *  You should have received a copy of the GNU General Public License
 *  along with this program; if not, write to the Free Software
 *  Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 *
 */

#ifndef plist_H
#define plist_H

#include "list.h"
#include "threads_private.h"

/* the plistueue */
typedef struct
{
    struct list_head lists[MAX_PRIORITY - MIN_PRIORITY];
    int len;
} plist_t;

/* 
 *	plist is a pointer to a queue
 *	thr is the pointer to the actual thread
 */
#define plist_foreach(list, thr)	\
		list_for_each_entry(thr, list, queue)

/*
 * init the plist;
 */
static inline int plist_init( plist_t * plist )
{
    int i;
    int length = MAX_PRIORITY - MIN_PRIORITY;

    plist->len = length;
    for( i = 0; i < length; ++i )
        INIT_LIST_HEAD( plist->lists + i );

    return 0;
}

/* 
 * returns true if plist is empty
 */
static inline int plist_empty( plist_t * plist )
{
    int i;

    for( i = 0; i < plist->len; ++i )
        if( !list_empty( plist->lists + i ) )
            return 0;

    return 1;
}

static inline int plist_destroy( plist_t * plist )
{
    if( !plist_empty( plist ) )
        return 1;

    return 0;
}

/*
 *	return the number or priorities
 */
static inline int plist_length( plist_t * plist )
{
    return plist->len;
}

/*
 * append a thread at the end of the plist
 */
static inline int plist_append( plist_t * plist, _thread_t * thr )
{
    if( thr->priority > MAX_PRIORITY )
    {
        errno = EINVAL;
        return 1;
    }

    list_add_tail( plist->lists + ( thr->priority - MIN_PRIORITY ), &thr->queue );
    return 0;
}

/*
 * get the next thread 
 * and remove it from the plist
 */
static inline _thread_t *plist_next( plist_t * plist )
{
    _thread_t *thr = NULL;
    int i;

    for( i = 0; i < plist->len; ++i )
        if( !list_empty( plist->lists + i ) )
        {
            thr = list_entry( plist->lists[i].next, _thread_t, queue );
            list_del_init( &thr->queue );
            break;
        }

    return thr;
}

/*
 * print the plist
 * for debugging
 */
static inline void plist_print( plist_t * plist )
{
    _thread_t *thr;
    int i;

    for( i = 0; i < plist->len; ++i )
        plist_foreach( plist->lists + i, thr )
    {
        internal( 0, " --> [%d]", thr->tid );
    }
}

#endif
