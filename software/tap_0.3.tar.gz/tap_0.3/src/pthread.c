/* $Id: pthread.c,v 1.3 2006/08/23 16:38:10 hroeck Exp $*/

/* 
 * Copyright (c) Petru Flueras petru.flueras@cs.uni-salzburg.at 
 *
 * University Salzburg, www.uni-salzburg.at
 * Department of Computer Science, cs.uni-salzburg.at
 */

/*  
 *  This program is free software; you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation; either version 2 of the License, or
 *  (at your option) any later version.
 *
 *  This program is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 *
 *  You should have received a copy of the GNU General Public License
 *  along with this program; if not, write to the Free Software
 *  Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 *
 */

#include "pthread.h"
#include "threads.h"
#include "hashtable.h"
#include "pthread_private.h"
#include "mutex.h"
#include "cond.h"

#include <stdio.h>              /* included only for printf messages */
#include <errno.h>
#include <string.h>


#ifdef TAP_PTHREAD


#ifdef OK
#undef OK
#endif
#define OK	0

#ifdef FAIL
#undef FAIL
#endif
#define FAIL	0

extern int errno;
extern hashtable thread_hash;

void static set_errno( int error )
{
    errno = error;
}

/*
 * Hash functions
 */
static _pthread_t *thread_hash_get( hashtable * hash, int key )
{
    _pthread_t *current;
    unsigned hash_no = hash->get_hash( key );

    if( hash_entry_empty( &( hash->hash_list[hash_no] ) ) )
        return NULL;

    list_for_each_entry( current, &( hash->hash_list[hash_no] ), queue )
    {
        if( current->tap_thread_id == key )
            return current;
    }

    return NULL;
}

static _pthread_t *thread_hash_rem( hashtable * hash, int key )
{
    _pthread_t *current;
    unsigned hash_no = hash->get_hash( key );

    internal( 6, "Remove hash key (thread) -%u-", hash_no );
    current = thread_hash_get( hash, key );
    if( current )
        hash_rem( &current->queue );

    return current;
}

/*
 * Thread attribute routines 
 */
int pthread_attr_init( pthread_attr_t * attr )
{
    memset( attr, 0, sizeof( *attr ) );
    return 0;
}

int pthread_attr_destroy( pthread_attr_t * attr )
{
    return 0;
}

int pthread_attr_setdetachstate( pthread_attr_t * attr, int detachstate )
{
    if( !attr )
    {
        errno = EINVAL;
        return -errno;
    }
    if( detachstate == PTHREAD_ATTR_DETACH )
        attr->flags |= PTHREAD_ATTR_DETACH;

    return 0;
}

/*
 * Thread routines
 */
int pthread_cancel( pthread_t thread )
{
    // FIXME not yet implemented
    return FAIL;
}

int pthread_detach( pthread_t thread )
{
    return tap_thread_detach( thread->tap_thread );
}

int pthread_create( pthread_t * thread, const struct _pthread_attr_st *attr,
                    void *( *start_routine ) ( void * ), void *arg )
{

    _pthread_t *t;
    int flags = 0;

    if( attr )
        flags = attr->flags;

    if( thread == NULL || start_routine == NULL )
    {
        set_errno( EINVAL );
        return FAIL;
    }

    t = ( _pthread_t * ) malloc( sizeof( _pthread_t ) );
    t->tap_thread = tap_thread_create( start_routine, arg, flags );
    internal( 9, "Created thread: %p", t->tap_thread );

    if( t->tap_thread == NULL )
    {
        set_errno( ENOMEM );
        return FAIL;
    }

    t->tap_thread_id = tap_thread_getid( t->tap_thread );
    if( t->tap_thread_id == -1 )
    {
        // the thread was lunched and terminated already
        // this error is fixed
        free( t );
        *thread = NULL;
    }
    else
    {
        hash_put( &thread_hash, t->tap_thread_id, &( t->queue ) );
        *thread = t;
    }

    return OK;
}

int pthread_equal( pthread_t pt1, pthread_t pt2 )
{
    _pthread_t *t1 = ( _pthread_t * ) pt1;
    _pthread_t *t2 = ( _pthread_t * ) pt2;

	if( !t1 || !t2 )
		return 0;

    if( t1->tap_thread == t2->tap_thread )
        return 1;
    else
        return 0;
}

void pthread_exit( void *retval )
{
    // printf("-- pthread_exit --\n");
    unsigned tap_thread_id = ( unsigned )tap_getid(  );
    _pthread_t *t;

    if( tap_thread_id > 0 )
    {
        while ( ( t =
                  ( _pthread_t * ) thread_hash_rem( &thread_hash,
                                                    tap_thread_id ) ) == NULL )
        {
            // the thread was lunched and
            // now is terminating before the pthread_create
            // succeeds to add this thread to thread_hash
            internal( 9, "yield !!!" );
            tap_yield(  );
            continue;
        }

        internal( 9, "Exiting thread: %p", t->tap_thread );
        free( t );
    }

    tap_thread_exit( retval );
}

int pthread_join( pthread_t thread, void **ret_val )
{
    return tap_thread_join( thread->tap_thread, ret_val );
}

pthread_t pthread_self(  )
{
    // FIXME problems for the main thread
    unsigned tap_thread_id = ( unsigned )tap_getid(  );
    _pthread_t *current;

    while ( ( current =
              ( _pthread_t * ) thread_hash_get( &thread_hash,
                                                tap_thread_id ) ) == NULL )
    {
        internal( 9, "yield !!!" );
        tap_yield(  );
    }

    return ( pthread_t ) current;
}

int sched_yield(  )
{
    tap_yield(  );
    return 0;
}

unsigned int sleep( unsigned int seconds )
{
    tap_thread_sleep( seconds * 1000 );
    return 0;
}

/* Thread synchronization routines */

/************************************************
 *            Mutex functions
 ************************************************/
int pthread_mutex_init( pthread_mutex_t * mut,
                        const pthread_mutexattr_t * mutexattr )
{
    return tap_mutex_init( ( struct _mutex ** )mut );
}

int pthread_mutex_lock( pthread_mutex_t * mutex )
{
    return tap_mutex_lock( *( struct _mutex ** )mutex );
}

int pthread_mutex_trylock( pthread_mutex_t * mutex )
{
    return tap_mutex_trylock( *( struct _mutex ** )mutex );
}

int pthread_mutex_unlock( pthread_mutex_t * mutex )
{
    return tap_mutex_unlock( *( struct _mutex ** )mutex );
}

int pthread_mutex_destroy( pthread_mutex_t * mutex )
{
    return tap_mutex_destroy( ( struct _mutex ** )mutex );
}

/************************************************
 *         condition variables functions
 ************************************************/

int pthread_cond_init( pthread_cond_t * cond, pthread_condattr_t * cond_attr )
{
    return tap_cond_init( ( struct _cond ** )cond );
}

int pthread_cond_signal( pthread_cond_t * cond )
{
    return tap_cond_signal( *( struct _cond ** )cond );
}

int pthread_cond_broadcast( pthread_cond_t * cond )
{
    return tap_cond_broadcast( *( struct _cond ** )cond );
}

int pthread_cond_wait( pthread_cond_t * cond, pthread_mutex_t * mutex )
{
    return tap_cond_wait( *( struct _cond ** )cond, *( struct _mutex ** )mutex );
}

int pthread_cond_timedwait( pthread_cond_t * cond, pthread_mutex_t * mutex,
                            const struct timespec *abstime )
{
    tap_utime_t time, now;

    now = tap_utime(  );
    time = abstime->tv_sec * 1000000;
    time += abstime->tv_nsec / 1000;

	time = time - now;
	if(time < 0)
		time = 0;
    return tap_cond_timedwait( *( struct _cond ** )cond,
                               *( struct _mutex ** )mutex, time );
}

int pthread_cond_destroy( pthread_cond_t * cond )
{
    return tap_cond_destroy( ( struct _cond ** )cond );
}

/*****************************************************
 *               scheduler functions
 *****************************************************/

int pthread_setschedparam( pthread_t thread, int policy,
                           const struct sched_param *param )
{
    int tap_priority;

    tap_priority = param->sched_priority;
    tap_setpriority( thread->tap_thread, tap_priority );
    return 0;
}

int sched_get_priority_max( int policy )
{
    return tap_getmaxpriority(  );
}

int sched_get_priority_min( int policy )
{
    return tap_getminpriority(  );
}
#endif
