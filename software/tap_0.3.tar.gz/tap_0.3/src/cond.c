
/* $Id: cond.c,v 1.1.1.1 2006/08/14 08:49:03 hroeck Exp $*/

/* 
 * Copyright (c) Harald Roeck hroeck@cs.uni-salzburg.at 
 *
 * University Salzburg, www.uni-salzburg.at
 * Department of Computer Science, cs.uni-salzburg.at
 */

/*  
 *  This program is free software; you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation; either version 2 of the License, or
 *  (at your option) any later version.
 *
 *  This program is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 *
 *  You should have received a copy of the GNU General Public License
 *  along with this program; if not, write to the Free Software
 *  Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 *
 */

#include "cond.h"
#include "errno.h"

#include "threads_private.h"
#include "process.h"

int tap_cond_init( struct _cond **c )
{
	struct _cond *retval = malloc(sizeof( struct _cond ));
    internal( 6, "%s", __FUNCTION__ );
    
	if( retval )
    {
        INIT_LIST_HEAD( &retval->threads );
        retval->m = NULL;
    }
	else
		return ENOMEM;
	
	*c = retval;
    return 0;
}

int tap_cond_destroy( struct _cond **c )
{
    internal( 6, "%s", __FUNCTION__ );
    if( !c || !*c || !list_empty( &(*c)->threads ) )
    {
        internal( 6, " cond_destroy: threads still waiting" );
        return EBUSY;

    }
	free(*c);
    return 0;
}

int tap_cond_wait( struct _cond *c, struct _mutex *m )
{
    internal( 6, "%s", __FUNCTION__ );
    return tap_cond_timedwait( c, m, -1 );
}

int tap_cond_timedwait( struct _cond *c, struct _mutex *m,
                        tap_utime_t expiration )
{
    _thread_t *this = tap_thread_self(  );

    internal( 6, "%s", __FUNCTION__ );
    if( !c )
    {
        internal( 6, " no cond variable" );
        return EINVAL;

    }
    if( !m || m->thread == NULL || ( m->thread != this ) )
    {
        internal( 6, "cond_wait: mutex not locked" );
        return EINVAL;

    }

    if( c->m == NULL )
        c->m = m;
    else if( c->m != m )
    {
        internal( 6, "cond_wait: wrong mutex supplied %p", m );
        return EINVAL;

    }
    list_add_tail( &c->threads, &this->queue );
    tap_mutex_unlock( m );
    block( expiration );

    /*
     * check if we got the mutex 
     */
    if( m->thread == NULL || ( m->thread != this ) )
    {
        internal( 6, "cond_wait: did not get the mutex, try again!!" );
        return tap_mutex_lock( m );
    }
    return 0;
}

int tap_cond_signal( struct _cond *c )
{
    internal( 6, "%s", __FUNCTION__ );
    if( !c )
    {
        internal( 6, "wrong cond var" );
        return EINVAL;

    }
    if( list_empty( &c->threads ) )
        return 0;

    _thread_t *next;
    next = list_entry( c->threads.next, _thread_t, queue );
    list_del( &next->queue );

    if( c->m->thread == NULL )
    {
        c->m->thread = next;
		next->state = RELEASED;
        process_release( next );
    }
    else
    {
        list_add_tail( &c->m->list, &next->queue );
    }
    return 0;
}

int tap_cond_broadcast( struct _cond *c )
{
    internal( 6, "%s", __FUNCTION__ );
    if( !c )
    {
        internal( 6, "wrong cond var" );
        return EINVAL;

    }

    while ( !list_empty( &c->threads ) )
    {
        tap_cond_signal( c );
    }
    return 0;
}
