/* $Id: debug.c,v 1.1.1.1 2006/08/14 08:49:03 hroeck Exp $ */

/* 
 * Copyright (c) Harald Roeck hroeck@cs.uni-salzburg.at 
 *
 * University Salzburg, www.uni-salzburg.at
 * Department of Computer Science, cs.uni-salzburg.at
 */

/*  
 *  This program is free software; you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation; either version 2 of the License, or
 *  (at your option) any later version.
 *
 *  This program is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 *
 *  You should have received a copy of the GNU General Public License
 *  along with this program; if not, write to the Free Software
 *  Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 *
 */

#include "threads_private.h"

#include "debug.h"
#include "timing.h"
#include <stdio.h>
#include <unistd.h>
#include <stdarg.h>
#include <sys/syscall.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <fcntl.h>

#ifndef NDEBUG

#define BUF_SIZE 256
#define MAX_FILES 10

#define DBG_FDS 0
#define INT_FDS 1

static int _files[2][MAX_FILES];
static int init = 0;

/*
 * open files
 */
int debug_init(  )
{
    if( !init )
    {
        int i;
        char filename[32];
        for( i = 0; i < MAX_FILES; ++i )
        {
            snprintf( filename, 32, "debug.%d", i );
            _files[DBG_FDS][i] = syscall( SYS_open, filename,
                                          O_CREAT | O_WRONLY | O_TRUNC,
                                          S_IRUSR | S_IWUSR );

            snprintf( filename, 32, "internal.%d", i );
            _files[INT_FDS][i] = syscall( SYS_open, filename,
                                          O_CREAT | O_WRONLY | O_TRUNC,
                                          S_IRUSR | S_IWUSR );
        }

        init = 1;
    }

    return 0;
}

/*
 * close files
 */
int debug_exit(  )
{
    if( init )
    {
        int i;
        for( i = 0; i < MAX_FILES; ++i )
        {
            syscall( SYS_close, _files[DBG_FDS][i] );
            syscall( SYS_close, _files[INT_FDS][i] );
        }
    }
    return 0;
}

/*
 * write message to the correct file
 */
static int do_io( int dest, int level, const char *format, va_list argptr )
{
    char buf[BUF_SIZE];
    int n, write_len, tid;
    // _thread_t *curr_thread;

    if( !init )
        return 0;

    level %= MAX_FILES;

    tid = tap_thread_self(  )? tap_thread_self(  )->tid : -1;
    n = snprintf( buf, BUF_SIZE, "[%5d] %lld ", tid, tap_utime(  ) );
    n += vsnprintf( buf + n, BUF_SIZE - n, format, argptr );

    if( n > BUF_SIZE )
    {
        n = BUF_SIZE;
        buf[n - 1] = '\n';
    }
    else
    {
        buf[n++] = '\n';
    }

    write_len = 0;
    while ( write_len < n )
        write_len += syscall( SYS_write, _files[dest][level],
                              buf + write_len, n - write_len );

    return write_len;
}

int debug( int level, const char *format, ... )
{
    int n;
    va_list argptr;

    va_start( argptr, format );

    n = do_io( DBG_FDS, level, format, argptr );

    va_end( argptr );
    return n;
}

int __internal( int level, const char *format, ... )
{
    int n;
    va_list argptr;

    va_start( argptr, format );

    n = do_io( INT_FDS, level, format, argptr );

    va_end( argptr );
    return n;
}

void tap_error( char *str )
{
    char buf[BUF_SIZE];
    int n, write_len;
    n = snprintf( buf, BUF_SIZE, " ERROR: %s \n", str );

    write_len = 0;
    while ( write_len < n )
        write_len += syscall( SYS_write, 2, buf + write_len, n - write_len );
    exit( 1 );
}

#endif
