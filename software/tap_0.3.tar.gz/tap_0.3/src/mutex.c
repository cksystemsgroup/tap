
/* $Id: mutex.c,v 1.1.1.1 2006/08/14 08:49:03 hroeck Exp $*/

/* 
 * Copyright (c) Harald Roeck hroeck@cs.uni-salzburg.at 
 *
 * University Salzburg, www.uni-salzburg.at
 * Department of Computer Science, cs.uni-salzburg.at
 */

/*  
 *  This program is free software; you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation; either version 2 of the License, or
 *  (at your option) any later version.
 *
 *  This program is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 *
 *  You should have received a copy of the GNU General Public License
 *  along with this program; if not, write to the Free Software
 *  Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 *
 */

/*******************************************************/
/*******************************************************/
/*               not tested yet                        */
/*******************************************************/
/*******************************************************/

#include "threads_private.h"
#include "process.h"
#include "mutex.h"

#include <errno.h>
#include <string.h>

int tap_mutex_init( struct _mutex **m )
{
    struct _mutex *retval = malloc( sizeof( struct _mutex ) );
 //   internal(6, "%s", __FUNCTION__);
	if( !retval )
    {
        return -1;
    }
    INIT_LIST_HEAD( &retval->list );
    retval->thread = NULL;

    *m = retval;
//	internal(6, "mutex created at %p", retval);
    return 0;
}

int tap_mutex_destroy( struct _mutex **m )
{
    struct _mutex *mutex = *m;
// internal(6, "%s mutex %p", __FUNCTION__, mutex);
    if( mutex->thread != NULL )
    {
        errno = EBUSY;

        return -1;
    }

    free( mutex );
    *m = NULL;
    return 0;
}

int tap_mutex_lock( struct _mutex *m )
{
    _thread_t *this = tap_thread_self(  );

//	internal(6, "%s mutex %p", __FUNCTION__, m);
    if( m->thread == this )
    {
		internal(6, "mutex already locked by me");
        errno = EDEADLK;
        return -1;
    }

    if( m->thread == NULL )
    {
//		internal(6, "aquire mutex");
        m->thread = this;
    }
    else
    {
//		internal(6, "mutex already locked by %p", m->thread);
        list_add_tail( &m->list, &this->queue );
        block( -1 );
        assert( m->thread == this );
    }

    return 0;
}

int tap_mutex_trylock( struct _mutex *m )
{
	 _thread_t *this = tap_thread_self(  );
// internal(6, "%s mutex %p", __FUNCTION__, m);
	if( m->thread == NULL )
    {
        m->thread = this;
		return 0;
    }
	
	return EBUSY;
}

int tap_mutex_unlock( struct _mutex *m )
{
    _thread_t *this = tap_thread_self(  );
    _thread_t *next;

//internal(6, "%s mutex %p", __FUNCTION__, m);

    if( m->thread == NULL || m->thread != this )
    {
        errno = EPERM;
        return -1;
    }

    if( !list_empty( &m->list ) )
    {
        next = list_entry( m->list.next, _thread_t, queue );
        list_del( &next->queue );
        m->thread = next;
		next->state = RELEASED;
        process_release( next );
    }
    else
        m->thread = NULL;

    return 0;
}
