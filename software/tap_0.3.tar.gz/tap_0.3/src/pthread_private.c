/* $Id: pthread_private.c,v 1.1.1.1 2006/08/14 08:49:03 hroeck Exp $*/

/* 
 * Copyright (c) Petru Flueras petru.flueras@cs.uni-salzburg.at 
 *
 * University Salzburg, www.uni-salzburg.at
 * Department of Computer Science, cs.uni-salzburg.at
 */

/*  
 *  This program is free software; you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation; either version 2 of the License, or
 *  (at your option) any later version.
 *
 *  This program is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 *
 *  You should have received a copy of the GNU General Public License
 *  along with this program; if not, write to the Free Software
 *  Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 *
 */

#include "pthread_private.h"
#include "posix_io.h"
#include "hashtable.h"

// the key is type int - the id of the thread
// the value is typeof - _pthread_t
hashtable thread_hash;

unsigned get_hash( int key )
{
    // FIXME for big number no * (no + 3) => overflow
    long long result;

    result = key * ( key + 3 ) % MAX;
    internal( 8, "Get_Hash key: -%d- value: -%lld-", key, result );
    return ( unsigned )result;
}

/*
 * Initialize pthread stuff
 */
void pthread_initialize(  )
{
    hash_init( &thread_hash, get_hash );
    internal( 9, "pthread intialized successfull" );
    posix_io_initialize(  );
}

/*
 * Cleanup
 */
void pthread_finalize(  )
{
    posix_io_finalize(  );
    internal( 9, "pthread finalized successfull" );
}
