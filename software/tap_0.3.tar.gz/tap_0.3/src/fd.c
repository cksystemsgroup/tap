/* $Id: fd.c,v 1.2 2006/08/21 17:14:56 hroeck Exp $ */

/* 
 * Copyright (c) Harald Roeck hroeck@cs.uni-salzburg.at 
 *
 * University Salzburg, www.uni-salzburg.at
 * Department of Computer Science, cs.uni-salzburg.at
 */

/*  
 *  This program is free software; you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation; either version 2 of the License, or
 *  (at your option) any later version.
 *
 *  This program is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 *
 *  You should have received a copy of the GNU General Public License
 *  along with this program; if not, write to the Free Software
 *  Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 *
 */

#include "fd.h"
#include <unistd.h>
#include <stdio.h>

/*
 * FIXME use more sophisticated system
 * alloc in blocks of fds ...
 */

/* FIXME use locking to access free list 
 * to support SMP and preemption
 */
static LIST_HEAD( free_list );

/*
 * get the next fd from the free list 
 * or return NULL
 */
static inline _fd_t *fd_next(  )
{
    _fd_t *retval;

    if( list_empty( &free_list ) )
        return NULL;

    retval = list_entry( free_list.next, _fd_t, u.free_list );
    list_del( free_list.next );
    return retval;
}

/*
 * push fd in free list
 */
static inline void fd_push( _fd_t * fd )
{
    list_add( &free_list, &fd->u.free_list );
}

/*
 * return a pointer to an empty file descriptor
 */
_fd_t *fd_create( int osfd, _fd_type type )
{
    _fd_t *retval;

    internal( 4, "create new fd, osfd %d, type %d", osfd, type );
    retval = fd_next(  );
    if( !retval )
        retval = ( _fd_t * ) malloc( sizeof( _fd_t ) );

    if( !retval )
        return NULL;

    memset( retval, 0, sizeof( _fd_t ) );
    retval->state = FREE;
    retval->type = type;
    retval->osfd = osfd;

    if( type == FD_SOCKET || type == FD_PIPE )
    {
        INIT_LIST_HEAD( &retval->u.sock.accept_q );
        retval->u.sock.ready = SOCK_IN | SOCK_OUT;
    }

    return retval;
}

_fd_t *fd_new( int fd )
{
    tap_fd_t tap_fd;
    struct stat _stat;
    if( fstat( fd, &_stat ) == -1 )
        return NULL;

    internal( 9, " fd %d not in hashtable attempt to create a tap_fd", fd );
    if( S_ISSOCK( _stat.st_mode ) )
    {
        internal( 9, "fd %d is a socket", fd );
        
        tap_fd = fd_create( fd, FD_SOCKET );
    }
    else if( S_ISFIFO( _stat.st_mode ) )
    {
        internal( 9, "fd %d is a FIFO", fd );
     
        tap_fd = fd_create( fd, FD_PIPE );
    }
    else if( S_ISREG( _stat.st_mode ) )
    {
        internal( 9, "fd %d is a regular file", fd );
    
        tap_fd = fd_create( fd, FD_FILE );
    }
	else if( S_ISCHR( _stat.st_mode ) )
    {
        internal( 9, "fd %d is a character device", fd );
    
        tap_fd = fd_create( fd, FD_CHR );
    }
    else
    {
        internal( 9, "unknown file type" );	
        return NULL;
    }
    return tap_fd;

}

/*
 * delete a filedescriptor
 */
int fd_destroy( _fd_t * fd )
{

    fd->state = FREE;

    fd_push( fd );
    return 0;
}

int tap_osfd( _fd_t * fd )
{
    if( fd )
        return fd->osfd;

    else
        return -1;
}
