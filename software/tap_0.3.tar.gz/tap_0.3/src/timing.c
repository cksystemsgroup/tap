/* $Id: timing.c,v 1.4 2006/08/22 16:47:39 hroeck Exp $ */

/* 
 * Copyright (c) Harald Roeck hroeck@cs.uni-salzburg.at 
 *
 * University Salzburg, www.uni-salzburg.at
 * Department of Computer Science, cs.uni-salzburg.at
 */

/*  
 *  This program is free software; you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation; either version 2 of the License, or
 *  (at your option) any later version.
 *
 *  This program is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 *
 *  You should have received a copy of the GNU General Public License
 *  along with this program; if not, write to the Free Software
 *  Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 *
 */

#define _POSIX_TIMERS

#include "timing.h"
#include "threads_private.h"
#include "posix_time.h"
#include <sys/time.h>
#include <time.h>
#include <stdio.h>

static tap_utime_t _clock;
static tap_utime_t next_poll;


static inline tap_utime_t get_utime(  )
{
    struct timeval tv;
	
    gettimeofday( &tv, NULL );
    return ( tv.tv_sec * 1000000LL + tv.tv_usec );
}

tap_utime_t tap_utime(  )
{

    return _clock;

}

tap_utime_t tap_thread_sleep( tap_utime_t time )
{
	tap_utime_t retval, now;
	_thread_t *thr = tap_thread_self();

	internal(2, "tap_thread_sleep %lld", time);
    if( time <= 500 )
        return tap_utime(  );

	now = tap_utime( );
    retval = block( time );
	thr->flags &= ~TAP_TIMEDOUT;
//	printf(" requested %10lld slept %10lld jitter: %5lld ms\n", time, retval -now, ((retval-now) - time)/1000 );
	return retval;
}

int clock_tick(  )
{
	tap_utime_t old = _clock;
    _clock = get_utime(  );
//	fprintf(stderr , "advanced %lld usecs\n", _clock - old );
/*
	if( _clock >= next_poll ) 
	{
		force_poll = 1;
		next_poll = _clock + 1000LL;
	}
*/
    return 0;
}

int tap_usleep( tap_utime_t usecs )
{
    struct timespec _t, rem;
    int retval = 0;
	
    /*
     * just return for a certain threshold 
     */
    if( usecs < 20 )
        return 0;

    rem.tv_sec = usecs / 1000000LL;
    rem.tv_nsec = ( long )( 1000 * ( usecs % 1000000LL ) );

    internal( 2, " sleeping for %lld usecs", usecs );
	do
	{
		_t.tv_sec = rem.tv_sec;
		_t.tv_nsec = rem.tv_nsec;
		rem.tv_sec = 0;
		rem.tv_nsec = 0;
		
		retval = nanosleep( &_t, &rem );
		
	}
	while( retval == -1 && errno == EINTR );
	
    clock_tick(  );
    return retval;
}

#ifdef __i386__

_tap_clock_t _tap_clock(  )
{
    _tap_clock_t x;
    __asm__ volatile ( ".byte 0x0f, 0x31":"=A" ( x ) );
    return x;
}
#else
_tap_clock_t _tap_clock()
{
	return 0;
}
#endif /* __i386__ */
