/* $Id: posix_io.c,v 1.3 2006/08/21 17:14:56 hroeck Exp $*/

/* 
 * Copyright (c) Petru Flueras petru.flueras@cs.uni-salzburg.at 
 *
 * University Salzburg, www.uni-salzburg.at
 * Department of Computer Science, cs.uni-salzburg.at
 */

/*  
 *  This program is free software; you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation; either version 2 of the License, or
 *  (at your option) any later version.
 *
 *  This program is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 *
 *  You should have received a copy of the GNU General Public License
 *  along with this program; if not, write to the Free Software
 *  Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 *
 */

#include "posix_io.h"
#include "hashtable.h"
#include "threads.h"
#include "pthread_private.h"
#include "os_io.h"
#include "fd.h"
#include <stdarg.h>
#include <sys/select.h>
#include <sys/time.h>
#include <errno.h>

#define DO_SELECT

static hashtable hash_fd;

/*
 * If the key exists in the kash return the value
 * otherwise return NULL
 */
static _posix_fd_t *posix_hash_get( hashtable * hash, int key )
{
    _posix_fd_t *current;
    unsigned hash_no = hash->get_hash( key );

    internal( 7, "elem-%p- prev-%p- next-%p-",
              &( hash->hash_list[hash_no] ),
              hash->hash_list[hash_no].prev, hash->hash_list[hash_no].next );

    internal( 8, "key: -%d- value: -%u-", key, hash_no );
    if( hash_entry_empty( &( hash->hash_list[hash_no] ) ) )
        return NULL;

    list_for_each_entry( current, &( hash->hash_list[hash_no] ), queue )
    {
        if( current->os_fd == key )
            return current;
    }

    return NULL;
}

static _posix_fd_t *posix_hash_rem( hashtable * hash, int key )
{
    _posix_fd_t *current;
    unsigned hash_no = hash->get_hash( key );

    internal( 6, "Remove hash key (posix) -%u-", hash_no );
    current = posix_hash_get( hash, key );
    if( current )
        hash_rem( &current->queue );

    return current;
}

/*
 * Intialization and finalization area
 */
void posix_io_initialize(  )
{
    hash_init( &hash_fd, get_hash );
    internal( 9, "posix io intialized successfull" );
}

void posix_io_finalize(  )
{
    internal( 9, "posix io finalized successfull" );
}

/*
 * Override system calls
 */
int open( const char *path, int flags, ... )
{
    va_list ap;
    int os_fd;
    mode_t mode = 0;
    tap_fd_t tap_fd;
    _posix_fd_t *posix_fd;

    internal( 9, "Executing open" );
    // get the mode
    va_start( ap, flags );
    if( flags & O_CREAT )
        mode = ( mode_t ) va_arg( ap, mode_t );

    va_end( ap );

    tap_fd = tap_open( path, flags, mode );
    if( !tap_fd )
    {
        internal( 9, "Error open" );
        return -1;
    }

    os_fd = tap_osfd( tap_fd );
    posix_fd = ( _posix_fd_t * ) malloc( sizeof( _posix_fd_t ) );
    posix_fd->os_fd = os_fd;
    posix_fd->tap_fd = tap_fd;

    internal( 9, "Got os_fd: -%d- Address: -%p-", os_fd, posix_fd );
    hash_put( &hash_fd, posix_fd->os_fd, &( posix_fd->queue ) );

    return os_fd;
}

int creat( const char *path, mode_t mode )
{
    return open( path, O_CREAT | O_TRUNC | O_WRONLY, mode );
}
extern int force_poll;
ssize_t read( int fd, void *buf, size_t count )
{
    _posix_fd_t *posix_fd;

    internal( 9, "Executing read" );
    posix_fd = posix_hash_get( &hash_fd, fd );
    if( !posix_fd )
    {
        tap_fd_t tap_fd;

        tap_fd = fd_new( fd );
        if( tap_fd )
        {
            posix_fd = ( _posix_fd_t * ) malloc( sizeof( _posix_fd_t ) );
            if( !posix_fd )
            {
                fd_destroy( tap_fd );
                return -1;
            }
            posix_fd->os_fd = fd;
            posix_fd->tap_fd = tap_fd;
            internal( 9, "Got os_fd: -%d- Address: -%p-", fd, posix_fd );
            hash_put( &hash_fd, posix_fd->os_fd, &( posix_fd->queue ) );
        }
        else
            return -1;
        /*
         * force_poll = 1; tap_yield( ); return _read( fd, buf, count
         * ); 
         */
    }

    internal( 9, "Read from fd: -%d- Address: -%p- Bytes %d", fd,
              posix_fd, count );
    return tap_read( posix_fd->tap_fd, buf, count );
}

ssize_t write( int fd, const void *buf, size_t count )
{
    _posix_fd_t *posix_fd;
    internal( 9, "Executing write" );
	
    posix_fd = posix_hash_get( &hash_fd, fd );
    if( !posix_fd )
    {

        tap_fd_t tap_fd;
        tap_fd = fd_new( fd );

        if( tap_fd )
        {
            posix_fd = ( _posix_fd_t * ) malloc( sizeof( _posix_fd_t ) );
            if( !posix_fd )
            {
                fd_destroy( tap_fd );
                return -1;
            }
            posix_fd->os_fd = fd;
            posix_fd->tap_fd = tap_fd;
            internal( 9, "Got os_fd: -%d- Address: -%p-", fd, posix_fd );
            hash_put( &hash_fd, posix_fd->os_fd, &( posix_fd->queue ) );
        }
        else
		{
			
            return -1;
		}
    }

    internal( 9, "Write to fd: -%d- Address: -%p- Bytes %d", fd,
              posix_fd, count );
    return tap_write( posix_fd->tap_fd, buf, count );
}

int close( int filedes )
{
    _posix_fd_t *posix_fd;
    tap_fd_t tap_fd;
    internal( 9, "Executing close" );
    posix_fd = posix_hash_rem( &hash_fd, filedes );
    if( !posix_fd )
    {
        internal( 9, "Error close. Rem hash failed" );
        tap_yield(  );
        return _close( filedes );
    }
    else
    {
        tap_fd = posix_fd->tap_fd;
        free( posix_fd );
        return tap_close( tap_fd );
    }
}

/* ********** Socket routines ************ */

int accept( int s, struct sockaddr *addr, socklen_t * addrlen )
{
    _posix_fd_t *posix_fd, *new_posix_fd;
    tap_fd_t new_tap_fd;
    int new_os_fd;
    internal( 9, "Executing accept" );
    posix_fd = posix_hash_get( &hash_fd, s );
    if( !posix_fd )
    {
        internal( 9, "Error accept. Get hash failed" );
        return -1;
    }

    new_tap_fd = tap_accept( posix_fd->tap_fd, addr, addrlen );
    if( !new_tap_fd )
        return -1;
    new_os_fd = tap_osfd( new_tap_fd );
    new_posix_fd = ( _posix_fd_t * ) malloc( sizeof( _posix_fd_t ) );
    new_posix_fd->tap_fd = new_tap_fd;
    new_posix_fd->os_fd = new_os_fd;
    hash_put( &hash_fd, new_posix_fd->os_fd, &( new_posix_fd->queue ) );
    return new_os_fd;
}

int bind( int sockfd, const struct sockaddr *myaddr, socklen_t addrlen )
{
    _posix_fd_t *posix_fd;
    internal( 9, "Executing bind" );
    posix_fd = posix_hash_get( &hash_fd, sockfd );
    if( !posix_fd )
    {
        internal( 9, "Error bind. Get hash failed" );
        return _bind( sockfd, myaddr, addrlen );
    }

    return tap_bind( posix_fd->tap_fd, myaddr, addrlen );
}

int connect( int sockfd, const struct sockaddr *saddr, socklen_t addrlen )
{
    _posix_fd_t *posix_fd;
    internal( 9, "Executing connect" );
    posix_fd = posix_hash_get( &hash_fd, sockfd );
    if( !posix_fd )
    {
        internal( 9, "Error connect. Get hash failed" );
        return _connect( sockfd, saddr, addrlen );
    }

    return tap_connect( posix_fd->tap_fd, saddr, addrlen );
}

int listen( int sockfd, int backlog )
{
    _posix_fd_t *posix_fd;
    internal( 9, "Executing %s", __FUNCTION__ );
    posix_fd = posix_hash_get( &hash_fd, sockfd );
    if( !posix_fd )
    {
        internal( 9, "Error %s. Get hash failed", __FUNCTION__ );
        return _listen( sockfd, backlog );
    }

    return tap_listen( posix_fd->tap_fd, backlog );
}

ssize_t recv( int sockfd, __ptr_t buffer, size_t len, int flags )
{
    _posix_fd_t *posix_fd;
    internal( 9, "Executing %s", __FUNCTION__ );
    posix_fd = posix_hash_get( &hash_fd, sockfd );
    if( !posix_fd )
    {
        internal( 9, "Error %s. Get hash failed", __FUNCTION__ );
        return _recv( sockfd, buffer, len, flags );
    }
    return tap_recv( posix_fd->tap_fd, buffer, len, flags );
}

ssize_t recvfrom( int sockfd, __ptr_t buffer, size_t len,
                  int flags, struct sockaddr * to, socklen_t * tolen )
{
    _posix_fd_t *posix_fd;
    internal( 9, "Executing %s", __FUNCTION__ );
    posix_fd = posix_hash_get( &hash_fd, sockfd );
    if( !posix_fd )
    {
        internal( 9, "Error %s. Get hash failed", __FUNCTION__ );
        return _recvfrom( sockfd, buffer, len, flags, to, tolen );
    }
    return tap_recvfrom( posix_fd->tap_fd, buffer, len, flags, to, tolen );
}

ssize_t recvmsg( int sockfd, struct msghdr * msg, int flags )
{
    _posix_fd_t *posix_fd;
    internal( 9, "Executing %s", __FUNCTION__ );
    posix_fd = posix_hash_get( &hash_fd, sockfd );
    if( !posix_fd )
    {
        internal( 9, "Error %s. Get hash failed", __FUNCTION__ );
        return _recvmsg( sockfd, msg, flags );
    }
    return tap_recvmsg( posix_fd->tap_fd, msg, flags );
}

ssize_t send( int sockfd, const void *buffer, size_t len, int flags )
{
    _posix_fd_t *posix_fd;
	ssize_t retval;
    internal( 9, "Executing %s", __FUNCTION__ );
    posix_fd = posix_hash_get( &hash_fd, sockfd );
    if( !posix_fd )
    {
        internal( 9, "Error %s. Get hash failed", __FUNCTION__ );
        return _send( sockfd, buffer, len, flags );
    }
    retval = tap_send( posix_fd->tap_fd, buffer, len, flags );
//	printf("send returned %d\n", retval);
	return retval;
}

ssize_t sendmsg( int sockfd, const struct msghdr * msg, int flags )
{
    _posix_fd_t *posix_fd;
    internal( 9, "Executing %s", __FUNCTION__ );
    posix_fd = posix_hash_get( &hash_fd, sockfd );
    if( !posix_fd )
    {
        internal( 9, "Error %s. Get hash failed", __FUNCTION__ );
        return _sendmsg( sockfd, msg, flags );
    }
    return tap_sendmsg( posix_fd->tap_fd, msg, flags );
}

ssize_t sendto( int sockfd, const void *buffer, size_t len,
                int flags, const struct sockaddr * to, socklen_t tolen )
{
    _posix_fd_t *posix_fd;
    internal( 9, "Executing %s", __FUNCTION__ );
    posix_fd = posix_hash_get( &hash_fd, sockfd );
    if( !posix_fd )
    {
        internal( 9, "Error %s. Get hash failed", __FUNCTION__ );
        return _sendto( sockfd, buffer, len, flags, to, tolen );
    }
    return tap_sendto( posix_fd->tap_fd, buffer, len, flags, to, tolen );
}

int socket( int family, int type, int protocol )
{
    _posix_fd_t *posix_fd;
    tap_fd_t tap_fd;
    int os_fd;
    internal( 9, "Executing socket" );
    tap_fd = tap_socket( family, type, protocol );
    if( !tap_fd )
    {
        internal( 9, "Error socket" );
        return -1;
    }

    os_fd = tap_osfd( tap_fd );
    posix_fd = ( _posix_fd_t * ) malloc( sizeof( _posix_fd_t ) );
    posix_fd->os_fd = os_fd;
    posix_fd->tap_fd = tap_fd;
    hash_put( &hash_fd, posix_fd->os_fd, &posix_fd->queue );
    return os_fd;
}

#ifdef DO_SELECT

static void build_fd_list( int nfds, fd_set * fds, tap_fd_t * list )
{
    int i;
    _posix_fd_t *posix_fd;
    for( i = 0; i < nfds; ++i )
        if( FD_ISSET( i, fds ) )
        {
            internal( 4, "add %d to fd list", i );
            posix_fd = posix_hash_get( &hash_fd, i );
            if( !posix_fd )
            {
                internal( 9, "Error build_fd_list. Get hash failed" );
                posix_fd = ( _posix_fd_t * ) malloc( sizeof( _posix_fd_t ) );
                posix_fd->os_fd = i;
                posix_fd->tap_fd = fd_create( i, FD_SOCKET );
                hash_put( &hash_fd, posix_fd->os_fd, &posix_fd->queue );
            }
            *list++ = posix_fd->tap_fd;
        }
}

static void _build_fdset( int nfds, tap_fd_t * tfds, fd_set * fds )
{
    int i;
    FD_ZERO( fds );
    for( i = 0; i < nfds; ++i )
    {
        if( tfds[i] )
		{
			
            FD_SET( i, fds );
		}
    }
}

int select( int nfds, fd_set * rfds, fd_set * wfds,
            fd_set * efds, struct timeval *timeout )
{
    int num, count;
    tap_fd_t *tap_rfds, *tap_wfds, *tap_efds, *__fds;
    tap_utime_t tout = 0;
    internal( 9, "\t%s %p %p %p", __FUNCTION__, rfds, wfds, efds );
    num = 0;
    if( rfds )
        ++num;
    if( wfds )
        ++num;
    if( efds )
        ++num;
    if( num )
    {
        tap_rfds = malloc( num * nfds * sizeof( tap_fd_t ) );
        if( !tap_rfds )
        {
            errno = ENOMEM;
            return -1;
        }
        __fds = tap_rfds;
        memset( tap_rfds, 0, num * nfds * sizeof( tap_fd_t ) );
        tap_wfds = tap_efds = tap_rfds;
        if( rfds )
        {
            tap_wfds += nfds;
            tap_efds += nfds;
            build_fd_list( nfds, rfds, tap_rfds );
        }
        else
            tap_rfds = NULL;
        if( wfds )
        {
            tap_efds += nfds;
            build_fd_list( nfds, wfds, tap_wfds );
        }
        else
            tap_wfds = NULL;
        if( efds )
        {
            build_fd_list( nfds, efds, tap_efds );
        }
        else
            tap_efds = NULL;
    }
    else
        tap_wfds = tap_efds = tap_rfds = __fds = NULL;
    if( timeout )
    {
        tout = timeout->tv_usec;
        tout += timeout->tv_sec * 1000000;
    }

    count = tap_select( nfds, tap_rfds, tap_wfds, tap_efds, tout );
    if( rfds )
        _build_fdset( nfds, tap_rfds, rfds );
	
    if( wfds )
        _build_fdset( nfds, tap_wfds, wfds );
	
    if( efds )
        _build_fdset( nfds, tap_efds, efds );
    if( num )
    {
        free( __fds );
    }
    return count;
}
#endif
