
#include "ShapingPanel.h"
#include "AvailableMetersPanel.h"
#include "MetersPanel.h"
#include "DisplayOptionsPanel.h"
#include "ColumnsPanel.h"
#include "ColorsPanel.h"
#include "AvailableColumnsPanel.h"
#include "Process.h"

#include "Panel.h"

#include "debug.h"
#include <assert.h>
#include <tap.h>


/*{

typedef struct ShapingPanel_ {
   Panel super;

   Settings* settings;
   ScreenManager* scr;
   Process* p;
} ShapingPanel;


typedef struct DevicePanel_ {
   Panel super;

   Settings* settings;
   ScreenManager* scr;
   Process* p;
   int resource;
} DevicePanel;



typedef struct SubDevicesPanel_ {
   Panel super;

   Settings* settings;
   ScreenManager* scr;
   Process* p;
} SubDevicesPanel;


#define MODE_BITS 3

typedef struct ShapingModePanel_ {
   Panel super;

   Settings* settings;
   ScreenManager* scr;
   bool check[MODE_BITS];
   Process* p;
} ShapingModePanel;


typedef struct EnableShapingPanel_ {
   Panel super;

   Settings* settings;
   ScreenManager* scr;
   bool enable;
   Process* p;
} EnableShapingPanel;

typedef struct InfoShapingPanel_ {
   Panel super;

   Settings* settings;
   ScreenManager* scr;
   Process* p;
} InfoShapingPanel;

}*/


static char* SShapingModeFunctions[10] = {"      ", "      ", "      ", "      ", "      ", "      ", "      ", "      ", "      ", "Done  "};

static char* SEnableShapingFunctions[10] = {"      ", "      ", "      ", "      ", "      ", "      ", "      ", "      ", "      ", "Done  "};

static char* SDevicesFunctions[10] = {"Reset", " +    ", " -    ", "      ", "      ", "      ", "      ", "      ", "      ", "Done  "};


char* deviceFunctions[2] = {"Exit  ", " New Value: "};
int deviceEvents[3] = {13, 27, ERR};
char* deviceKeys[2] = {"Enter", "Esc"};

static char* ReadWriteModeNames[] = {
   "",
   "Write",
   NULL
};


static char* ShapingModeSchemes[] = {
   "Share table with child",
   "Shape resource",
   "Shape read/write independently",
   NULL
};



EnableShapingPanel* EnableShapingPanel_new(Settings* settings, ScreenManager* scr, Process* p) {
   EnableShapingPanel* this = (EnableShapingPanel*) malloc(sizeof(EnableShapingPanel));
   Panel* super = (Panel*) this;
   Panel_init(super, 1, 1, 1, 1, CHECKITEM_CLASS, true);
   ((Object*)this)->delete = EnableShapingPanel_delete;

   this->settings = settings;
   this->scr = scr;
   this->p = p;
   super->eventHandler = EnableShapingPanel_EventHandler;

   Panel_setHeader(super, "Ativate Shaping");

   // FIXME : set this->enable true or false depending on active shaping or not
   if( p->shaping )
     this->enable = true;
   else 
     this->enable = false;
   Panel_add(super, (Object*) CheckItem_new(String_copy("Enable"), &(this->enable)));
   return this;
}

void EnableShapingPanel_delete(Object* object) {
   Panel* super = (Panel*) object;
   EnableShapingPanel* this = (EnableShapingPanel*) object;
   Panel_done(super);
   free(this);
}

HandlerResult EnableShapingPanel_EventHandler(Panel* super, int ch) {
   EnableShapingPanel* this = (EnableShapingPanel*) super;
   
   HandlerResult result = IGNORED;
   //CheckItem* selected = (CheckItem*) Panel_getSelected(super);

   switch(ch) {
   case 0x0a:
   case 0x0d:
   case KEY_ENTER:
   case ' ':
      this->enable = ! this->enable;	
      result = HANDLED;
   }

   if (result == HANDLED) {
      //this->settings->changed = true;
	// FIXME : shaping : enable or disable shaping for process



      if(this->enable) {
        if(Process_setShape(this->p, this->p->smode))
		this->p->shaping = true;
      }
      else {
	if( Process_unsetShape(this->p) )
	        this->p->shaping = false;
      }
      Header* header = this->settings->header;
      Header_calculateHeight(header);
      Header_draw(header);
      ScreenManager_resize(this->scr, this->scr->x1, header->height, this->scr->x2, this->scr->y2);
   }
   return result;
}




ShapingModePanel* ShapingModePanel_new(Settings* settings, ScreenManager* scr, Process* p) {
   ShapingModePanel* this = (ShapingModePanel*) malloc(sizeof(ShapingModePanel));
   Panel* super = (Panel*) this;
   Panel_init(super, 1, 1, 1, 1, CHECKITEM_CLASS, true);
   int i;
   ((Object*)this)->delete = ShapingModePanel_delete;

   this->settings = settings;
   this->scr = scr;
   this->p = p;

   super->eventHandler = ShapingModePanel_EventHandler;

   Panel_setHeader(super, "Shaping Mode");
   for (int i = 0; ShapingModeSchemes[i] != NULL; i++) {
      Panel_add(super, (Object*) CheckItem_new(String_copy(ShapingModeSchemes[i]), &(this->check[i])));
      this->check[i] = false;
   }
   
   if(p->smode == -1 )
   {
   	   for(i=0;i<MODE_BITS;++i)
		this->check[i] = false;
   }
   else
   {
	for(i=0;i<MODE_BITS;++i)
		if( p->smode & (1<<i) )
			this->check[i] = true;
		else
			this->check[i] = false;
   }
   return this;
}

void ShapingModePanel_delete(Object* object) {
   Panel* super = (Panel*) object;
   ShapingModePanel* this = (ShapingModePanel*) object;
   Panel_done(super);
   free(this);
}

HandlerResult ShapingModePanel_EventHandler(Panel* super, int ch) {
   ShapingModePanel* this = (ShapingModePanel*) super;
   
   HandlerResult result = IGNORED;
   int mark = Panel_getSelectedIndex(super);

   switch(ch) {
   case 0x0a:
   case 0x0d:
   case KEY_ENTER:
   case ' ':
      this->check[mark] = !this->check[mark];
      
      
      result = HANDLED;
   }

   if (result == HANDLED) {
      int i;
      int mode = 0;
      char svalue[MAX_NAME + 1];
      this->settings->changed = true;
      Header* header = this->settings->header;
      Header_draw(header);


      for(i=0; i<MODE_BITS; ++i)
      {
	     if( this->check[i] == true )
		     mode |= (1<<i);
      }

      this->p->smode = mode;
      snprintf(svalue, MAX_NAME, "/%s/%d/shaping", "proc", this->p->pid );
      Process_writeShaping( this->p, svalue );

      ScreenManager_resize(this->scr, this->scr->x1, header->height, this->scr->x2, this->scr->y2);
   }
   return result;
}



ShapingPanel* ShapingPanel_new(Settings* settings, ScreenManager* scr, Process* p) {
   ShapingPanel* this = (ShapingPanel*) malloc(sizeof(ShapingPanel));
   Panel* super = (Panel*) this;
   Panel_init(super, 1, 1, 1, 1, LISTITEM_CLASS, true);
   ((Object*)this)->delete = ShapingPanel_delete;

   this->settings = settings;
   this->scr = scr;
   this->p = p;

   super->eventHandler = ShapingPanel_eventHandler;
   Panel_setHeader(super, "Shaping");
   Panel_add(super, (Object*) ListItem_new("Enable", 0));
   Panel_add(super, (Object*) ListItem_new("Mode", 0));
   Panel_add(super, (Object*) ListItem_new("Devices -> DISK", 0));
   Panel_add(super, (Object*) ListItem_new("Devices -> LO", 0));
   Panel_add(super, (Object*) ListItem_new("Devices -> NET1", 0));
   Panel_add(super, (Object*) ListItem_new("Devices -> NET2", 0));
   Panel_add(super, (Object*) ListItem_new("Stats", 0));
   return this;
}

void ShapingPanel_delete(Object* object) {
   Panel* super = (Panel*) object;
   ShapingPanel* this = (ShapingPanel*) object;
   Panel_done(super);
   free(this);
}

void ShapingPanel_makeEnablePage(ShapingPanel* this) {
   Panel* enableShaping = (Panel*) EnableShapingPanel_new(this->settings, this->scr, this->p);
   ScreenManager_add(this->scr, enableShaping, FunctionBar_new(10, SEnableShapingFunctions, NULL, NULL), -1);

}

void ShapingPanel_makeModePage(ShapingPanel* this) {
   Panel* shapingModeOptions = (Panel*) ShapingModePanel_new(this->settings, this->scr, this->p);
   ScreenManager_add(this->scr, shapingModeOptions, FunctionBar_new(10, SShapingModeFunctions, NULL, NULL), -1);
}

void ShapingPanel_makeDevicePage(ShapingPanel* this, int device) {
   Panel* devices = (Panel*) DevicePanel_new(this->settings, this->scr, this->p, device);
   ScreenManager_add(this->scr, devices, FunctionBar_new(10, SDevicesFunctions, NULL, NULL), -1);
}

void ShapingPanel_makeInfoPage(ShapingPanel* this) {
   Panel* infoShaping = (Panel*) InfoShapingPanel_new(this->settings, this->scr, this->p);
   ScreenManager_add(this->scr, infoShaping, FunctionBar_new(10, SEnableShapingFunctions, NULL, NULL), -1);
}


HandlerResult ShapingPanel_eventHandler(Panel* super, int ch) {
   ShapingPanel* this = (ShapingPanel*) super;

   HandlerResult result = IGNORED;

   int previous = Panel_getSelectedIndex(super);

   switch (ch) {
      case KEY_UP:
      case KEY_DOWN:
      case KEY_NPAGE:
      case KEY_PPAGE:
      case KEY_HOME:
      case KEY_END: {
         Panel_onKey(super, ch);
         int selected = Panel_getSelectedIndex(super);
         if (previous != selected) {
            int size = ScreenManager_size(this->scr);
            for (int i = 1; i < size; i++)
               ScreenManager_remove(this->scr, 1);
            switch (selected) {
               case 0:
                  ShapingPanel_makeEnablePage(this);
                  break;
               case 1:
                  ShapingPanel_makeModePage(this);
                  break;
               case 2:
                  ShapingPanel_makeDevicePage(this, DISK);
                  break;
               case 3:
                  ShapingPanel_makeDevicePage(this, LO);
                  break;
	       case 4:
                  ShapingPanel_makeDevicePage(this, NET1);
                  break;
               case 5:
                  ShapingPanel_makeDevicePage(this, NET2);
                  break;
               case 6:
                  ShapingPanel_makeInfoPage(this);
                  break;
            }
         }
	
         result = HANDLED;
      }
   }

   return result;
}


DevicePanel* DevicePanel_new(Settings* settings, ScreenManager* scr, Process* p, int resource) {
   DevicePanel* this = (DevicePanel*) malloc(sizeof(DevicePanel));
   Panel* super = (Panel*) this;
   char svalue[MAX_NAME + 1];
   int ivalue;
   int read_write_mode = (p->smode & SHAPE_RW)?1:0;

   Panel_init(super, 1, 1, 1, 1, CHECKITEM_CLASS, true);
   ((Object*)this)->delete = DevicePanel_delete;

   this->settings = settings;
   this->scr = scr;
   this->p = p;
   this->resource = resource;

   super->eventHandler = DevicePanel_EventHandler;

   Panel_setHeader(super, "Devices");

   ivalue = toks_to_kbs(p->stable[this->resource].rate_write);
   snprintf( svalue,  MAX_NAME, "%s Rate: %d KB/s", ReadWriteModeNames[read_write_mode], ivalue ) ;
   ListItem* rate_write = ListItem_new(svalue , 0);

   ivalue = toks_to_kbs(p->stable[this->resource].limit_write);
   snprintf( svalue,  MAX_NAME, "%s Burst: %d KB", ReadWriteModeNames[read_write_mode], ivalue ) ;
   ListItem* limit_write = ListItem_new(svalue, 0);

   ivalue = p->stable[this->resource].count_write;
   snprintf( svalue,  MAX_NAME, "%s Count: %d", ReadWriteModeNames[read_write_mode], ivalue );
   ListItem* count_write = ListItem_new(svalue, 0);
   
   ivalue = toks_to_kbs(p->stable[this->resource].rate_read);
   snprintf( svalue,  MAX_NAME, "Read Rate: %d KB/s", ivalue ) ;
   ListItem* rate_read = ListItem_new(svalue , 0);

   ivalue = toks_to_kbs(p->stable[this->resource].limit_read);
   snprintf( svalue,  MAX_NAME, "Read Burst: %d KB", ivalue ) ;
   ListItem* limit_read = ListItem_new(svalue, 0);

   ivalue = p->stable[this->resource].count_read;
   snprintf( svalue,  MAX_NAME, "Read Count: %d", ivalue );
   ListItem* count_read = ListItem_new(svalue, 0);

   Panel_add(super, (Object*) rate_write);
   Panel_add(super, (Object*) limit_write);
   Panel_add(super, (Object*) count_write);
   if( read_write_mode ) {
   	Panel_add(super, (Object*) rate_read);
	Panel_add(super, (Object*) limit_read);
	Panel_add(super, (Object*) count_read);
   }
  return this;
}

void DevicePanel_delete(Object* object) {
   Panel* super = (Panel*) object;
   DevicePanel* this = (DevicePanel*) object;
   Panel_done(super);
   free(this);
}

static int DevicePanel_readInput( char *svalue, int count ) {
	int c, i=0;
      FunctionBar* deviceBar = FunctionBar_new(2, deviceFunctions, deviceKeys, deviceEvents);
      svalue[0] = '\0';
      FunctionBar_draw(deviceBar, svalue);

      while( ( c = CRT_readKey() ) != 13 && i < count - 1 )
      {
	if( c == KEY_BACKSPACE ) 
		--i;
	else if ( ( c >= '0' && c <= '9' ) || c == '.') 
		svalue[i++] = (char) c;
	else
		continue;

	svalue[i]  = '\0';
      	FunctionBar_draw(deviceBar, svalue);
      }
      FunctionBar_delete( (Object*) deviceBar );
      return i;
}

HandlerResult DevicePanel_EventHandler(Panel* super, int ch) {
   DevicePanel* this = (DevicePanel*) super;
   
   HandlerResult result = IGNORED;
   ListItem* selected = (ListItem*) Panel_getSelected(super);
   int selectedIndex = Panel_getSelectedIndex(super);
   int read_result;
   char svalue[MAX_NAME + 1];
   int read_write_mode = (this->p->smode & SHAPE_RW)?1:0;

   

   switch(ch) {
   case 13 :
   case ' ':
      result = HANDLED;
   }

   if (result == HANDLED) {
      Header* header = this->settings->header;
      Header_calculateHeight(header);

      Header_draw(header);

      DevicePanel_readInput( svalue, MAX_NAME );

     	read_result = atoi( svalue );
      switch (selectedIndex) {
         case 0:
		this->p->stable[ this->resource ].rate_write = kbs_to_toks(read_result); 
		snprintf( svalue, MAX_NAME, "%s Rate: %d KB/s", ReadWriteModeNames[read_write_mode], read_result );
           break;
         case 1:
		this->p->stable[ this->resource ].limit_write = kbs_to_toks( read_result ); 
		snprintf( svalue, MAX_NAME, "%s Burst: %d KB", ReadWriteModeNames[read_write_mode],read_result );
           break;
         case 2:
		this->p->stable[ this->resource ].count_write = read_result; 
		snprintf( svalue, MAX_NAME, "%s Count: %d ", ReadWriteModeNames[read_write_mode],read_result );
         break;
         case 3:
		this->p->stable[ this->resource ].rate_read = kbs_to_toks(read_result); 
		snprintf( svalue, MAX_NAME, "Read Rate: %d KB/s", read_result );
           break;
         case 4:
		this->p->stable[ this->resource ].limit_read = kbs_to_toks( read_result ); 
		snprintf( svalue, MAX_NAME, "Read Burst: %d KB", read_result );
           break;
         case 5:
		this->p->stable[ this->resource ].count_read = read_result; 
		snprintf( svalue, MAX_NAME, "Read Count: %d ", read_result );
         break;
      }

      ListItem_setRef(selected, svalue );
      super->needsRedraw = true;	
      ScreenManager_resize(this->scr, this->scr->x1, header->height, this->scr->x2, this->scr->y2);
      
   }

   snprintf(svalue, MAX_NAME, "/%s/%d/shaping", "proc", this->p->pid );
   Process_writeShaping( this->p, svalue );
   
   return result;
}


InfoShapingPanel* InfoShapingPanel_new(Settings* settings, ScreenManager* scr, Process* p) {
   InfoShapingPanel* this = (InfoShapingPanel*) malloc(sizeof(InfoShapingPanel));
   Panel* super = (Panel*) this;
   Panel_init(super, 1, 1, 1, 1, CHECKITEM_CLASS, true);
   ((Object*)this)->delete = InfoShapingPanel_delete;

   this->settings = settings;
   this->scr = scr;
   this->p = p;

   super->eventHandler = InfoShapingPanel_EventHandler;

   Panel_setHeader(super, "Info");

   // FIXME : get the TID and add other informations
   Panel_add(super, (Object*) ListItem_new("TID : ", 0));
   Panel_add(super, (Object*) ListItem_new("Actual DISK rate : ", 0));
   Panel_add(super, (Object*) ListItem_new("Actual NET1 rate : ", 0));
   Panel_add(super, (Object*) ListItem_new("Actual NET2 rate : ", 0));
  
   return this;
}

void InfoShapingPanel_delete(Object* object) {
   Panel* super = (Panel*) object;
   InfoShapingPanel* this = (InfoShapingPanel*) object;
   Panel_done(super);
   free(this);
}

HandlerResult InfoShapingPanel_EventHandler(Panel* super, int ch) {
   InfoShapingPanel* this = (InfoShapingPanel*) super;
   
   HandlerResult result = IGNORED;
   //CheckItem* selected = (CheckItem*) Panel_getSelected(super);

   switch(ch) {
   case 0x0a:
   case 0x0d:
   case KEY_ENTER:
   case ' ':
      result = HANDLED;
   }

   if (result == HANDLED) {
      Header* header = this->settings->header;
      Header_calculateHeight(header);
      Header_draw(header);
      ScreenManager_resize(this->scr, this->scr->x1, header->height, this->scr->x2, this->scr->y2);
   }
   return result;
}


