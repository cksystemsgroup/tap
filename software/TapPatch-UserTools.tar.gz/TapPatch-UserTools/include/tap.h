/*
 *  The TAP Project: Traffic Shaping System Calls
 *  Copyright (c) Harald Roeck (hroeck@cs.uni-salzburg.at), Silviu Craciunas (scraciunas@gmail.com)
 *
 *  University Salzburg, www.uni-salzburg.at
 *  Department of Computer Science, cs.uni-salzburg.at
 *
 *  This project is funded by the Austrian Science Fund project nummer P18913
 *
 *  This program is free software; you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation; either version 2 of the License, or
 *  (at your option) any later version.
 *
 *  This program is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 *
 *  You should have received a copy of the GNU General Public License
 *  along with this program; if not, write to the Free Software
 *  Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 *
 */

#ifndef TAP_H
#define TAP_H

#ifndef _GNU_SOURCE
#define _GNU_SOURCE
#endif
#include <unistd.h>
#include <sys/syscall.h>
#include <sys/types.h>
#include <errno.h>

/* our system call looks as follows
 *
 * int shape(pid_t pid, int on_off, int mode)
 *
 * return value: 0 on success 
 *   	on error: ESRCH no process with pid found
 *   		  ENOMEM no memory for shape table left
 *   		  ENOSYS the syscall is not implemented
 * 
 * arg1: the pid of the process to shape. 0 is
 * the current process. all threads of the 
 * process are shaped automatically and share
 * same token table.
 * 
 * arg2: 0 or 1. turn shaping on or off for the process.
 *
 * arg3: only used when arg2 is 1.
 * mode of shaping. is a bitmask of 0 or 
 * SHAPE_SHARE_CHILD. 
 *
 * when a process that is shaped does a fork its childs are
 * automatically shaped. Usally we do a deep copy of the 
 * shaping table, but if SHAPE_SHARE_CHILD is set, the 
 * childs will share their token table with the parent.
 */
static inline long int shape( pid_t pid, int on_off, int mode )
{
	return syscall ( __NR_shape, pid, on_off, mode );	
}

/* include tap kernel header */
#include <linux/tap.h>

#endif
