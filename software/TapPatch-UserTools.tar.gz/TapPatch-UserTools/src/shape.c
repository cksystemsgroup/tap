/*
 *  The TAP Project: Traffic Shaping System Calls
 *  Copyright (c) Harald Roeck (hroeck@cs.uni-salzburg.at), Silviu Craciunas (scraciunas@gmail.com)
 *
 *  University Salzburg, www.uni-salzburg.at
 *  Department of Computer Science, cs.uni-salzburg.at
 *
 *  This project is funded by the Austrian Science Fund project nummer P18913
 *
 *  This program is free software; you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation; either version 2 of the License, or
 *  (at your option) any later version.
 *
 *  This program is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 *
 *  You should have received a copy of the GNU General Public License
 *  along with this program; if not, write to the Free Software
 *  Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 *
 */
#include "tap.h"
#include <stdlib.h>
#include <stdio.h>
#include <string.h>



void usage(char *name)
{
	printf("usage: %s [OPTIONS] pid\n", name );
	printf("\twhere OPTIONS can be '-s' to indicate that the childs of the process"
			"shall share their token table with the parent\n");
}

int main(int argc, char **argv)
{
	int retval;
	pid_t pid;
	int mode = 0;
	int i;

	if(argc < 2 || argc > 3)
	{
		usage(argv[0]);
		exit(1);
	}


	for(i=1; i< argc;++i)
	{
		if( !strcmp(argv[i], "-s") )
			mode = 1;
		else
			pid = atoi( argv[i] );
	}
	printf("activating shaping for process %d with mode %d\n", pid, mode);
	retval = shape( pid, 1, mode );
	if(retval)
	{
		perror("ERROR: ");
	}
	return retval;
}
