#include <unistd.h>
#include <stdlib.h>
#include <stdio.h>

#include <errno.h>
#include <linux/unistd.h>
//#include <linux/ioprio.h>
/*
 * Gives us 8 prio classes with 13-bits of data for each class
 */
#define IOPRIO_BITS		(16)
#define IOPRIO_CLASS_SHIFT	(13)
#define IOPRIO_PRIO_MASK	((1UL << IOPRIO_CLASS_SHIFT) - 1)

#define IOPRIO_PRIO_CLASS(mask)	((mask) >> IOPRIO_CLASS_SHIFT)
#define IOPRIO_PRIO_DATA(mask)	((mask) & IOPRIO_PRIO_MASK)
#define IOPRIO_PRIO_VALUE(class, data)	(((class) << IOPRIO_CLASS_SHIFT) | data)

#define ioprio_valid(mask)	(IOPRIO_PRIO_CLASS((mask)) != IOPRIO_CLASS_NONE)


enum {
	IOPRIO_CLASS_NONE,
	IOPRIO_CLASS_RT,
	IOPRIO_CLASS_BE,
	IOPRIO_CLASS_IDLE,
};


enum {
	IOPRIO_WHO_PROCESS = 1,
	IOPRIO_WHO_PGRP,
	IOPRIO_WHO_USER,
};



static inline int ioprio_set(int which, int who, int ioprio)
{
	return syscall(__NR_ioprio_set, which, who, ioprio);
}

static void usage(char *s)
{
	printf("usage: %s pid\n", s);
	exit(0);
}

int main(int argc, char **argv)
{
	int pid, retval;
	int which, who, ioprio;

	if(argc != 2)
		usage(argv[0]);

	pid = atoi( argv[1] );
	which = IOPRIO_WHO_PROCESS;
	who =	pid; 
	ioprio = IOPRIO_PRIO_VALUE( IOPRIO_CLASS_RT, 0);
	

	retval = ioprio_set(which, who, ioprio);
	if(retval)
		perror("ioprio_set");
	return 0;
}
