/*
 *  The TAP Project: Traffic Shaping System Calls
 *  Copyright (c) Harald Roeck (hroeck@cs.uni-salzburg.at), Silviu Craciunas (scraciunas@gmail.com)
 *
 *  University Salzburg, www.uni-salzburg.at
 *  Department of Computer Science, cs.uni-salzburg.at
 *
 *  This project is funded by the Austrian Science Fund project nummer P18913
 *
 *  This program is free software; you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation; either version 2 of the License, or
 *  (at your option) any later version.
 *
 *  This program is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 *
 *  You should have received a copy of the GNU General Public License
 *  along with this program; if not, write to the Free Software
 *  Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 *
 */
#include <sys/syscall.h>
#include <sys/types.h>
#include <sys/wait.h>
#include <unistd.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#include <tap.h>

int pipe_fd[2];

#define COUNT   10
#define BUFFER_SIZE  (16*1024 + 2)

int main(int argc, char **argv)
{
	int i, mode;
	pid_t pid;
	
	if(argc == 2)
		mode = 1;
	else
		mode = 0;

	printf("calling shape with mode: %d\n", mode );
	syscall(279, 0, 1, mode);

	for(i=0;i<COUNT;++i)
		printf("%d\n", i);

	if( pipe(pipe_fd) )
	{
		perror("pipe");
		exit(1);
	}

	pid = fork();
	if( pid == -1 )
	{
		perror("fork");
		exit(1);
	}

	if(pid == 0)
	{/* child */
		char *buf = malloc(BUFFER_SIZE);
		int read_result;
		close( pipe_fd[1] );
		if( buf )
		{
			do
			{
				read_result = read( pipe_fd[0], buf, BUFFER_SIZE-1 );
				if(read_result > 0 )
				{
					buf[read_result] = '\0';
          printf("read: %s\n", buf);
				}
			} while( read_result != 0 );
			free( buf );
		}
		else
		{
			perror("malloc");
		}
		close( pipe_fd[0]	);
	}/* parent */
	else
	{
		char *buf = malloc(BUFFER_SIZE);
		close( pipe_fd[0]	);
		if( buf )
		{
			do
			{
				printf("your input: ");
				scanf( "%s/n", buf);
				write( pipe_fd[1], buf, strlen(buf) );
			} while( buf[0] != 'k' );
		}
		else
		{
			perror("malloc");
		}
		for(i=0;i<COUNT*1024;++i)
			printf("%d ", i);

		printf("press any key to close");
		scanf( "%s\n", buf);
		close( pipe_fd[1] );

		waitpid(pid,NULL, 0);
	}

	shape( 0, 0, 0);
	return 0;
}

