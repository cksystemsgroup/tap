/*
 *  The TAP Project: Traffic Shaping System Calls
 *  Copyright (c) Harald Roeck (hroeck@cs.uni-salzburg.at), Silviu Craciunas (scraciunas@gmail.com)
 *
 *  University Salzburg, www.uni-salzburg.at
 *  Department of Computer Science, cs.uni-salzburg.at
 *
 *  This project is funded by the Austrian Science Fund project nummer P18913
 *
 *  This program is free software; you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation; either version 2 of the License, or
 *  (at your option) any later version.
 *
 *  This program is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 *
 *  You should have received a copy of the GNU General Public License
 *  along with this program; if not, write to the Free Software
 *  Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 *
 */

#define _XOPEN_SOURCE 500

#include <asm/msr.h>
#include <sys/stat.h>
#include <fcntl.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>

int ntrials = 1000;
#define NTRIALS ntrials

#define BUFFER_SIZE (1024*4 + 1)
char buffer[BUFFER_SIZE];

#define	TICKS_PER_SECOND 2000000000l

int in_fd = STDIN_FILENO;

void usage( char *s )
{
	printf("usage: %s [-f file_name] [loop_count]\n", s);
}

void open_file(char *name)
{
	int fd;

	fd = open(name, O_RDONLY);
	if( fd == -1 )
	{
		printf("ERROR on %s ", name ); 
		fflush(stdout);
		perror("open file");
		exit(1);
	}

	printf("file %s opened\n", name );
	in_fd = fd;
}

int main(int argc, char **argv)
{
	unsigned long ini, end, now, best, tsc, worst;
	unsigned long sum = 0;
	int i;

	if( argc > 1 )
	{
		for(i=1; i<argc; ++i)
		{
			if( strcmp( argv[i], "-f" ) == 0)
			{
				if( argc <= i + 1 )
				{
					usage( argv[0] );
				}
				open_file( argv[i + 1] );
				++i;
			}
			else
				ntrials = atoi( argv[i] );
		}
	}
	else
	{
		usage( argv[0] );
		return 0;
	}
#define measure_time(code) \
	for (i = 0; i < NTRIALS; i++) { \
		rdtscll(ini); \
		code; \
		rdtscll(end); \
		now = end - ini; \
		if (now < best) best = now; \
		if (now > worst) worst = now; \
		sum += now; \
	}

	/* time rdtsc (i.e. no code) */
	best = ~0;
	measure_time(  );
	tsc = best;

	/* time an empty read() */
	best = ~0;
	worst = 0;
	measure_time( pread(in_fd, buffer, BUFFER_SIZE -1, 0) );

	/* report data */
	printf( "%d loops: rdtsc: %lu ticks\n"
		"best read(): %6li ticks, %6lu nsecs\n"
		"avg. read(): %6li ticks, %6lu nsecs\n"
		"wrst read(): %6li ticks, %6lu nsecs\n",
			ntrials, tsc, 
			best-tsc, (best-tsc)/(TICKS_PER_SECOND/1000000000l),
	     		sum/ntrials - tsc, (sum/ntrials - tsc)/( TICKS_PER_SECOND/1000000000l ),
			worst-tsc, (worst-tsc)/(TICKS_PER_SECOND/1000000000l)
			);

	return 0;
}
