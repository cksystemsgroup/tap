/* $Id: pthread.h,v 1.10.2.1 2005/07/06 06:37:46 hroeck Exp $*/

/* 
 * Copyright (c) Petru Flueras petru.flueras@cs.uni-salzburg.at 
 *
 * University Salzburg, www.uni-salzburg.at
 * Department of Computer Science, cs.uni-salzburg.at
 */

/*  
 *  This program is free software; you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation; either version 2 of the License, or
 *  (at your option) any later version.
 *
 *  This program is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 *
 *  You should have received a copy of the GNU General Public License
 *  along with this program; if not, write to the Free Software
 *  Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 *
 */

#ifndef PTHREAD_MAP_H
#define PTHREAD_MAP_H

/*
 * Protect namespace
 */
#define pthread_t		__vendor_pthread_t
#define pthread_attr_t		__vendor_pthread_attr_t
#define pthread_key_t		__vendor_pthread_key_t
#define pthread_once_t		__vendor_pthread_once_t
#define pthread_mutex_t 	__vendor_pthread_mutex_t
#define pthread_mutexattr_t	__vendor_pthread_mutexattr_t

/*
 * Include essential headers
 */
#include <sys/types.h>

/*
 * API
 */
#define PTHREAD_CREATE_JOINABLE 0x00
#define PTHREAD_CREATE_DETACHED 0x01

/*
 * Unprotect namespace
 */
#undef pthread_t
#undef pthread_attr_t
#undef pthread_key_t
#undef pthread_once_t
#undef pthread_mutex_t
#undef pthread_mutexattr_t

/*
 * Forward structure definitions.
 * These are mostly opaque to the application.
 */
struct _pthread_st;
struct _pthread_attr_st;
struct _pthread_mutex_st;
struct _pthread_mutexattr_st;
/*
 * Primitive system data type definitions required by P1003.1c
 */
typedef struct _pthread_st *pthread_t;
typedef struct _pthread_attr_st *pthread_attr_t;
typedef int pthread_key_t;
typedef struct _pthread_mutex_st *pthread_mutex_t;
typedef struct _pthread_mutexattr_st *pthread_mutexattr_t;
typedef int pthread_once_t;

/*
 * IEEE (POSIX) Std 1003.1 Second edition 1996-07-12
 */
/* Thread attribute routines */
extern int pthread_attr_init(pthread_attr_t *);
extern int pthread_attr_destroy(pthread_attr_t *);
extern int pthread_attr_setdetachstate(pthread_attr_t *, int);

/* Thread routines */
extern int pthread_cancel(pthread_t);
extern int pthread_create(pthread_t *, const pthread_attr_t *,
                          void *(*)(void *), void *);
extern int pthread_equal(pthread_t, pthread_t);
extern void pthread_exit(void *);
extern int pthread_join(pthread_t, void **);
extern pthread_t pthread_self();
extern int sched_yield();

/* Thread synchronization routines */
extern int pthread_mutex_init(pthread_mutex_t * mutex,
                              const pthread_mutexattr_t * mutex_attr);
extern int pthread_mutex_lock(pthread_mutex_t * mutex);
extern int pthread_mutex_trylock(pthread_mutex_t * mutex);
extern int pthread_mutex_unlock(pthread_mutex_t * mutex);
extern int pthread_mutex_destroy(pthread_mutex_t * mutex);

#endif // PTHREAD_MAP_H
