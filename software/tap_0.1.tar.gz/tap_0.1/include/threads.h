/* $Id: threads.h,v 1.19.2.8 2005/10/14 14:30:12 hroeck Exp $*/

/* 
 * Copyright (c) Harald Roeck hroeck@cs.uni-salzburg.at 
 *
 * University Salzburg, www.uni-salzburg.at
 * Department of Computer Science, cs.uni-salzburg.at
 */

/*  
 *  This program is free software; you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation; either version 2 of the License, or
 *  (at your option) any later version.
 *
 *  This program is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 *
 *  You should have received a copy of the GNU General Public License
 *  along with this program; if not, write to the Free Software
 *  Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 *
 */

#ifndef THREADLIB_H
#define THREADLIB_H

#ifndef _GNU_SOURCE
#define _GNU_SOURCE
#endif


/* turn of debuging */
/* if commented out the lib
 * creates several trace files
 */
#ifndef NDEBUG
#define NDEBUG
#endif


#include "debug.h"
#include <stdlib.h>
#include <fcntl.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <sys/socket.h>
#include <string.h>

/* thread type */
typedef struct _thread *tap_thread_t;

/* filedescriptor type */
typedef struct _fdesc *tap_fd_t;

extern tap_thread_t tap_thread_self();
extern tap_thread_t tap_thread_create(void *(*start) (void *arg), void *arg);
extern void tap_thread_exit(void *retval);

extern void tap_yield();

/* get id of the current thread */
extern int tap_getid();
/* get id of a thread */
extern int tap_thread_getid(tap_thread_t thr);

/* FIXME following two are not implemented yet */
extern int tap_thread_join(tap_thread_t thread, void **value);
extern int tap_thread_cancel(tap_thread_t thread);

#define TAP_RETURN_CANCELED (NULL+1)

/*****************************************************************
 *                         IO staff
 *****************************************************************/

/* for read and write */
extern ssize_t tap_read(tap_fd_t fd, void *buf, size_t count);

extern ssize_t tap_write(tap_fd_t fd, const void *buf, size_t count);
/* get the underlying OS filedescriptor */
extern int tap_osfd(tap_fd_t fd);

extern tap_fd_t tap_open(const char *path, int flags, mode_t mode);
extern ssize_t tap_close(tap_fd_t fd);

extern void tap_kill(tap_thread_t thr);
/************************************
 * socket operations
 ************************************/

extern tap_fd_t tap_accept(tap_fd_t s, struct sockaddr *addr,
                           socklen_t * addrlen);

extern tap_fd_t tap_socket(int domain, int type, int protocoll);

extern int tap_listen(tap_fd_t s, int backlog);

extern int tap_bind(tap_fd_t s, const struct sockaddr *myaddr,
                    socklen_t addrlen);

extern int tap_connect(tap_fd_t s, const struct sockaddr *saddr,
                       socklen_t addrlen);

typedef struct _mutex *tap_mutex_t;

extern int tap_mutex_init(tap_mutex_t * m);
extern int tap_mutex_destroy(tap_mutex_t * m);
extern int tap_mutex_lock(tap_mutex_t m);
extern int tap_mutex_unlock(tap_mutex_t m);
#endif
