/* $Id: syscalls.h,v 1.3 2005/04/27 15:18:22 hroeck Exp $*/
/* Copyright (c) Harald Roeck hroeck@cs.uni-salzburg.at */

/* 
 * Copyright (c) Harald Roeck hroeck@cs.uni-salzburg.at 
 *
 * University Salzburg, www.uni-salzburg.at
 * Department of Computer Science, cs.uni-salzburg.at
 */

/*  
 *  This program is free software; you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation; either version 2 of the License, or
 *  (at your option) any later version.
 *
 *  This program is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 *
 *  You should have received a copy of the GNU General Public License
 *  along with this program; if not, write to the Free Software
 *  Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 *
 */

#ifndef SYSCALLS_H
#define SYSCALLS_H

#include "threads.h"
#include <sys/socket.h>

/* 
 * override syscalls 
 */
ssize_t read(int fd, void *buf, size_t count);
ssize_t write(int fd, const void *buf, size_t count);
int open(const char *path, int flags, ...);
ssize_t close(int fd);

/*
 * sockets
 */

int accept(int s, struct sockaddr *addr, socklen_t * addrlen);

int bind(int sockfd, const struct sockaddr *myaddr, socklen_t addrlen);

int connect(int sockfd, const struct sockaddr *saddr, socklen_t addrlen);

int getpeername(int sockfd, struct sockaddr *addr, socklen_t * paddrlen);

int getsockname(int sockfd, struct sockaddr *addr, socklen_t * paddrlen);

int getsockopt(int fd, int level, int optname, __ptr_t optval,
               socklen_t * optlen);

int listen(int sockfd, int backlog);

ssize_t recv(int sockfd, __ptr_t buffer, size_t len, int flags);

ssize_t recvfrom(int sockfd, __ptr_t buffer, size_t len, int flags,
                 struct sockaddr *to, socklen_t * tolen);

ssize_t recvmsg(int sockfd, struct msghdr *msg, int flags);

ssize_t send(int sockfd, const void *buffer, size_t len, int flags);

ssize_t sendmsg(int sockfd, const struct msghdr *msg, int flags);

ssize_t sendto(int sockfd, const void *buffer, size_t len, int flags,
               const struct sockaddr *to, socklen_t tolen);

int setsockopt(int fd, int level, int optname, const void *optval,
               socklen_t optlen);

int shutdown(int sockfd, int how);

int socket(int family, int type, int protocol);

int socketpair(int family, int type, int protocol, int sockvec[2]);

#endif
