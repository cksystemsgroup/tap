/* $Id: process.h,v 1.9.2.12 2005/10/14 14:30:12 hroeck Exp $ */

/* 
 * Copyright (c) Harald Roeck hroeck@cs.uni-salzburg.at 
 *
 * University Salzburg, www.uni-salzburg.at
 * Department of Computer Science, cs.uni-salzburg.at
 */

/*  
 *  This program is free software; you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation; either version 2 of the License, or
 *  (at your option) any later version.
 *
 *  This program is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 *
 *  You should have received a copy of the GNU General Public License
 *  along with this program; if not, write to the Free Software
 *  Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 *
 */

#ifndef PROCESS_H
#define PROCESS_H

#include "threads.h"
#include "runq.h"
#include "timeoutq.h"
#include "plist.h"
#include "list.h"

/*aa*/

#include <libaio.h>             /* disc aio */
#include <sys/epoll.h>          /* new linux event polling */
#include <stdio.h>

#define MAX_PROC 1              /* support only one cpu */
#define MAX_CALENDARS 4
/*
 * representation of a process 
 */
typedef 
struct{
	pid_t pid;
	int cpu_id;
	int active_threads;

	_thread_t *reactor;           /* a reactor per process */

	_thread_t *curr_thread;       /* running thread */

	runq_t run_q;                 /* runq per process */
	runq_t zombie_q;              /* finished threads, waiting for clean up */


	struct tap_list all_threads;
	
	/*
	 * set of threads for the next appointment
	 */
	// threads of the next app, but not yet ready
	struct tap_list app_next;
	// threads ready for the app clock
	struct tap_list app_ready;

	/* the calendars */
	plist_t *calendars;

	/* Timeout queue */
	timeoutq_t timeout_q;

	/* IO descriptors */
	/* 
	 * for epoll;
	 * network io 
	 */
	int epoll_fd;
	struct epoll_event *epoll_events;

	/*
	 * for linux aio;
	 * disc io
	 */
	io_context_t aio_ctx;
	struct io_event *aio_events;
	int pending;
	/* to batch aio submitts */
	struct iocb **aio_cbs;
	int active_cbs;

} 
process_t;

extern process_t processes[MAX_PROC];

static inline int get_id()
{
	return 0;                     /* support only one CPU, yet */
}

/*
 * Macros to define getter functions
 */

/* return pointer to a member */
#define decl_get_p(name, member)                                          \
	static inline __typeof__(((process_t *)0)->member)* process_get_##name(int id) \
{                                                                     \
	return &processes[id].member;                                      \
}
/* simple getter where name is equal member */
#define sdecl_get_p(name) decl_get_p(name, name)

/* declare list functions: getter, and empty test */
#define decl_list_funcs(name, member)                           \
	decl_get_p(name, member)                                    \
static inline int process_empty_##name(int id)              \
{                                                           \
	return list_empty(process_get_##name(id));              \
}                                                           

/* declare simple list functions */
#define sdecl_list_funcs(name) decl_list_funcs(name, name)

/* getter for elements */
#define decl_get(name, member)                                            \
	static inline __typeof__( ((process_t *)0)->member) process_get_##name(int id) \
{                                                                     \
	return processes[id].member;                                      \
}

#define sdecl_get(name) decl_get(name, name)

/* declare list getter and empty functions */
sdecl_list_funcs(app_ready);
sdecl_list_funcs(app_next);
/* declare getter functions */
sdecl_get(active_threads);
sdecl_get(reactor);
sdecl_get_p(run_q);
sdecl_get_p(zombie_q);
sdecl_get(epoll_fd);
sdecl_get(epoll_events);
sdecl_get(aio_events);
sdecl_get_p(aio_ctx);
sdecl_get(aio_cbs);
sdecl_get(calendars);
sdecl_get_p(all_threads);

decl_get_p(timeoutq, timeout_q);

static inline void process_add_ready(_thread_t *thread)
{
	assert(thread->flags & TAP_ON_NEXT_APP);
	assert(thread->flags & TAP_READY);
	internal(3, " push thread [%d] to ready queue ", thread->tid);

	thread->curr_func = __FUNCTION__;
	list_del_init(&thread->ready_q);
	list_add_tail(process_get_app_ready(get_id()), &thread->ready_q);
}
static inline void process_add_next(_thread_t *thread)
{
	assert(thread->flags & TAP_ON_NEXT_APP);
	internal(3, " push thread [%d] to next_app queue ", thread->tid);

	thread->curr_func = __FUNCTION__;
	list_del_init(&thread->ready_q);
	list_add_tail(process_get_app_next(get_id()), &thread->ready_q);
}

static inline void process_release(_thread_t * thread)
{
	internal(3, " release thread [%d]", thread->tid);
	runq_append(&processes[get_id()].run_q, thread);
}

static inline plist_t *process_get_calendar(int id, int cal)
{
	return process_get_calendars(id) + cal;//processes[id].calendars + cal;
}

static inline void process_inc_threads(int id)
{
	++processes[id].active_threads;
	internal(0, " active threads changed to %d", processes[id].active_threads);
}

static inline void process_dec_threads(int id)
{
	--processes[id].active_threads;
	internal(0, " active threads changed to %d", processes[id].active_threads);
}

/*
 * get the active thread of a specific process 
 */
static inline _thread_t *get_thread(int id)
{
	return processes[id].curr_thread;
}

static inline void clear_thread(int id)
{
	processes[id].curr_thread = NULL;
}


static inline void process_set_epoll(int id, int epfd, struct epoll_event *ev)
{
	processes[id].epoll_fd = epfd;
	processes[id].epoll_events = ev;

}


static inline int process_reduce_pending(int id, int count)
{
	//if(count > 0 && processes[id].pending > count)
	processes[id].pending -= count;

	internal(3, "pending changed to %d", processes[id].pending);
	return processes[id].pending;
}
static inline int process_pending(int id)
{
	return processes[id].pending > 0;
}

static inline int process_increase_pending(int id, int count)
{
	processes[id].pending += count;
	internal(3, "pending changed to %d", processes[id].pending);
	return processes[id].pending;
}

static inline int process_aio_submit(struct iocb *cb, int id)
{
	int retval = 0;
#ifdef AIO_NO_BATCH
  io_context_t *_aio_ctx = process_get_aio_ctx(id);
  retval = io_submit(*_aio_ctx, 1, &cb);
  if (retval > 0)
  	process_increase_pending(id, retval);
#else
	processes[id].aio_cbs[processes[id].active_cbs++] = cb;
#endif
	return retval;
}

extern long poll_count;
static inline int process_epoll_submit(struct netcb *ncb, int id)
{
	int epfd = process_get_epoll_fd(id);
	int ret;
	internal(5, "do a epoll ctl of fd %d", ncb->fd);
	ret = epoll_ctl(epfd, ncb->epoll_op, ncb->fd, ncb->event);
	if(ret)
	{
		internal(4, " ERROR epoll_ctl %d: %d %s ", 
				ret, errno, strerror(errno));
		internal(4, "      ARGS: %d %x %d ", epfd, ncb->epoll_op, ncb->fd); 
		printf(" error epoll_ctl: %d %s\n", errno, strerror(errno));
	}
	else
		poll_count++;
	return ret;
}
static inline void process_set_aio(int id, struct io_event *ev)
{
	processes[id].aio_events = ev;
}
static inline void process_print_calendars(int id)
{
	int i;
	printf("printing all calendars:\n");
	for(i=0; i<4;++i)
	{
		printf("calendar %d:\n", i);
		plist_print(process_get_calendar(id,i));
	}
}
extern void process_print_threads(int id);
extern void process_print_next(int id);
extern void process_print_ready(int id);
static inline void process_print(int id)
{
	process_print_threads(id);
	process_print_next(id);
	process_print_ready(id);
}
#endif
