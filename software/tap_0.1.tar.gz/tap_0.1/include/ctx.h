/* $Id: ctx.h,v 1.6.2.1 2005/07/06 06:37:46 hroeck Exp $ */

/* 
 * Copyright (c) Harald Roeck hroeck@cs.uni-salzburg.at 
 *
 * University Salzburg, www.uni-salzburg.at
 * Department of Computer Science, cs.uni-salzburg.at
 */

/*
 *  This program is free software; you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation; either version 2 of the License, or
 *  (at your option) any later version.
 *
 *  This program is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 *
 *  You should have received a copy of the GNU General Public License
 *  along with this program; if not, write to the Free Software
 *  Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 *
 */

#ifndef CTX_H
#define CTX_H

#include "stack.h"

#include <ucontext.h>
#include "debug.h"

struct ctx_context
{
  struct ucontext cc;
};

//#define USE_STD_CTX

#ifdef USE_STD_CTX

#define getctx(...) getcontext(__VA_ARGS__)

#define setctx(...) setcontext(__VA_ARGS__)

#define swapctx(...) swapcontext(__VA_ARGS__)

#define makectx(...) makecontext(__VA_ARGS__)

#else

extern int getctx(ucontext_t * __ucp);

/* Set user context from information of variable pointed to by UCP.  */
extern int setctx(const ucontext_t * __ucp);

/* Save current context in context variable pointed to by OUCP and set
   context from variable pointed to by UCP.  */
extern int swapctx(ucontext_t * __oucp, const ucontext_t * __ucp);

/* Manipulate user context UCP to continue with calling functions FUNC
   and the ARGC-1 parameters following ARGC when the context is used
   the next time in `setcontext' or `swapcontext'.

   We cannot say anything about the parameters FUNC takes; `void'
   is as good as any other choice.  */
extern void makectx(ucontext_t * __ucp, void (*__func) (void), int __argc, ...);

#endif

/*
 * init a context with the current state
 */
static inline int ctx_init(struct ctx_context *ctx)
{
  return getctx(&ctx->cc);
}

/*
 * resume a saved context
 * does not save the current context
 */
static inline int ctx_resume(struct ctx_context *ctx)
{
  return setctx(&ctx->cc);
}

/*
 * creates a new context
 */
static inline int ctx_create(struct ctx_context *ctx, void (*func) (),
                             void *data, tap_stack_t * stack)
{
  if (ctx_init(ctx))
    return -1;

  if (stack->state != STK_FREE)
    return -1;

  stack_fix(stack);
  ctx->cc.uc_link = NULL;
  ctx->cc.uc_stack.ss_sp = stack->sp;
  ctx->cc.uc_stack.ss_size = stack_usable_size(stack);
  ctx->cc.uc_stack.ss_flags = 0;

  makectx(&ctx->cc, func, 1, data);

  return 0;
}

/*
 * saves the current context in from
 * and resumes context to
 */
static inline int ctx_switch(struct ctx_context *from, struct ctx_context *to)
{
  return swapctx(&from->cc, &to->cc);
}

#endif
