/* $Id: profile.h,v 1.1.2.3 2005/08/03 15:24:59 hroeck Exp $ */

/* 
 * Copyright (c) Harald Roeck hroeck@cs.uni-salzburg.at 
 *
 * University Salzburg, www.uni-salzburg.at
 * Department of Computer Science, cs.uni-salzburg.at
 */

/*  
 *  This program is free software; you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation; either version 2 of the License, or
 *  (at your option) any later version.
 *
 *  This program is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 *
 *  You should have received a copy of the GNU General Public License
 *  along with this program; if not, write to the Free Software
 *  Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 *
 */


#ifndef PROFILE_H
#define PROFILE_H

#define PROF_SUBMITTED 0
#define PROF_GETEVENTS 1
#define PROF_EPOLL     2
#define PROF_RUNQ      3
#define PROF_READY     4
#define PROF_NEXTREADY 5

#define PROF_LAST 6

#define DOPROFILE(statements) 

void prof_print();
#ifdef PROFILE
#undef DOPROFILE
#define DOPROFILE(statements) { statements }

#define MAX_PROFILE 100

struct prof_avg
{
	long n;
	double avg;
};

typedef struct prof_avg *prof_avg_t;

extern struct prof_avg profiling[MAX_PROFILE];

int prof_new(prof_avg_t *avg);


char * prof_name(int id);

static inline long prof_add(prof_avg_t avg, long value)
{
	double t = avg->avg * (double)avg->n;
	++avg->n;
	avg->avg = (t+value)/avg->n;
	return avg->avg;
}
static inline void prof_init()
{
	memset(profiling, 0, sizeof(profiling));
}

static inline prof_avg_t prof_get(int id)
{
	return profiling + id;
}

#else /* PROFILE */
#define MAX_PROFILE 0
typedef int prof_avg_t;
static inline long prof_add(prof_avg_t avg, long value)
{

}

static inline void prof_init()
{

}

static inline prof_avg_t prof_new()
{
	return 0;
}

static inline prof_avg_t prof_get(int id)
{
	return 0;
}

#define DECL_PROF(...) int __VA_ARGS__

#endif /* PROFILE */




#endif
