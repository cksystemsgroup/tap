/* $Id: threads_private.h,v 1.19.2.18 2005/10/14 14:30:12 hroeck Exp $*/

/* 
 * Copyright (c) Harald Roeck hroeck@cs.uni-salzburg.at 
 *
 * University Salzburg, www.uni-salzburg.at
 * Department of Computer Science, cs.uni-salzburg.at
 */

/*  
 *  This program is free software; you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation; either version 2 of the License, or
 *  (at your option) any later version.
 *
 *  This program is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 *
 *  You should have received a copy of the GNU General Public License
 *  along with this program; if not, write to the Free Software
 *  Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 *
 */

#ifndef THREADLIB_PRIVATE_H
#define THREADLIB_PRIVATE_H

//#define _GNU_SOURCE

#include "threads.h"
#include "config.h"
#include "ctx.h"
#include "list.h"
#include "stack.h"
#include "timeoutq.h"
#include "timing.h"
#ifdef HAVE_LIBAIO_H
#include <libaio.h>
#else
#error missing libaio library 
#endif
#include <stdlib.h>
#include <errno.h>

#define MAX_PRIORITY 10
#define MIN_PRIORITY 0

/* three different traffic
 * shaping policies
 */
//#define REV_PRIOS // increase
//#define STD_PRIOS // decrease
#define NO_PRIOS    // constant


//#if defined(REV_PRIOS) 
typedef 
struct{
  enum
  {
    APP_COMMIT = 1,
    APP_READ,
    APP_WRITE,
    APP_ACCEPT,
    APP_SOCKOP,
  } type;
  enum
  {
    RES_DISC = 1,
    RES_NET = 2,
    RES_CPU = 3,                    /* for commit, and others */
  } resource;
}
appointment_t;

typedef 
enum{
  READ = 1,
  WRITE,
  PREAD,
  PWRITE,
  ACCEPT,
} 
tap_io_t;

struct netcb
{
  tap_io_t op;
  int fd;
  void *buf;
  size_t count;
  ssize_t result;
	struct epoll_event *event;
	int epoll_op;
};

struct thread_io_op
{
	/* type of io; e.g. READ, WRITE */
	tap_io_t type;
	
	/* resource to access */
	enum	
	{
    TRES_DISC,
    TRES_NET,
    TRES_CPU,
  } 
	resource;
	/* arguments for the syscall */
  union
  {
    struct iocb cb;
    struct netcb ncb;
	} 
	;
};

struct _thread;
typedef 
struct _thread{
  int tid;
  /* cpu context */
  struct ctx_context ctx;

  /* stack segment */
  tap_stack_t *stk;

  /* priority */
  int priority;

	const char *curr_func;

  /* when we support SMP */
  char cpu_id;

  /* the state of the thread */
  enum
	{
    RUNNING = 1,
    RELEASED,
    HOLD,
    DELAYED,
    BLOCKED,
    WAITING,
    TIMEDOUT,
    ZOMBIE,
    DESTROYED,
  } 
	state:8;


  /* internal flags, e.g. joinable, detached */
  char flags;
#define TAP_JOINABLE         0x01
#define TAP_CANCELED         0x02
#define TAP_TIMEDOUT         0x04
#define TAP_READY            0x10
#define TAP_ON_NEXT_APP      0x20
#define TAP_ON_NEXT_CLOCK    0x40

  /* the private errno */
  int _errno;

  /* start function and arguments */
  void *(*start_func) (void *data);
  void *start_data;
  void *retval;

  /* joining thread */
  struct _thread *joining_thread;

  /* for the family tree 
   * FIXME: not yet fully supported 
	 *
   */
  /* parent thread */
  struct _thread *parent;
  /* childs and siblings */
  struct tap_list childs;
  struct tap_list siblings;

	struct tap_list fd_list;
  /* for inserting the thread in the queue
   * run queue, zombie queue, timeout queue ...
   */
  struct tap_list queue;

  /* for the calendar */
  struct tap_list calendar;

//  struct tap_list appointment;

	/* for the ready list */
	struct tap_list ready_q;
  /* IO queue */
  struct tap_list io_q;

	struct tap_list all_threads;
  /* timeout queue */
  timeoutq_t tq;

  /* appointment type */
  appointment_t app;

	struct thread_io_op op;
}
_thread_t;

struct _mutex
{
	_thread_t *thread;
  struct tap_list list;
};

/* forward declarations of some basic functions */

/*
 * constructor and destructor;
 * called by the main thread, before and
 * after main() resp.
 */
void main_init() __attribute__ ((constructor));
void main_exit();// __attribute__ ((destructor));

/*
 * if time -1 blocks indefinetly or until an
 * other event wakes the thread
 * return the current time 
 * i.e. when the thread continues
 *
 */
#define block(time) __block(__FUNCTION__, time)

tap_utime_t __block(const char *function, tap_utime_t time);

/*
 * add current thread to the timeout queue
 */
int thread_timeout(tap_utime_t time);

/*
 * kill/destroy a thread
 */
void tap_kill(_thread_t * thr);

/*
 * increase priority of a thread
 */
#if defined(REV_PRIOS)
static inline void _thread_dec_priority(_thread_t * thr)
{
  if (thr->priority < MAX_PRIORITY -1) 
     ++thr->priority;
}

/*
 * decrease priority
 */
static inline void _thread_inc_priority(_thread_t * thr)
{
  if (thr->priority > MIN_PRIORITY)
    --thr->priority;
}

static inline void _thread_reset_priority(_thread_t * thr)
{
  thr->priority = MAX_PRIORITY-1;
}
#elif defined(NO_PRIOS) 
static inline void _thread_inc_priority(_thread_t * thr)
{
}

/*
 * decrease priority
 */
static inline void _thread_dec_priority(_thread_t * thr)
{
}

static inline void _thread_reset_priority(_thread_t * thr)
{
  thr->priority = (MAX_PRIORITY + MIN_PRIORITY)/2;
}

#elif defined(STD_PRIOS)
static inline void _thread_inc_priority(_thread_t * thr)
{
  if (thr->priority < MAX_PRIORITY -1) 
     ++thr->priority;
}

/*
 * decrease priority
 */
static inline void _thread_dec_priority(_thread_t * thr)
{
  if (thr->priority > MIN_PRIORITY)
    --thr->priority;
}

static inline void _thread_reset_priority(_thread_t * thr)
{
  thr->priority = MIN_PRIORITY;
}
#else
#error please specify the priorities policy
#endif
/**********************************************************
 *          public tap functions 
 **********************************************************/

/* yields to reactor */
void tap_yield();
void tap_yield_thread(_thread_t * thread);

/* returns the current thread */
_thread_t *tap_thread_self();

/* exit current thread */
void tap_thread_exit(void *retval);

/* create a new thread */
_thread_t *tap_thread_create(void *(*start) (void *arg), void *arg);

/* cancel a thread */
int tap_thread_cancel(_thread_t * thr);

/****************************************************** 
 *                         I/O
 ******************************************************/
#define _AIO_QUEUE_SIZE    (512)
#define _AIO_MAX_EVENTS    (512)
#define _EPOLL_QUEUE_SIZE  _AIO_QUEUE_SIZE
#define _EPOLL_MAX_EVENTS  _AIO_MAX_EVENTS
void tap_io_init(int id);
void tap_io_destroy(int id);

/*
 * check aio queue and epoll for ready threads
 */
int tap_io_poll(struct tap_list *list);

#endif
