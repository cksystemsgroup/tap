/* $Id: stack.h,v 1.6.2.2 2005/10/14 14:30:12 hroeck Exp $*/

/* 
 * Copyright (c) Harald Roeck hroeck@cs.uni-salzburg.at 
 *
 * University Salzburg, www.uni-salzburg.at
 * Department of Computer Science, cs.uni-salzburg.at
 */

/*  
 *  This program is free software; you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation; either version 2 of the License, or
 *  (at your option) any later version.
 *
 *  This program is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 *
 *  You should have received a copy of the GNU General Public License
 *  along with this program; if not, write to the Free Software
 *  Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 *
 */

/*
 * This header file defines a stack type used by
 * TAP library as call stack for threads
 *
 * This is the only point in the sources which does 
 * dynamic memory allocation for threads. Other necessary memory
 * for a thread should be used form the bottom the stack
 * and the stack pointer should be shifted.
 * 
 * FIXME: memory management
 */

#ifndef STACK_H
#define STACK_H

#include "debug.h"
#include <unistd.h>

typedef struct
{
  void *top;
  void *bottom;
  void *sp;                     /* stack pointer used by context switches */
  enum
  {
    STK_FIXED,                  /* stack is used by a context, no shifting */
    STK_FREE,                   /* allocated but not used by a context */
  } state:8;
} tap_stack_t;

static inline void stack_fix(tap_stack_t * stk)
{
  stk->state = STK_FIXED;
}

static inline size_t stack_usable_size(tap_stack_t * stk)
{
  return stk->top - stk->sp;
}

/* 
 * TODO: use better memory management 
 * probably a combination of mmap and a free list
 */
static inline tap_stack_t *stack_create(size_t size)
{
  void *stk;
  tap_stack_t *retval;

  /* FIXME: should the stack be aligned? */
  stk = malloc(size);
  memset(stk, 0, size);
  if (!stk)
    return NULL;

  retval = (tap_stack_t *) stk;
  retval->bottom = stk;
  retval->top = stk + size;
  retval->state = STK_FREE;

  retval->sp = stk + sizeof(tap_stack_t);

  return retval;
}

/*
 * free the stack
 */
static inline void stack_destroy(tap_stack_t * stk)
{
  internal(0, "destroy stack at %p", stk);
  free(stk->bottom);
}

/*
 * shift the useable stack by num bytes
 * and return the old address
 *
 * usefull for storing some stuff at the bottom of the stack
 * e.g. the thread object
 */
static inline void *stack_shift(tap_stack_t * stk, size_t num)
{
  void *retval = stk->sp;

  if (stk->state == STK_FIXED)
    return NULL;

  if (num > stack_usable_size(stk))
    tap_error(" stack_shift");

  stk->sp += (long) num;

  return retval;
}

#endif
