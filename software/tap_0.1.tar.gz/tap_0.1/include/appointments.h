/* $Id: appointments.h,v 1.1.2.1 2005/07/21 13:38:53 hroeck Exp $ */

/* 
 * Copyright (c) Harald Roeck hroeck@cs.uni-salzburg.at 
 *
 * University Salzburg, www.uni-salzburg.at
 * Department of Computer Science, cs.uni-salzburg.at
 */

/*  
 *  This program is free software; you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation; either version 2 of the License, or
 *  (at your option) any later version.
 *
 *  This program is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 *
 *  You should have received a copy of the GNU General Public License
 *  along with this program; if not, write to the Free Software
 *  Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 *
 */

#ifndef APPOINTMENTS_H
#define APPOINTMENTS_H

#include "threads_private.h"

/*
 * make an appointment for a thread
 * input params: thread, app
 *
 * writes thread context and adds 
 * the thread to a calendar
 */
void tap_get_appointment(_thread_t *thread, appointment_t *app);

/*
 * get the threads for the next appointment
 *
 * output params: *) ready: list of threads ready for the next app
 *                *) nready: threads not ready for next app
 * input params: *) id: process id
 */
void next_ready(tap_list_t *ready, tap_list_t *nready, int id);

#endif
