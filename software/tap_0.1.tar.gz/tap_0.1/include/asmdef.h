/* $Id: asmdef.h,v 1.2.2.3 2005/07/20 06:59:48 hroeck Exp $ */


/* 
 * Copyright (c) Harald Roeck hroeck@cs.uni-salzburg.at 
 *
 * University Salzburg, www.uni-salzburg.at
 * Department of Computer Science, cs.uni-salzburg.at
 */

/*
 *  This program is free software; you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation; either version 2 of the License, or
 *  (at your option) any later version.
 *
 *  This program is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 *
 *  You should have received a copy of the GNU General Public License
 *  along with this program; if not, write to the Free Software
 *  Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 *    /
 *
 */

#ifndef _ASM_DEF_H
#define _ASM_DEF_H 

/* There is some commonality.  */

#define END(sym) .size sym,.-sym;

#define JUMPTARGET(sym)		sym

#define	ENTRY(name)		      \
  .global name;				      \
  .type name, @function;    \
  .align 4;						      \
  name##:     				      \

#endif /* linux/i386/sysdep.h */
