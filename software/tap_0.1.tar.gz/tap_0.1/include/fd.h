/* $Id: fd.h,v 1.10.2.2 2005/07/08 13:13:15 hroeck Exp $ */

/* 
 * Copyright (c) Harald Roeck hroeck@cs.uni-salzburg.at 
 *
 * University Salzburg, www.uni-salzburg.at
 * Department of Computer Science, cs.uni-salzburg.at
 */

/*  
 *  This program is free software; you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation; either version 2 of the License, or
 *  (at your option) any later version.
 *
 *  This program is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 *
 *  You should have received a copy of the GNU General Public License
 *  along with this program; if not, write to the Free Software
 *  Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 *
 */

#ifndef FD_H
#define FD_H

#include "threads.h"
#include "list.h"

#include <libaio.h>
#include <sys/epoll.h>

#define ONE 1

struct _fdesc;
typedef enum
{
  FD_SOCKET = 1,
  FD_FILE,
  FD_PIPE,
} _fd_type;

/* 
 * FIXME support dup 
 */
typedef struct _fdesc
{
  int osfd;
  _fd_type type;
  tap_thread_t thread;          /* waiting thread for this fd */

  enum
  {
    FREE = 1,
    CLOSED,
  } state:4;

  unsigned int flags:4;
#define FD_DONE       ONE
#define FD_SUBMITTED (FD_DONE<<1)
#define FD_CANCELED  (FD_DONE<<2)

  short ref_count;

  union
  {
    struct                      /* files */
    {                           /* for async disk io */
      size_t off;               /* keep track of the offset */
      ssize_t res;              /* return value of read/write */
    } rw;

    struct                      /* sockets */
    {                           /* epoll structures */
      unsigned int ready;
#define SOCK_IN    ONE
#define SOCK_OUT   (ONE << 1)
#define SOCK_ERR   (ONE << 2)
      struct epoll_event event;
      struct tap_list accept_q;
    } sock;

    struct tap_list free_list; /* For putting on the free list */

  } u;

} _fd_t;

static inline void sock_set_in(_fd_t * fd)
{
  fd->u.sock.ready |= SOCK_IN;
}
static inline void sock_clear_in(_fd_t * fd)
{
  fd->u.sock.ready &= ~SOCK_IN;
}
static inline int sock_in(_fd_t * fd)
{
  return fd->u.sock.ready & SOCK_IN;
}

static inline void sock_set_err(_fd_t * fd)
{
  fd->u.sock.ready |= SOCK_ERR;
}
static inline void sock_clear_err(_fd_t * fd)
{
  fd->u.sock.ready &= ~SOCK_ERR;
}
static inline int sock_err(_fd_t * fd)
{
  return fd->u.sock.ready & SOCK_ERR;
}

static inline void sock_set_out(_fd_t * fd)
{
  fd->u.sock.ready |= SOCK_OUT;
}
static inline void sock_clear_out(_fd_t * fd)
{
  fd->u.sock.ready &= ~SOCK_OUT;
}
static inline int sock_out(_fd_t * fd)
{
  return fd->u.sock.ready & SOCK_OUT;
}

static inline void fd_set_canceled(_fd_t * fd)
{
  fd->flags |= FD_CANCELED;
}

static inline int fd_canceled(_fd_t * fd)
{
  return fd->flags & FD_CANCELED;
}

static inline void fd_clear_canceled(_fd_t * fd)
{
  fd->flags &= ~FD_CANCELED;
}

static inline void fd_clear_done(_fd_t * fd)
{
  fd->flags &= ~FD_DONE;
}
static inline void fd_set_done(_fd_t * fd)
{
  fd->flags |= FD_DONE;
}
static inline int fd_done(_fd_t * fd)
{
  return fd->flags & FD_DONE;
}

static inline void fd_clear_submitted(_fd_t * fd)
{
  fd->flags &= ~FD_SUBMITTED;
}

static inline void fd_set_submitted(_fd_t * fd)
{
  fd->flags |= FD_SUBMITTED;
}
static inline int fd_submitted(_fd_t * fd)
{
  return fd->flags & FD_SUBMITTED;
}

/*
 * return a pointer to an empty file descriptor
 */
_fd_t *fd_create(int osfd, _fd_type type);

/*
 * delete a filedescriptor
 */
int fd_destroy(_fd_t * fd);

#endif
