/* $Id: runq.h,v 1.6.2.4 2005/07/11 14:52:51 hroeck Exp $ */

/* 
 * Copyright (c) Harald Roeck hroeck@cs.uni-salzburg.at 
 *
 * University Salzburg, www.uni-salzburg.at
 * Department of Computer Science, cs.uni-salzburg.at
 */

/*
 *  This program is free software; you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation; either version 2 of the License, or
 *  (at your option) any later version.
 *
 *  This program is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 *
 *  You should have received a copy of the GNU General Public License
 *  along with this program; if not, write to the Free Software
 *  Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 *
 */

#ifndef RUNQ_H
#define RUNQ_H

#include "list.h"
#include "threads_private.h"

/* the runqueue */
typedef struct
{
  struct tap_list list;
  int len;
} runq_t;

/* traverse a run queue 
 *	runq is a pointer to a queue
 *	thr is the pointer to the actual thread
 */
#define runq_foreach(runq, thr)	\
		list_for_each_entry(thr, &runq->list, queue)

/*
 * init the runq;
 */
static inline void runq_init(runq_t * run_q)
{
  INIT_TAP_LIST(&run_q->list);
  run_q->len = 0;
}

/*
 *	return the length of the queue
 */
static inline int runq_length(runq_t * run_q)
{
  return run_q->len;
}

/* 
 * returns true if runq is empty
 */
static inline int runq_empty(runq_t * run_q)
{
  return !runq_length(run_q);
}

/*
 * append a thread at the end of the runqueue
 *
 */
static inline void runq_append(runq_t * run_q, _thread_t * thr)
{
  list_add_tail(&run_q->list, &thr->queue);
  run_q->len++;
}

/*
 * get the next thread 
 * and remove it from the runqueue
 */
static inline _thread_t *runq_next(runq_t * run_q)
{
  _thread_t *thr;

  if (list_empty(&run_q->list))
    return NULL;

  thr = list_entry(run_q->list.next, _thread_t, queue);
  list_del_init(run_q->list.next);
  run_q->len--;

  prefetch(run_q->list.next);
  return thr;
}

/*
 * print the runq
 * for debugging
 */
static inline void runq_print(runq_t * run_q)
{
  _thread_t *thr;
  if (run_q->len)
  {
    internal(0, " queue length %d: ", run_q->len);
    runq_foreach(run_q, thr)
    {
      internal(0, " --> [%d]", thr->tid);
    }

  }
}

#endif

