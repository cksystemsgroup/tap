/* $Id: httpd_posix_cache.c,v 1.1.2.1 2005/10/14 14:30:12 hroeck Exp $*/

#ifndef _GNU_SOURCE
#define _GNU_SOURCE
#endif

#define TAP_PTHREAD
/* http server - posix implementation */
#include <pthread.h>

#include <stdio.h>
#include <string.h>
#include <assert.h>             // for assert

#include <netinet/in.h>
#include <netinet/tcp.h>
#include <sys/socket.h>
#include <sys/stat.h>
#include <sys/time.h>
#include <sys/types.h>
#include <netinet/in.h>

#include <sys/stat.h>           // for struct stat
#include <fcntl.h>              // for open
#include <stdlib.h>             // for atoi

#include <errno.h>
#include <unistd.h>

static int port = 10080;
static int num_threads = 164;
static unsigned long num_connections = 0;

#define NUM_THREADS		num_threads     // num of threads
#define MAX_REQUEST_HEADER	512     // max length of header

#include <sys/time.h>
#include <time.h>

#include "cache.h"

#include "http.h"


typedef long long _utime_t;

static inline _utime_t get_utime()
{
  struct timeval tv;
  gettimeofday(&tv, NULL);
	return (tv.tv_sec * 1000000LL + tv.tv_usec);
}

int createListener(int port)
{
  int listenfd;
  struct sockaddr_in serveraddr;
  int so_reuseaddr = 1;
  int res;

  // SOCKET
  listenfd = socket(PF_INET, SOCK_STREAM, 0);
  if (listenfd < 0)
  {
    printf("Socket failed\n");
    exit(0);
  }
  // SETSOCKOPT
  res = setsockopt(listenfd, SOL_SOCKET, SO_REUSEADDR,
                   &so_reuseaddr, sizeof(so_reuseaddr));
  if (res < 0)
  {
    printf("Setsockopt failed\n");
    exit(0);
  }

  memset(&serveraddr, 0, sizeof(serveraddr));
  serveraddr.sin_family = PF_INET;
  serveraddr.sin_addr.s_addr = htonl(INADDR_ANY);
  serveraddr.sin_port = port;


  // BIND
  res = bind(listenfd, (struct sockaddr *) &serveraddr, sizeof(serveraddr));
  if (res < 0)
  {
    printf("Bind failed\n");
    exit(0);
  }

  // LISTEN
  res = listen(listenfd, 5 );
	
  if (res < 0)
  {
    printf("Listen failed\n");
    exit(0);
  }

  return listenfd;
}

static inline int write_to_network(int sockfd, char *buf, int write_len)
{
  ssize_t wrote_total = 0;
  ssize_t wrote_len = 0;

  while (wrote_total < write_len)
  {
    wrote_len = write(sockfd, buf + wrote_total, 
				write_len-wrote_total<1024?write_len-wrote_total:1024);
    if (wrote_len < 0)
    {
      printf("Write failed\n");
      return -1;
    }
    wrote_total += wrote_len;
  }

  return 0;
}

int write_error(int sockfd, int error)
{
  char *outbuf;

  switch (error)
  {
  case 400:
    outbuf =
      "HTTP/1.0 400 Bad Request\nContent-Type: text/plain\n\n400 Bad Request.\n";
    break;

  case 403:
    outbuf =
      "HTTP/1.0 403 Forbidden\nContent-Type: text/plain\n\n403 Forbidden.\n";
    break;

  case 404:
    outbuf =
      "HTTP/1.0 404 Not Found\nContent-Type: text/plain\n\n404 Not Found.\n";
    break;

  case 501:
    outbuf =
      "HTTP/1.0 501 Method Not Implemented\nContent-Type: text/plain\n\n501 Method Not Implemented.\n";
    break;
  }

  printf("-- Error no %d\n", error);
	return  write_to_network(sockfd, outbuf, strlen(outbuf));
}

void *handler(void *arg)
{
  int listenfd;
  int connectfd;
  struct sockaddr_in client_address;
  socklen_t client_length;
  char *filename = NULL;
		http_request request;

  memcpy(&listenfd, arg, sizeof(int));
  client_length = sizeof(client_address);

  while (1)
	{
		// ACCEPT A NEW CLIENT
		connectfd =
			accept(listenfd, (struct sockaddr *) &client_address, &client_length);
		if (connectfd < 0)
		{
			printf("Accept failed\n");
			continue;
		}
		// turn off Nagle, so pipelined requests don't wait unnecessarily.
		if( 1 ) {
			int optval = 1;
			//if (setsockopt (sock, IPPROTO_TCP, TCP_NODELAY, &optval, sizeof (optval)) < 0)
			if (setsockopt (connectfd, SOL_TCP, TCP_NODELAY, &optval, sizeof (optval)) < 0)

			{
				perror("setsockopt");
				continue;
			}
		}


		http_init(&request, connectfd);

		if(http_parse(&request) && !request.closed) 
			filename = request.url;
		else
			filename = NULL;

		if (filename)
		{
			struct entry *e;

			e = cache_get(filename);

			if(e)
			{
				// SEND THE HEADER
				if (write_to_network(connectfd, e->e_header, e->e_hlength) < 0)
				{
					printf("Write failed\n");
					close(connectfd);
					cache_release(e);
					continue;
				}

				write_to_network(connectfd, e->e_buffer, e->e_bytes);

				cache_release(e);
			}
			else
				fprintf(stderr, "no entry: %d %s\n", errno, strerror(errno));
		}
		else
			fprintf(stderr, " no filename \n");
		close(connectfd);
		num_connections++;
	}
  return NULL;
}

void usage()
{
  printf(" usage: httpd [port number] [number of threads]\n");
  exit(0);
}

int main(int argc, char *argv[])
{
  int listenfd;
  pthread_t *threads;           //[NUM_THREADS];
  int i, retval, status;


  if (argc == 3)
  {
    printf("Port number: %d. Using %d threads\n", atoi(argv[1]), atoi(argv[2]));
    port = atoi(argv[1]);
    NUM_THREADS = atoi(argv[2]);
    argc--;
    argv++;
  }
  if (argc != 2)
    usage();

	cache_init(32);

  threads = (pthread_t *) malloc(NUM_THREADS * sizeof(pthread_t));

  listenfd = createListener(htons(port));
  printf("Create listener finished\n");

  // FIXME
  // thread = pthread_self();

  printf("Start creating %d threads\n", NUM_THREADS);

  for (i = 0; i < NUM_THREADS; i++)
  {
    retval = pthread_create(threads + i, NULL, handler, (void *) &listenfd);
		if(retval)
		{
			printf("ERROR pthread_create: %d %s\n", errno, strerror(errno));
		}
    // printf("Created thread no %d\n", i);
  }

  printf("Finished creating threads\n");
  for (i = 0; i < NUM_THREADS; i++)
    pthread_join(threads[i], (void **) &status);

	printf("Joined all threads: main thread exiting\n");
	pthread_exit(0);
	return 0;
}
