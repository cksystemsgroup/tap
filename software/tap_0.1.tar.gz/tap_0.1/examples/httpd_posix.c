/* $Id: httpd_posix.c,v 1.10.2.8 2005/10/14 14:30:12 hroeck Exp $*/

#ifndef _GNU_SOURCE
#define _GNU_SOURCE
#endif

/* http server - posix implementation */
#include <pthread.h>

#include <stdio.h>
#include <string.h>
#include <assert.h>             // for assert

// #include <sys/types.h>
#include <sys/socket.h>
#include <netinet/in.h>

#include <sys/stat.h>           // for struct stat
#include <fcntl.h>              // for open
#include <stdlib.h>             // for atoi

#include <errno.h>

static int port = 10080;
static int num_threads = 164;
static unsigned long num_connections = 0;

#define ALIGN			    (512)
#define FILEBUFLEN		(4*1024)
#define NUM_THREADS		num_threads     // num of threads
#define MAX_REQUEST_HEADER	512     // max length of header

#include <time.h>

typedef long long _utime_t;

static inline _utime_t get_utime()
{
  struct timeval tv;
  gettimeofday(&tv, NULL);
	return (tv.tv_sec * 1000000LL + tv.tv_usec);
}


/* alloc page alligned buffer */
char *malloc_filebuf(int size, size_t * shifted)
{
  char *p, *o;
  int i;

  // alocate enough space to align p
  if ((p = (char *) malloc(size + ALIGN)) == NULL)
  {
    printf("Malloc of the read buffer failed\n");
    exit(0);
  }

  // save original pointer
  o = p;

  // align p
  p += (ALIGN - 1);
  p = (char *) ((unsigned long) p & ~(ALIGN - 1));

  /* touch each page, do not want page faults for test */
  /* actually touching each "sector" */
  for (i = 0; i < (size >> 9); i++)
  {
    char *pp = p;
    *pp = 1;
    pp += 512;
  }

  *shifted = p - o;
  return p;
}

int createListener(int port)
{
  int listenfd;
  struct sockaddr_in serveraddr;
  int so_reuseaddr = 1;
  int res;

  // SOCKET
  listenfd = socket(AF_INET, SOCK_STREAM, 0);
  if (listenfd < 0)
  {
    printf("Socket failed\n");
    exit(0);
  }

  memset(&serveraddr, 0, sizeof(serveraddr));
  serveraddr.sin_family = AF_INET;
  serveraddr.sin_addr.s_addr = htonl(INADDR_ANY);
  serveraddr.sin_port = port;

  // SETSOCKOPT
  res = setsockopt(listenfd, SOL_SOCKET, SO_REUSEADDR,
                   &so_reuseaddr, sizeof(so_reuseaddr));
  if (res < 0)
  {
    printf("Setsockopt failed\n");
    exit(0);
  }

  // BIND
  res = bind(listenfd, (struct sockaddr *) &serveraddr, sizeof(serveraddr));
  if (res < 0)
  {
    printf("Bind failed\n");
    exit(0);
  }

  // LISTEN
  res = listen(listenfd, 1);
  if (res < 0)
  {
    printf("Listen failed\n");
    exit(0);
  }

  return listenfd;
}

int write_to_network(int sockfd, char *buf, int write_len)
{
  ssize_t wrote_total = 0;
  ssize_t wrote_len = 0;

  while (wrote_total < write_len)
  {
    wrote_len = write(sockfd, buf + wrote_total, write_len - wrote_total);
    if (wrote_len < 0)
    {
      printf("Write failed\n");
      return -1;
    }
    wrote_total += wrote_len;
  }

  return 0;
}

int write_error(int sockfd, int error)
{
  char *outbuf;

  switch (error)
  {
  case 400:
    outbuf =
      "HTTP/1.0 400 Bad Request\nContent-Type: text/plain\n\n400 Bad Request.\n";
    break;

  case 403:
    outbuf =
      "HTTP/1.0 403 Forbidden\nContent-Type: text/plain\n\n403 Forbidden.\n";
    break;

  case 404:
    outbuf =
      "HTTP/1.0 404 Not Found\nContent-Type: text/plain\n\n404 Not Found.\n";
    break;

  case 501:
    outbuf =
      "HTTP/1.0 501 Method Not Implemented\nContent-Type: text/plain\n\n501 Method Not Implemented.\n";
    break;
  }

  printf("-- Error no %d\n", error);
  write_to_network(sockfd, outbuf, strlen(outbuf));
}

/*
 * read the header sent by the client
 * GET filename ...
 */
int read_request_header(int sockfd, char *buf, int buf_len)
{
  int this_read_len;
  int read_total = 0;

  // printf("Read request header\n");
  do
  {
    this_read_len = read(sockfd, buf + read_total, buf_len - read_total);
    if (this_read_len == 0)
      break;

    if (this_read_len < 0)
    {
      printf("Read request header failed\n");
      break;
    }

    read_total += this_read_len;
    assert(read_total <= buf_len);
  }
  while (read_total < 4 || memcmp(buf + read_total - 4, "\r\n\r\n", 4) != 0);

  // printf("- Read total %d\n", read_total);
  return read_total;
}

/*
 * Parse the header read by read_request_header
 * Return filename
 */
char *parse_request_header(int sockfd, char *buf, int buf_len)
{
  char *filename, *end_filename;

  if (memcmp(buf, "GET ", 4) != 0)
  {
    printf("It's not a GET, send 501\n");
    write_error(sockfd, 501);
    return NULL;
  }

  filename = buf + 4;
  end_filename = strchr(filename, ' ');
  assert(end_filename == NULL || (end_filename - buf) < buf_len);

  // It's a GET
  // printf("It's a get\n");
  if (strstr(filename, "..") != NULL)
  {
    printf("It's not allowed ..\n");
    write_error(sockfd, 400);
    return NULL;
  }

  *end_filename = '\0';

  return filename;
}

/*
 * copy from file to network
 */
int copy(int from, int to, char *filebuf, int filesize)
{
  int total, current;
  int reached_eof = 0;

  total = 0;

  do
  {
    // read from file
    current = read(from, filebuf, FILEBUFLEN);
    if (current == 0)
    {
      reached_eof = 1;
    }
    else if (current < 0)
    {
      printf("Read from file failed\n");
      break;
    }

    if (filesize - total < FILEBUFLEN)
      current = filesize - total;

    // write to network
    if (write_to_network(to, filebuf, current) < 0)
    {
      printf("Write to network failed\n");
      break;
    }

    total += current;
  }
  while (!reached_eof);

  return total;
}

void *handler(void *arg)
{
  int listenfd;
  int connectfd;
  struct sockaddr_in client_address;
  socklen_t client_length;
  int request_header_len = 0;
  char *filename = NULL;
  char *filebuf;
  int shifted;
  char request_header[MAX_REQUEST_HEADER];
	_utime_t now;

  memcpy(&listenfd, arg, sizeof(int));
	printf("malloc a filebuffer of size %d\n", FILEBUFLEN);
  filebuf = malloc_filebuf(FILEBUFLEN, &shifted);
  client_length = sizeof(client_address);

  while (1)
  {
    // ACCEPT A NEW CLIENT
    connectfd =
      accept(listenfd, (struct sockaddr *) &client_address, &client_length);
    if (connectfd < 0)
    {
      printf("Accept failed\n");
      continue;
    }

		now = get_utime();

    // READ THE HEADER
    request_header_len =
      read_request_header(connectfd, request_header, MAX_REQUEST_HEADER);
    if (request_header_len < 0)
    {
      close(connectfd);
      continue;
    }

    filename = parse_request_header(connectfd, request_header,
                                    MAX_REQUEST_HEADER);
//              printf("Try to open the file %s\n", filename);

    if (filename)
    {
      int filefd;
      filename -= 1;
      filename[0] = '.';

      // OPEN THE FILE
      filefd = open(filename, O_RDONLY | O_DIRECT, 0);
      if (filefd < 0)
      {
        printf("Open file failed\n");

        if (errno == EEXIST)
          write_error(connectfd, 404);
        else if (errno == EACCES)
          write_error(connectfd, 403);
        else
          write_error(connectfd, 400);
      }
      else
      {
        struct stat fstat_buf;
        int file_size, copied;

//                              printf("Open succeded, create header\n");

        // CREATE THE HEADER
        if (fstat(filefd, &fstat_buf) == 0)
          file_size = fstat_buf.st_size;
        else
          file_size = 0;

        snprintf(filebuf, FILEBUFLEN,
                 "HTTP/1.0 200 OK\nContent-Type: text/plain\n"
                 "Content-Lenght: %d\n\n", file_size);

        // SEND THE HEADER
        if (write_to_network(connectfd, filebuf, strlen(filebuf)) < 0)
        {
          printf("Write failed\n");
          close(connectfd);
          close(filefd);
          continue;
        }

        //                      printf("Send the file\n");
        copied = copy(filefd, connectfd, filebuf, file_size);
        if (copied != file_size)
          printf("Did not sent the whole file: copied (%d) file size (%d)\n",
                 copied, file_size);

        close(filefd);
      }
    }
    close(connectfd);
    num_connections++;
		fprintf(stderr, "%ld us for connection\n", (get_utime()-now)); 
  }
  free(filebuf - shifted);
  return NULL;
}

void usage()
{
  printf(" usage: httpd [port number] [number of threads]\n");
  exit(0);
}

int main(int argc, char *argv[])
{
  int listenfd;
  pthread_t *threads;           //[NUM_THREADS];
  int i, retval, status;


  if (argc == 3)
  {
    printf("Port number: %d. Using %d threads\n", atoi(argv[1]), atoi(argv[2]));
    port = atoi(argv[1]);
    NUM_THREADS = atoi(argv[2]);
    argc--;
    argv++;
  }
  if (argc != 2)
    usage();

  threads = (pthread_t *) malloc(NUM_THREADS * sizeof(pthread_t));

  listenfd = createListener(htons(port));
  printf("Create listener finished\n");

  // FIXME
  // thread = pthread_self();

  printf("Start creating %d threads\n", NUM_THREADS);

  for (i = 0; i < NUM_THREADS; i++)
  {
    retval = pthread_create(threads + i, NULL, handler, (void *) &listenfd);
		if(retval)
		{
			printf("ERROR pthread_create: %d %s\n", errno, strerror(errno));
		}
    // printf("Created thread no %d\n", i);
  }

  printf("Finished creating threads\n");
  for (i = 0; i < NUM_THREADS; i++)
    pthread_join(threads[i], (void **) &status);

	printf("Joined all threads: main thread exiting\n");
	pthread_exit(0);
}
