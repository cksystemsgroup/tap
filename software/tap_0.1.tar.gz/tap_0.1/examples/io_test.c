#include "pthread.h"

#include <unistd.h>
#include <fcntl.h>

#define MAX	1024*1024

/* alloc page alligned buffer */
char *malloc_filebuf(int size, size_t * shifted)
{

  char *p, *o;
  int i;

  /* page align the record buffer */
  if ((p = (char *) malloc(size + 4096)) == NULL)
  {
    perror("malloc of read buffer");
    return (NULL);
  }
  /* safe original pointer */
  o = p;

  /* user read buffer is page aligned */
  p += (4096 - 1);
  p = (char *) ((unsigned long) p & ~(4096 - 1));

  /* touch each page, do not want page faults for test */
  /* actually touching each "sector" */
  for (i = 0; i < (size >> 9); i++)
  {

    char *pp = p;
    *pp = 1;
    pp += 512;
  }
  *shifted = p - o;
  return (p);
}

int main()
{
  int fd_read, fd_write, bytes_read, i;
  char *buf;
  size_t shift;

  buf = malloc_filebuf(MAX, &shift);
  for (i = 0; i < MAX; ++i)
    buf[i] = '1';

  fd_read = open("test_in.txt", O_RDONLY);
  bytes_read = read(fd_read, buf, MAX);
  buf[bytes_read] = '\0';
  printf("Read: --%s--", buf);
  printf("\nSize: %d\n", bytes_read);
  close(fd_read);

  //fd_write = creat("test_out.txt", S_IRWXU);
  //write(fd_write, buf, bytes_read);
  //close(fd_write);
  return 0;
}
