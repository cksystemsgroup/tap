/* $Id: main.c,v 1.7.2.1 2005/07/06 06:37:46 hroeck Exp $*/
/* 
 * Copyright (c) Harald Roeck hroeck@cs.uni-salzburg.at 
 *
 * University Salzburg, www.uni-salzburg.at
 * Department of Computer Science, cs.uni-salzburg.at
 */

/*  
 *  This program is free software; you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation; either version 2 of the License, or
 *  (at your option) any later version.
 *
 *  This program is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 *
 *  You should have received a copy of the GNU General Public License
 *  along with this program; if not, write to the Free Software
 *  Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 *
 */

#include "threads.h"
#include "debug.h"

#include <stdlib.h>
#include <string.h>
#include <errno.h>

#define NUM_THREADS 4
#define FBUFF_SIZE  512
#define ALIGN       512

/* alloc page alligned buffer */
char *malloc_filebuf(int size)
{

  char *p;
  int i;

  /* page align the record buffer */
  if ((p = (char *) malloc(size + ALIGN)) == NULL)
  {

    perror("malloc of read buffer");
    return (NULL);
  }

  /* user read buffer is page aligned */
  p += (ALIGN - 1);
  p = (char *) ((unsigned long) p & ~(ALIGN - 1));

  /* touch each page, do not want page faults for test */
  /* actually touching each "sector" */
  for (i = 0; i < (size >> 9); i++)
  {

    char *pp = p;
    *pp = 1;
    pp += 512;
  }
  return (p);
}

void *one(void *arg)
{
  char *buff = malloc_filebuf(5);
  size_t len = 5;
  int total_len = 0;
  char *msg = "5 characters asdfasdf:  ";
  char *fbuff = malloc_filebuf(FBUFF_SIZE);
  tap_fd_t fd;
  char filename[32];

  strncpy(fbuff, msg, strlen(msg));
  snprintf(filename, 32, "test_file_%d.txt", tap_getid());

  debug(2, "errno at %p", &errno);

  fd = tap_open(filename, O_WRONLY | O_CREAT | O_APPEND, S_IRUSR | S_IWUSR);
  if (!fd)
  {
    debug(0, " ERROR open file");
    tap_thread_exit(NULL);
  }
  debug(0, " fd: %p, osfd: %d, fbuff %s", fd, tap_osfd(fd), fbuff);

  debug(0, " %s %s %d ", __FILE__, __FUNCTION__, __LINE__);

  tap_write(fd, fbuff, FBUFF_SIZE);
  debug(0, " %s %s %d ", __FILE__, __FUNCTION__, __LINE__);

  tap_close(fd);

  memset(fbuff, 0, strlen(msg));
  fd = tap_open(filename, O_RDONLY, S_IRUSR);
  if (!fd)
  {
    debug(0, " ERROR open file 2");
    tap_thread_exit(NULL);
  }
  len = 0;
  len = tap_read(fd, fbuff + total_len, FBUFF_SIZE);
  write(1, fbuff, len);
  write(1, "\n", 1);
  /*
     while((len = tap_do_io(READ,fd, fbuff+total_len, FBUFF_SIZE-total_len))) 
     {
     total_len+=len; 
     if (total_len != FBUFF_SIZE)
     continue;

     debug(2, "total_len %d", total_len);
     debug(0, " %s %s %d ", __FILE__, __FUNCTION__, __LINE__); 

     //tap_do_io(WRITE,fd, buff, len); 
     write(1, fbuff, total_len); 
     write(1, "\n", 1);
     total_len = 0;
     }
     if(total_len)
     {
     debug(2, "total_len %d", total_len);
     debug(0, " %s %s %d ", __FILE__, __FUNCTION__, __LINE__); 

     //tap_do_io(WRITE,fd, buff, len); 
     fbuff[total_len -1] = '\n';
     write(1, fbuff, total_len); 
     }
   */
  tap_close(fd);
  debug(0, " %s %s %d ", __FILE__, __FUNCTION__, __LINE__);
}

int main(int argc, char **argv)
{
  int i;
  tap_thread_t thr;
  int count = 0;

  for (i = 0; i < NUM_THREADS; ++i)
  {
    thr = tap_thread_create(one, NULL);
    if (thr)
      ++count;
  }

  debug(3, "created %d threads", count);

	tap_thread_exit(0);
  return 0;
}
