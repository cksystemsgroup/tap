/* $Id: echodth.c,v 1.2.2.1 2005/07/06 06:37:46 hroeck Exp $ */
/* Copyright (c) 2004 Peter Palfrader <peter@palfrader.org> */

/* Simple multi-threaded echo server, using blocking IO */

#include "threads.h"

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <assert.h>
#include <signal.h>
#include <arpa/inet.h>
#include <errno.h>

#define PORT 10007
#define BUFLEN 512
#define FAIL -1
#define NUM_THREADS  3

static tap_thread_t threads[NUM_THREADS];

/* alloc page alligned buffer */
#define ALIGN 512
char *malloc_filebuf(int size)
{

  char *p;
  int i;

  /* page align the record buffer */
  if ((p = (char *) malloc(size + ALIGN)) == NULL)
  {

    perror("malloc of read buffer");
    return (NULL);
  }

  /* user read buffer is page aligned */
  p += (ALIGN - 1);
  p = (char *) ((unsigned long) p & ~(ALIGN - 1));

  /* touch each page, do not want page faults for test */
  /* actually touching each "sector" */
  for (i = 0; i < (size >> 9); i++)
  {

    char *pp = p;
    *pp = 1;
    pp += 512;
  }
  return (p);
}

tap_fd_t createListener(int port)
{
  tap_fd_t listenfd;
  struct sockaddr_in servaddr;
  int so_reuseaddr = 1;
  int res;

  listenfd = tap_socket(AF_INET, SOCK_STREAM, 0);
  printf(" socket finished \n");
  if (tap_osfd(listenfd) == 0)
  {
    fprintf(stderr, "Socket failed %d %s\n", errno, strerror(errno));
    exit(1);
  };

  memset(&servaddr, 0, sizeof(servaddr));
  servaddr.sin_family = AF_INET;
  servaddr.sin_addr.s_addr = htonl(INADDR_ANY);
  servaddr.sin_port = port;

  res = setsockopt(tap_osfd(listenfd), SOL_SOCKET,
                   SO_REUSEADDR, &so_reuseaddr, sizeof(so_reuseaddr));
  if (res == FAIL)
  {
    fprintf(stderr, "setsockopt failed %d: %d %s\n",
            res, errno, strerror(errno));
    exit(1);
  };

  res = tap_bind(listenfd, (struct sockaddr *) &servaddr, sizeof(servaddr));
  printf(" bind finished \n");
  if (res == FAIL)
  {
    fprintf(stderr, "Bind failed: %d %s\n", errno, strerror(errno));
    exit(1);
  };

  res = tap_listen(listenfd, 1);
  printf(" listen finished \n");
  if (res == FAIL)
  {
    fprintf(stderr, "Listen failed: %d %s\n", errno, strerror(errno));
    exit(1);
  };

  return listenfd;
}

void *handler(void *arg)
{
  tap_fd_t listenfd;
  tap_fd_t connfd;
  tap_fd_t filefd;
  ssize_t read_len, wrote_total;
  struct sockaddr_in cliaddr;
  socklen_t clilen;
  ssize_t wrote_len;
  char *buf;
  char filename[32];
  int quit = 0;
  memcpy(&listenfd, arg, sizeof(tap_fd_t));

  printf(" start first accept %p \n", tap_thread_self());
  fflush(stdout);

  buf = malloc_filebuf(BUFLEN);

  snprintf(filename, 32, "input_%d.txt", tap_getid());

  filefd = tap_open(filename, O_WRONLY | O_CREAT | O_APPEND, S_IRUSR | S_IWUSR);

  while (1)
  {
    clilen = sizeof(cliaddr);

    connfd = tap_accept(listenfd, (struct sockaddr *) &cliaddr, &clilen);

    if (tap_osfd(connfd) == FAIL)
    {
      fprintf(stderr, "Accept failed: %d %s\n", errno, strerror(errno));
      exit(1);
    };
    printf("Connection accepted by %p.\n", tap_thread_self());

    while (1)
    {
      do
      {
        debug(3, "read fd %p, osfd", connfd, tap_osfd(connfd));
        read_len = tap_read(connfd, buf, BUFLEN);
      }
      while (read_len < 0 && errno == EAGAIN);
      write(1, buf, read_len);

      if (strncasecmp(buf, "quit", 4) == 0)
      {
        read_len = 0;
        quit = 1;
      }
      if (read_len == FAIL)
      {
        fprintf(stderr, "Read failed: %d %s\n", errno, strerror(errno));
        exit(1);
      };

      if (read_len == 0)
      {
        debug(3, "close fd %p", connfd);
        tap_close(connfd);
        break;
      };
      tap_write(filefd, buf, read_len);

      assert(read_len > 0);
      wrote_total = 0;
      while (wrote_total < read_len)
      {
        debug(3, "write fd %p, osfd", connfd, tap_osfd(connfd));
        wrote_len = tap_write(connfd, buf + wrote_total, read_len -
                              wrote_total);
        /* XXX: ditto to read above.  EINTR? */
        if (wrote_len == FAIL)
        {
          fprintf(stderr, "Write failed: %d %s\n", errno, strerror(errno));
          exit(1);
        }
        wrote_total += wrote_len;
      }
    }

    if (quit)
      break;
  }
  tap_close(filefd);
}

int main(int argc, char **argv)
{
  tap_fd_t listenfd;
  tap_thread_t thread;
  int i;

  printf(" tap init finished \n");

  listenfd = createListener(htons(PORT));
  printf(" createListener finished \n");
  //sleep(2);
  thread = tap_thread_self();
  printf(" start creating threads %p \n", thread);

  for (i = 0; i < NUM_THREADS - 1; ++i)
  {
    threads[i] = tap_thread_create(handler, (void *) &listenfd);
    printf(" %d created thread %p \n", i, threads[i]);
    if (!thread)
      sleep(2);
  }
  threads[i] = tap_thread_create(handler, (void *) &listenfd);
  printf(" %d created thread %p \n", i, threads[i]);

  sleep(2);
	tap_thread_exit(0);
  return 0;
}
