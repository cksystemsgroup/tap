#include <stdio.h>
#include <pthread.h>
// #include <unistd.h>

void *thread_handler(void *arg)
{
  pthread_t t1, t2;

  // tap_yield();
  t1 = pthread_self();
  t2 = pthread_self();
  if (pthread_equal(t1, t2))
  {
    printf("pthread_equal success\n");
  }
  printf("I'm a thread with pid=%d\n", getpid());
  // tap_yield();
  pthread_exit((void *) 0);
}

int main()
{
  const int n = 5;
  int i, rc, status;
  pthread_t threads[n];
  pthread_attr_t attr;

  // set the threads joinable
  pthread_attr_init(&attr);
  pthread_attr_setdetachstate(&attr, PTHREAD_CREATE_JOINABLE);

  // create the threads
  for (i = 0; i < n; i++)
  {

    printf("Creating thread nr %d\n", i);
    rc = pthread_create(threads + i, &attr, thread_handler, NULL);
    if (rc)
      printf("*** Error creating thread %i\n", i);
  }

  printf("Finished with creating threads\n");
  // pthread_attr_destroy(&attr);

  // join the threads
  /*for(i=0; i<n; i++)
     {
     // till now pthread_join function is not available
     // rc = pthread_join(threads[i], (void **)&status);
     if (rc)
     printf("*** Error joining the thread %i\n",i);
     } */


	pthread_exit(0);
  return 0;
}
