/* $Id: echodth2.c,v 1.3.2.2 2005/07/06 06:37:46 hroeck Exp $ */
/* Copyright (c) 2004 Peter Palfrader <peter@palfrader.org> */

/* Simple multi-threaded echo server, using blocking IO */

#include "threads.h"
#include "debug.h"

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <assert.h>
#include <arpa/inet.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <fcntl.h>
#include <errno.h>

#define PORT 10007
#define BUFLEN 8
#define FAIL -1
#define NUM_THREADS  5

tap_fd_t createListener(int port)
{
  tap_fd_t listenfd;
  struct sockaddr_in servaddr;
  int so_reuseaddr = 1;
  int res;

  listenfd = tap_socket(AF_INET, SOCK_STREAM, 0);
  debug(3, "socket finished");
  if (listenfd == 0)
  {
    fprintf(stderr, "Socket failed %d %s\n", errno, strerror(errno));
    exit(1);
  };

  memset(&servaddr, 0, sizeof(servaddr));
  servaddr.sin_family = AF_INET;
  servaddr.sin_addr.s_addr = htonl(INADDR_ANY);
  servaddr.sin_port = port;

  res = setsockopt(tap_osfd(listenfd), SOL_SOCKET,
                   SO_REUSEADDR, &so_reuseaddr, sizeof(so_reuseaddr));
  if (res == FAIL)
  {
    fprintf(stderr, "setsockopt failed %d: %d %s\n",
            res, errno, strerror(errno));
    exit(1);
  };

  res = tap_bind(listenfd, (struct sockaddr *) &servaddr, sizeof(servaddr));
  debug(3, "bind finished");
  if (res == FAIL)
  {
    fprintf(stderr, "Bind failed: %d %s\n", errno, strerror(errno));
    exit(1);
  };

  res = tap_listen(listenfd, 1);
  debug(3, "listen finished");
  if (res == FAIL)
  {
    fprintf(stderr, "Listen failed: %d %s\n", errno, strerror(errno));
    exit(1);
  };

  return listenfd;
}

void *handler(void *arg)
{
  tap_fd_t connfd;
  ssize_t read_len, wrote_total;
  ssize_t wrote_len;
  char buf[BUFLEN];
//  tap_fd_t filefd;

  memcpy(&connfd, arg, sizeof(tap_fd_t));

  debug(3, "Connection accepted by");

  while (1)
  {
    do
    {
      read_len = tap_read(connfd, buf, BUFLEN);
    }
    while (read_len < 0 && errno == EAGAIN);
    if (read_len == FAIL)
    {
      fprintf(stderr, "Read 2 failed: %d %s\n", errno, strerror(errno));
      tap_thread_exit(0);
    }
    if (read_len == 0)
    {
      //tap_close(filefd);
      break;
    }
    wrote_total = 0;
    while (wrote_total < read_len)
    {
      wrote_len = tap_write(connfd, buf + wrote_total, read_len - wrote_total);
      if (wrote_len == FAIL)
      {
        fprintf(stderr, "Write failed: %d %s\n", errno, strerror(errno));
        tap_thread_exit(0);
      };
      wrote_total += wrote_len;
    }
  }
  tap_close(connfd);
  //}
}

int main(int argc, char **argv)
{
  tap_fd_t listenfd, connfd;
  tap_thread_t thread;

  struct sockaddr_in cliaddr;
  socklen_t clilen;

  debug(3, "tap init aa finished");

  listenfd = createListener(htons(PORT));
  debug(3, "createListener finished");

  debug(3, "start accepting", thread);

  clilen = sizeof(cliaddr);
  while (1)
  {
    connfd = tap_accept(listenfd, (struct sockaddr *) &cliaddr, &clilen);
    debug(3, " accepted %p", connfd);
    if (!connfd)
    {
      fprintf(stderr, "Accept failed: %d %s\n", errno, strerror(errno));
      exit(1);
    };

    thread = tap_thread_create(handler, (void *) &connfd);
    debug(3, "created thread");
  }

	tap_thread_exit(0);
  return 0;
}
