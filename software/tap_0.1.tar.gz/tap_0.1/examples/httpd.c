/* $Id: httpd.c,v 1.2.2.1 2005/07/06 06:37:46 hroeck Exp $ */
/* Copyright (c) 2004, 2005 Peter Palfrader <peter@palfrader.org> */
/* Copyright (c) 2004 Harald Roeck <hroeck@cosy.sbg.ac.at> */

/* http server */

#include "threads.h"
#include <errno.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <assert.h>
#include <arpa/inet.h>
#include <signal.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <fcntl.h>

static int port = 10080;
#define PORT port

#define EAGAIN_THRES 20

#define BUFLEN 4096
/* #define FILEBUFLEN 16K */
#define FILEBUFLEN 1024*16
#define FAIL -1
static int num_threads = 512;
#define NUM_THREADS  num_threads

#define dbg_printf(...) debug(2, __VA_ARGS__)

/* alloc page alligned buffer */
char *malloc_filebuf(int size)
{

  char *p;
  int i;

  /* page align the record buffer */
  if ((p = (char *) malloc(size + 4096)) == NULL)
  {
    perror("malloc of read buffer");
    return (NULL);
  }

  /* user read buffer is page aligned */
  p += (4096 - 1);
  p = (char *) ((unsigned long) p & ~(4096 - 1));

  /* touch each page, do not want page faults for test */
  /* actually touching each "sector" */
  for (i = 0; i < (size >> 9); i++)
  {

    char *pp = p;
    *pp = 1;
    pp += 512;
  }
  return (p);
}

static unsigned long long num_connections = 0;

tap_fd_t createListener(int port)
{
  tap_fd_t listenfd;
  struct sockaddr_in servaddr;
  int so_reuseaddr = 1;
  int res;

  printf("[%p] before socket\n", tap_thread_self());
  listenfd = tap_socket(AF_INET, SOCK_STREAM, 0);
  printf(" socket finished \n");
  if (tap_osfd(listenfd) == 0)
  {
    fprintf(stderr, "Socket failed %d %s\n", errno, strerror(errno));
    exit(1);
  };

  memset(&servaddr, 0, sizeof(servaddr));
  servaddr.sin_family = AF_INET;
  servaddr.sin_addr.s_addr = htonl(INADDR_ANY);
  servaddr.sin_port = port;

  res =
    setsockopt(tap_osfd(listenfd), SOL_SOCKET, SO_REUSEADDR, &so_reuseaddr,
               sizeof(so_reuseaddr));
  if (res == FAIL)
  {
    fprintf(stderr, "setsockopt failed %d: %d %s\n", res, errno,
            strerror(errno));
    exit(1);
  };

  res = tap_bind(listenfd, (struct sockaddr *) &servaddr, sizeof(servaddr));
  printf(" bind finished \n");
  if (res == FAIL)
  {
    fprintf(stderr, "Bind failed: %d %s\n", errno, strerror(errno));
    exit(1);
  };

  res = tap_listen(listenfd, 1);
  printf(" listen finished \n");
  if (res == FAIL)
  {
    fprintf(stderr, "Listen failed: %d %s\n", errno, strerror(errno));
    exit(1);
  };

  return listenfd;
}

int write_stuff_to_network(ssize_t write_len, char *outbuf, tap_fd_t connfd,
                           char *filename, int error);
void *handler(void *arg)
{
  int no_eagains, no_weagains, no_deagains;
  tap_fd_t listenfd;
  tap_fd_t connfd;
  ssize_t read_total;
  ssize_t this_read_len;
  struct sockaddr_in cliaddr;
  socklen_t clilen;
  ssize_t write_len;
  char *buf;
  char *filebuf;
  ssize_t buf_len;
  ssize_t filebuf_len = FILEBUFLEN;
  char *outbuf;
  char *filename = NULL;

  memcpy(&listenfd, arg, sizeof(tap_fd_t));

  filebuf = malloc_filebuf(FILEBUFLEN);
  buf = malloc(BUFLEN);

  printf("[%p] buf at %p\n", tap_thread_self(), filebuf);
  buf_len = BUFLEN;
  clilen = sizeof(cliaddr);
  while (1)
  {
    /* reset eagain counters */
    no_weagains = 0;
    no_eagains = 0;
    no_deagains = 0;

    dbg_printf("start accepting");
    connfd = tap_accept(listenfd, (struct sockaddr *) &cliaddr, &clilen);

    dbg_printf("accepted fd %d", tap_osfd(connfd));

    if (!connfd)
    {
      dbg_printf("accept failed %d", errno);
      fprintf(stderr, "Accept failed: %d %s\n", errno, strerror(errno));
      continue;
    };

    this_read_len = -2;
    read_total = 0;
    do
    {
      dbg_printf("Doing read (we are at %d, may read up to %d chars)",
                 (int) read_total, (int) (buf_len - read_total));

      this_read_len = tap_read(connfd, buf + read_total, buf_len - read_total);

      dbg_printf("net read got %d bytes", this_read_len);

      if (this_read_len == 0)
        break;
      if (this_read_len < 0)
      {
        if (errno != EAGAIN)
        {                       /* What about EINTR? */
          fprintf(stderr, "Read failed: %s (%d)\n", strerror(errno), errno);
          break;
        }
        else
        {
          no_eagains++;
          if (no_eagains > EAGAIN_THRES)
            read_total = buf_len;

          continue;
        }
      }
      read_total += this_read_len;
      assert(read_total <= buf_len);

    }
    while (read_total < 4 || memcmp(buf + read_total - 4, "\r\n\r\n", 4) != 0);

    if (this_read_len < 0)
    {
      /* close socket and goto accept */
      tap_close(connfd);
      continue;
    }
    if (this_read_len == 0)
    {
      if (no_eagains > EAGAIN_THRES)
        printf
          (" [%p] closing connection because of too many EAGAINs after read \n",
           tap_thread_self());
      else
        dbg_printf(" connection closed by foreign host");

      tap_close(connfd);
      continue;
    }

    if (memcmp(buf, "GET ", 4) != 0)
    {
      dbg_printf(" Not a GET.");
      outbuf =
        "HTTP/1.0 501 Method Not Implemented\nContent-Type: text/plain\n\n501 Method Not Implemented.\n";
      write_len = strlen(outbuf);
    }
    else
    {
      filename = buf + 4;
      char *eofilename = strchr(filename, ' ');
      assert(eofilename == NULL || (eofilename - buf) < buf_len);

      dbg_printf("It's a GET.");

      if (eofilename != NULL)
        *eofilename = '\0';

      if (eofilename == NULL || strstr(filename, "..") != NULL)
      {
        dbg_printf("But a bad filename.");
        outbuf =
          "HTTP/1.0 400 Bad Request\nContent-Type: text/plain\n\n400 Bad Request.\n";
        write_len = strlen(outbuf);
        no_weagains =
          write_stuff_to_network(write_len, outbuf, connfd, filename, 0);
        debug(1, "write_stuff returned %s %d", __FILE__, __LINE__);
      }
      else
      {
        tap_fd_t file;
        filename -= 2;
        filename[0] = '.';
        filename[1] = '/';
        dbg_printf("Try to open '%s'", filename);
        file = tap_open(filename, O_RDONLY, 0);
        dbg_printf("finished open");
        if (file)
        {
          int reached_eof = 0;
          int reached_error = 0;
          ssize_t read_len;
          ssize_t write_len;
          struct stat fstat_buf;
          int fsize;

          dbg_printf(" open succeeded");
          dbg_printf(" create header");
          if (fstat(tap_osfd(file), &fstat_buf) == 0)
            fsize = fstat_buf.st_size;
          else
            fsize = 0;

          snprintf(filebuf, FILEBUFLEN,
                   "HTTP/1.0 200 OK\nContent-Type: text/plain\n"
                   "Content-Length: %d\n\n", fsize);

          dbg_printf("going to send header");
          no_weagains +=
            write_stuff_to_network(strlen(filebuf), filebuf, connfd, filename,
                                   0);
          debug(1, "write_stuff returned %s %d", __FILE__, __LINE__);
          do
          {
            dbg_printf("read from file...");
            read_len = tap_read(file, filebuf, filebuf_len);
            dbg_printf("got %d from file", read_len);
            write_len = read_len;
            if (read_len == 0)
            {
              reached_eof = 1;
            }
            else if (read_len < 0)
            {
              if (errno != EAGAIN)
              {                 /* What about EINTR? */
                char *head =
                  "HTTP/1.0 400 read failed\nContent-Type: text/plain\n\n";
                dbg_printf(" read failed: %s (%d)", strerror(errno), errno);

                strncpy(filebuf, head, FILEBUFLEN);
                snprintf(filebuf + strlen(head), FILEBUFLEN,
                         "Read failed: %s (%d)", strerror(errno), errno);
                read_total = strlen(filebuf);
                reached_error = 1;

                no_weagains +=
                  write_stuff_to_network(read_total, filebuf, connfd, filename,
                                         1);
                debug(1, "write_stuff returned %s %d", __FILE__, __LINE__);
                break;
              }
              else
              {
                ++no_deagains;
                continue;
              }
            }

            assert(read_len <= filebuf_len);
            assert(write_len <= filebuf_len);

            outbuf = filebuf;

            if (!reached_eof)
            {
              int ret =
                write_stuff_to_network(write_len, filebuf, connfd, filename, 0);
              debug(1, "write_stuff returned %d %s %d", ret, __FILE__,
                    __LINE__);
              if (ret < 0)
                reached_error = 1;
              else
                no_weagains += ret;
            }
          }
          while (!reached_eof);

          if (reached_eof)
            dbg_printf("reached eof, closing");
          else if (reached_error)
            dbg_printf("had error, closing");
          else
            dbg_printf("I have no idea why I'm here, closing");

          dbg_printf("Doing close for file.");
          tap_close(file);
        }
        else
        {
          dbg_printf("open failed");
          if (errno == EEXIST)
          {
            outbuf =
              "HTTP/1.0 404 Not Found\nContent-Type: text/plain\n\n404 Not Found.\n";
            write_len = strlen(outbuf);
          }
          else if (errno == EACCES)
          {
            outbuf =
              "HTTP/1.0 403 Forbidden\nContent-Type: text/plain\n\n403 Forbidden.\n";
            write_len = strlen(outbuf);
          }
          else
          {
            outbuf =
              "HTTP/1.0 400 Unkown Error\nContent-Type: text/plain\n\n400 Unkown Error.\n";
            write_len = strlen(outbuf);
          }
          no_weagains =
            write_stuff_to_network(write_len, outbuf, connfd, filename, 1);
          debug(1, "write_stuff returned %d %s %d", no_weagains, __FILE__,
                __LINE__);
        }
      }
    }
    dbg_printf("Doing close for connfd");
    tap_close(connfd);
    dbg_printf("closed");
    ++num_connections;

    fprintf(stderr,
            "[%p] got %d EAGAINS, %d on read, %d on write, %d on disc\n",
            tap_thread_self(), no_eagains + no_weagains + no_deagains,
            no_eagains, no_weagains, no_deagains);
  };
  free(filebuf);
  free(buf);
  return NULL;
}

int write_stuff_to_network(ssize_t write_len, char *outbuf, tap_fd_t connfd,
                           char *filename, int error)
{
  ssize_t wrote_total = 0;
  ssize_t wrote_len = 0;
  int no_eagains = 0;
  dbg_printf("Entering write_stuff_to_network() for %s, %d bytes",
             filename, write_len);

  while (wrote_total < write_len)
  {
    dbg_printf(" Doing write, file %s", filename);
    wrote_len =
      tap_write(connfd, outbuf + wrote_total, write_len - wrote_total);

    if (wrote_len == FAIL && errno == EAGAIN)
    {
      no_eagains++;
      if (no_eagains > EAGAIN_THRES)
      {
        tap_write(connfd, outbuf, 0);
        wrote_total = write_len;
        break;
      }
      continue;
    }
    if (wrote_len == FAIL)
    {
      debug(0, "Write failed: %d %s\n", errno, strerror(errno));

      return -1;
    };
    wrote_total += wrote_len;
  };

  if (no_eagains > EAGAIN_THRES)
    printf(" [%p] closing connection because of too many EAGAINs after write\n",
           tap_thread_self());

  return no_eagains;
}

void usage()
{
  printf(" usage: httpd [port number] [number of threads]\n");
  exit(0);
}

int main(int argc, char **argv)
{
  tap_fd_t listenfd;
  tap_thread_t thread;
  int i;

  printf("call init\n");
  printf("argc %d\n", argc);
  if (argc > 1)
  {
    printf(" using port %d\n", atoi(argv[1]));
    PORT = atoi(argv[1]);
    --argc;
    ++argv;
  }
  if (argc > 1)
  {
    printf(" using %d threads \n", atoi(argv[1]));
    NUM_THREADS = atoi(argv[1]);
    --argc;
    ++argv;
  }
  if (argc != 1)
    usage();

  listenfd = createListener(htons(PORT));
  printf(" createListener finished \n");

  thread = tap_thread_self();
  printf(" start creating %d threads %p \n", NUM_THREADS, thread);

  for (i = 0; i < NUM_THREADS - 1; ++i)
  {
    thread = tap_thread_create(handler, (void *) &listenfd);
    dbg_printf(" %d created thread %p \n", i, thread);
    if (!thread)
      sleep(2);
  }
  thread = tap_thread_create(handler, (void *) &listenfd);
  dbg_printf(" %d created thread %p ", i, thread);

  printf(" finished creating threads\n");

  sleep(1);
  tap_thread_exit(0);
  /* is never reached */
  return 0;
}

/* vim:set ts=4: */
