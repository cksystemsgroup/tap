/* $Id: httpd2.c,v 1.8.2.5 2005/07/25 10:51:26 hroeck Exp $ */
/* Copyright (c) 2004 Harald Roeck <hroeck@cosy.sbg.ac.at> */

/* http server */

#include "threads.h"
#include <errno.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <assert.h>
#include <arpa/inet.h>
#include <netinet/tcp.h>
#include <netinet/in.h>
#include <signal.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <fcntl.h>
#include <signal.h>

static int port = 10080;
#define PORT port

#define MAX_REQUEST_HEADER 512
#define MAX_HEADER         512

/* #define FILEBUFLEN 16K */
#define FILEBUFLEN (512)
#define FAIL -1

#define ALIGN 512

static int num_threads = 64;
#define NUM_THREADS  num_threads

#define dbg_printf(...) debug(2, __VA_ARGS__)

/* alloc page alligned buffer */
char *malloc_filebuf(int size, size_t * shifted)
{

  char *p, *o;
  int i;

  /* page align the record buffer */
  if ((p = (char *) malloc(size + ALIGN)) == NULL)
  {
    perror("malloc of read buffer");
    return (NULL);
  }
  /* safe original pointer */
  o = p;

  /* user read buffer is page aligned */
  p += (ALIGN - 1);
  p = (char *) ((unsigned long) p & ~(ALIGN - 1));

  /* touch each page, do not want page faults for test */
  /* actually touching each "sector" */
  for (i = 0; i < (size >> 9); i++)
  {

    char *pp = p;
    *pp = 1;
    pp += 512;
  }
  *shifted = p - o;
  return (p);
}

static unsigned long long num_connections = 0;

tap_fd_t createListener(int port)
{
  tap_fd_t listenfd;
  struct sockaddr_in servaddr;
  int so_reuseaddr = 1;
  int res;

  printf("[%p] before socket\n", tap_thread_self());
  listenfd = tap_socket(AF_INET, SOCK_STREAM, 0);
  printf(" socket finished \n");
  if (tap_osfd(listenfd) == 0)
  {
    fprintf(stderr, "Socket failed %d %s\n", errno, strerror(errno));
    exit(1);
  };

  memset(&servaddr, 0, sizeof(servaddr));
  servaddr.sin_family = AF_INET;
  servaddr.sin_addr.s_addr = htonl(INADDR_ANY);
  servaddr.sin_port = port;

  res =
    setsockopt(tap_osfd(listenfd), SOL_SOCKET, SO_REUSEADDR, &so_reuseaddr,
               sizeof(so_reuseaddr));
  if (res == FAIL)
  {
    fprintf(stderr, "setsockopt failed %d: %d %s\n", res, errno,
            strerror(errno));
    exit(1);
  };

  res = tap_bind(listenfd, (struct sockaddr *) &servaddr, sizeof(servaddr));
  printf(" bind finished \n");
  if (res == FAIL)
  {
    fprintf(stderr, "Bind failed: %d %s\n", errno, strerror(errno));
    exit(1);
  };

  res = tap_listen(listenfd, 1);
  printf(" listen finished \n");
  if (res == FAIL)
  {
    fprintf(stderr, "Listen failed: %d %s\n", errno, strerror(errno));
    exit(1);
  };

  return listenfd;
}

int write_to_network(tap_fd_t connfd, char *buf, int write_len)
{
  ssize_t wrote_total = 0;
  ssize_t wrote_len = 0;
  int no_eagains = 0;

  //printf("Writting %s\n", buf);
  while (wrote_total < write_len)
  {
    wrote_len = tap_write(connfd, buf + wrote_total, write_len - wrote_total);

    if (wrote_len == FAIL)
    {
      printf("Write failed: %d %s\n", errno, strerror(errno));

      return -1;
    }
    wrote_total += wrote_len;
  }

  return 0;
}

int write_error(tap_fd_t connfd, int error)
{
  char *outbuf;

  switch (error)
  {
  case 400:
    outbuf =
      "HTTP/1.0 400 Bad Request\nContent-Type: text/plain\n\n400 Bad Request.\n";
    break;
  case 501:
    outbuf =
      "HTTP/1.0 501 Method Not Implemented\nContent-Type: text/plain\n\n501 Method Not Implemented.\n";
    break;
  case 404:
    outbuf =
      "HTTP/1.0 404 Not Found\nContent-Type: text/plain\n\n404 Not Found.\n";
    break;
  case 403:
    outbuf =
      "HTTP/1.0 403 Forbidden\nContent-Type: text/plain\n\n403 Forbidden.\n";
    break;
  }

  printf("-- Error no %d\n", error);
  write_to_network(connfd, outbuf, strlen(outbuf));
}

int read_request_header(tap_fd_t connfd, char *buf, int buf_len)
{
  int this_read_len;
  int read_total = 0;

  debug(0, " read request header");
  do
  {
    this_read_len = tap_read(connfd, buf + read_total, buf_len - read_total);

    debug(1, "net read got %d bytes", this_read_len);

    if (this_read_len == 0)
      break;
    if (this_read_len < 0)
    {
      debug(1, "Read request header failed: %s (%d)", strerror(errno), errno);
      if (!read_total)
        read_total = -1;
      break;
    }
    read_total += this_read_len;
    assert(read_total <= buf_len);
  }
  while (read_total < 4 || memcmp(buf + read_total - 4, "\r\n\r\n", 4) != 0);

//  printf("- Read total %d\n", read_total);
  return read_total;
}

char *parse_request_header(tap_fd_t connfd, char *buf, int buf_len)
{
  char *filename, *eofilename;
  if (memcmp(buf, "GET ", 4) != 0)
  {
    debug(0, "It's not a GET, send 501.");
    write_error(connfd, 501);
    return NULL;
  }
  else
  {
    filename = buf + 4;
    eofilename = strchr(filename, ' ');
    assert(eofilename == NULL || (eofilename - buf) < buf_len);

    debug(0, "It's a GET.");

    if (eofilename == NULL || strstr(filename, "..") != NULL)
    {
      debug(0, "wrong file name");
      write_error(connfd, 400);
      return NULL;
    }
    else
      *eofilename = '\0';
  }

  return filename;
}

int copy(tap_fd_t from, tap_fd_t to, char *filebuf)
{
  int total, current;
  int reached_eof = 0;

  total = 0;
  do
  {
    current = tap_read(from, filebuf, FILEBUFLEN);
    if (current == 0)
    {
      reached_eof = 1;
    }
    else if (current == -1)
    {
      debug(0, "error read file: %d %s", errno, strerror(errno));
      break;
    }

    if (write_to_network(to, filebuf, current) == -1)
    {
      debug(0, "error write_network");
      break;
    }
    total += current;
  }
  while (!reached_eof);

  return total;
}

void *handler(void *arg)
{
  tap_fd_t listenfd;
  tap_fd_t connfd;
  struct sockaddr_in cliaddr;
  socklen_t clilen;
  int request_header_len = 0;
  char *filename = NULL;
  char *filebuf;
  int shifted;
  char request_header[MAX_REQUEST_HEADER];
  int optval = 1;

  memcpy(&listenfd, arg, sizeof(tap_fd_t));

  filebuf = malloc_filebuf(FILEBUFLEN, &shifted);

  clilen = sizeof(cliaddr);
  while (1)
  {
    dbg_printf("start accepting");
    connfd = tap_accept(listenfd, (struct sockaddr *) &cliaddr, &clilen);

    dbg_printf("accepted fd %d", tap_osfd(connfd));

    if (!connfd)
    {
      dbg_printf("accept failed %d", errno);
      fprintf(stderr, "Accept failed: %d %s\n", errno, strerror(errno));
      continue;
    };

    setsockopt(tap_osfd(connfd), SOL_TCP, TCP_NODELAY, &optval, sizeof(optval));
    request_header_len =
      read_request_header(connfd, request_header, MAX_REQUEST_HEADER);
    if (request_header_len < 0)
    {
      tap_close(connfd);
      continue;
    }

    filename = parse_request_header(connfd, request_header, request_header_len);

    if (filename)
    {
      tap_fd_t file;
      filename -= 1;
      filename[0] = '.';

      dbg_printf("Try to open '%s'", filename);

      file = tap_open(filename, O_RDONLY, 0);

      if (file == NULL)
      {
        printf("open failed %s: %d %s\n", filename, errno, strerror(errno));
				
        if (errno == EEXIST)
          write_error(connfd, 404);
        else if (errno == EACCES)
          write_error(connfd, 403);
        else
          write_error(connfd, 400);
      }
      else
      {
        struct stat fstat_buf;
        int fsize, copied;

        debug(0, " open succeeded, create header");

        if (fstat(tap_osfd(file), &fstat_buf) == 0)
          fsize = fstat_buf.st_size;
        else
          fsize = 0;

        snprintf(filebuf, FILEBUFLEN,
                 "HTTP/1.0 200 OK\nContent-Type: text/plain\n"
                 "Content-Length: %d\n\n", fsize);

        dbg_printf("going to send header");
        if (write_to_network(connfd, filebuf, strlen(filebuf)) == -1)
        {
          debug(0, " write failed, closing file and socket");
          tap_close(connfd);
          tap_close(file);
          continue;
        }

        copied = copy(file, connfd, filebuf);

        if (copied != fsize)
          debug(0, "did not send whole file!");

        debug(3, " sent file %s, size is %d bytes, and I sent %d bytes",
              filename, fsize, copied);
        tap_close(file);
      }
    }
    tap_close(connfd);
    ++num_connections;
  }

  free(filebuf - shifted);
  return NULL;
}

void usage()
{
  printf(" usage: httpd [port number] [number of threads]\n");
  tap_kill(NULL);
}

void sighandler(int sig)
{
  printf("got SIGINT, exiting ...\n");
	tap_kill(NULL);
  exit(0);
}

int main(int argc, char **argv)
{
  tap_fd_t listenfd;
  tap_thread_t thread;
  int i;

  printf("call init\n");
  printf("argc %d\n", argc);

  signal(SIGINT, sighandler);

  if (argc > 1)
  {
    printf(" using port %d\n", atoi(argv[1]));
    PORT = atoi(argv[1]);
    --argc;
    ++argv;
  }
  if (argc > 1)
  {
    printf(" using %d threads \n", atoi(argv[1]));
    NUM_THREADS = atoi(argv[1]);
    --argc;
    ++argv;
  }
  if (argc != 1)
    usage();

  listenfd = createListener(htons(PORT));
  printf(" createListener finished \n");

  thread = tap_thread_self();
  printf(" start creating %d threads %p \n", NUM_THREADS, thread);

  for (i = 0; i < NUM_THREADS; ++i)
  {
    thread = tap_thread_create(handler, (void *) &listenfd);
    debug(1, " %d created thread %p \n", i, thread);
  }

  printf(" finished creating threads\n");
	tap_thread_exit(0);

  return 0;
}
