/* $Id: cache.c,v 1.1.2.4 2005/10/14 14:50:16 hroeck Exp $*/

/* 
 * Copyright (c) Harald Roeck hroeck@cs.uni-salzburg.at 
 *
 * University Salzburg, www.uni-salzburg.at
 * Department of Computer Science, cs.uni-salzburg.at
 */

/*  
 *  This program is free software; you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation; either version 2 of the License, or
 *  (at your option) any later version.
 *
 *  This program is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 *
 *  You should have received a copy of the GNU General Public License
 *  along with this program; if not, write to the Free Software
 *  Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 *
 */




#ifndef _GNU_SOURCE
#define _GNU_SOURCE
#endif
#include "cache.h"
#include <errno.h>
#include <fcntl.h>
#include <stdio.h>
#include <string.h>
#include <unistd.h>
#include <sys/stat.h>           // for struct stat
#include <assert.h>

#define ALIGN 512
#define MAX_CACHE (64*1024*1024)


struct cache_table
{
	int size;
	struct tap_list *table;
};

/* a sorted list of cache entries
 * order them after the last touched
 */
static struct tap_list c_sorted; 
static size_t csize = 0;

static struct cache_table cache; 



/*
 * hash function
 */
static int hash(char *s)
{
	char *num;
	unsigned int h;

	h =0;
	for ( num = s; *num; num++)
		h = (h >> 28)^(h<<4) ^ *num;
	
	h = h%cache.size;
	return h ;
}

static inline int entry_add_ref(struct entry* e)
{
	
	if(e != NULL)
	{
		return ++e->e_ref_count;
	}
	else
		return -1;
}

/*
 * called from the initial thread
 */
int cache_init(int size)
{
	static int init = 0;
	int i;
	void *p;
	if(init)
	{
		errno = EINVAL;
		return -1;
	}
	init =1;	
	
	memset(&cache, 0, sizeof(cache));
	/* init cache vector */
	p = malloc(size * sizeof(struct cache_table));
	if(!p)
	{
		errno = ENOMEM;
		return -1;
	}
	
	cache.table = p;
	cache.size = size;

	printf("table at %p, size %d\n", cache.table, cache.size);
	for(i=0;i<size;++i)
	{
		INIT_TAP_LIST(&cache.table[i]);
	}
	
	/* init sorted list */
	INIT_TAP_LIST(&c_sorted);

	return 0;
}

/*
 * mark entry as last used
 */ 
static int entry_touch(struct entry *e)
{
	/* move entry to the tail of list */
	if(list_empty(&e->e_sorted))
	{
		entry_add_ref(e);
		csize += e->e_size;
	}
	else
		list_del(&e->e_sorted);
	
	list_add_tail(&c_sorted, &e->e_sorted);
	
	return 0;
}
/*
 * remove old entries if cache gets to big
 */
static inline  int cache_prune(int max_csize)
{
	int entries;
	struct entry* e;
	while(csize > max_csize)
	{
		/* remove entry from sorted list */
		e = list_entry(c_sorted.next, struct entry, e_sorted);
		
		if( e->e_sorted.next == (&c_sorted))
			break;

		list_del(&e->e_sorted);


		/* remove entry from hash table */
		list_del(&e->e_list);

		/* decrement reference count twice
		 * one for the hashtable
		 * and one for the sorted list
		 */
		cache_release(e);
		cache_release(e);
		
	
	}
	return 0;
}


int free_entry(struct entry *e)
{
	free(e->e_p);
	free(e);
	
	return 0;
}

int cache_release(struct entry* e)
{
	int ref;
	if(e != NULL)
	{
		ref = --e->e_ref_count;
		if(ref == 0)
		{
			free_entry(e);
		}
	}
	return 0;
}

/*
 * alloc buffer and align it
 *
 * change entry members only if successfull
 * otherwise entry is untouched
 */
static int entry_malloc_buf(struct entry *e, size_t size)
{
	void *p = NULL;

	size_t nsize = size + ALIGN -1;
	nsize = nsize & ~(ALIGN -1);
	
	p = malloc(nsize + ALIGN);
	if(!p)
	{
		errno = ENOMEM;
		return -1;
	}
	e->e_p = p;
	e->e_buffer = e->e_p + ALIGN -1;
	e->e_buffer = (void*)((unsigned long)e->e_buffer& ~(ALIGN -1));
	e->e_size = nsize;
	return 0;
}

static void entry_free(struct entry *e)
{
	if(e != NULL)
	{
		assert(!e->e_ref_count);
		free(e->e_p);
		csize -= e->e_size;
		e->e_size = 0;
		e->e_buffer = NULL;
	}
}
/* read whole file into a cache entry 
 * entry is already in the hash table
 *
 */ 
static int entry_fill(struct entry *e)
{
	int total_read, last_read;
	char *name;
	int fd;


	name = e->e_name;
	fd = open(name, O_RDONLY | O_DIRECT, 0);
	if(fd < 0)
	{
		total_read = -errno;
		fprintf(stderr, "error open: %d %s\n", errno, strerror(errno));
		goto out;
	}

	struct stat fstat_buf;
	fstat(fd, &fstat_buf);
	if( entry_malloc_buf(e, fstat_buf.st_size) == -1 )
	{
		total_read = -ENOMEM;
		goto out_file;
	}

	total_read = 0;
//	while( (
				last_read = read(fd, 
					e->e_buffer + total_read, 
					e->e_size - total_read)
					;
//				) > 0 )
//	{
		total_read += last_read;
//	}
	if(last_read < 0)
	{
		total_read = -errno;
		goto out_file;		
	}

	e->e_bytes = fstat_buf.st_size;

	e->e_hlength = snprintf(e->e_header, MAX_HEADER, 
						"HTTP/1.0 200 OK\r\nContent-Type: text/html\r\n"
						"Content-Lenght: %d\r\n\r\n", e->e_bytes);

out_file:
	close(fd);

out:
	return total_read;
}


/*
 * init entry struct
 */
static int entry_init(struct entry *e, char *filename)
{	

	memset(e, 0, sizeof(struct entry));

	INIT_TAP_LIST(&e->e_sorted);
	INIT_TAP_LIST(&e->e_list);

	strncpy(e->e_name, filename, MAX_NAME);

	return 0;
}

static inline struct entry *entry_malloc()
{
	struct entry *e;

	e = (struct entry*)malloc(sizeof(struct entry));

	return e;
}

static inline struct entry *list_search(struct tap_list *b, char *filename)
{
	struct entry *retval = NULL;
	struct entry *e;
	
	list_for_each_entry(e, b, e_list)
	{
		if(!strcmp(filename, e->e_name))
		{
			retval = e;
			break;
		}
	}

	return retval;
}

static inline void list_add_entry(struct tap_list *b, struct entry *e)
{
	list_add(b, &e->e_list);
	entry_add_ref(e);
}

static inline struct entry *cache_search(char *filename)
{
	int key;
	struct entry *e, *e2;
	struct tap_list *b;

	key = hash(filename);
	
	b = &cache.table[key];

	e = list_search(b, filename);
	
	if(e == NULL)
	{
		e = entry_malloc();
		
		/* init data structure */
		entry_init(e, filename);

		/* fill entry by reading from disk */
		entry_fill(e);
		
		/* check if some other thread 
		 * inserted an entry in the 
		 * mean time
		 */
		e2 = list_search(b, filename);
		if(!e2)
			list_add_entry(b, e);
		else
		{
			entry_free(e);
			e = e2;
		}
	}
	return e;
}

struct entry *cache_get(char *filename)
{
	struct entry *e;
	int ret;
	
	/*
	 * get entry from hash table;
	 * if not there insert one
	 */
	e = cache_search(filename);

	/* got one reference more */
	entry_add_ref(e);

	/* touch it */
	entry_touch(e);

	/* prune the cache */
	cache_prune(MAX_CACHE);

	return e;
}
