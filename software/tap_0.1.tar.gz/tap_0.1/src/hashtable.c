/* $Id: hashtable.c,v 1.10.2.2 2005/07/08 13:13:15 hroeck Exp $*/

/* 
 * Copyright (c) Petru Flueras petru.flueras@cs.uni-salzburg.at 
 *
 * University Salzburg, www.uni-salzburg.at
 * Department of Computer Science, cs.uni-salzburg.at
 */

/*  
 *  This program is free software; you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation; either version 2 of the License, or
 *  (at your option) any later version.
 *
 *  This program is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 *
 *  You should have received a copy of the GNU General Public License
 *  along with this program; if not, write to the Free Software
 *  Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 *
 */

#include "hashtable.h"
#include "threads.h"

int hash_init(hashtable * hash, hash_function function)
{
  int i;

  if (hash == NULL)
    return -1;
  if (function == NULL)
    return -1;

  hash->get_hash = function;
  for (i = 0; i < MAX; i++)
    INIT_TAP_LIST(&(hash->hash_list[i]));
}

/*
 * Get all the elements with the
 * same hash number like key
 */
struct tap_list *hash_get(hashtable * hash, int key)
{
  unsigned hash_no = hash->get_hash(key);

  return &(hash->hash_list[hash_no]);
}

/*
 * the duplication of keys is not treated
 */
void hash_put(hashtable * hash, int key, struct tap_list *queue)
{
  unsigned hash_no = hash->get_hash(key);

  internal(6, "Put hash key -%u-", hash_no);
  list_add(&(hash->hash_list[hash_no]), queue);
}

void hash_rem(struct tap_list *queue)
{
  list_del(queue);
}

/*
 * Test if the specified hash entry
 * is empty
 */
int hash_entry_empty(struct tap_list *queue)
{
  return list_empty(queue);
}
