/* $Id: io.c,v 1.23.2.21 2005/10/14 14:30:12 hroeck Exp $ */

/* 
 * Copyright (c) Harald Roeck hroeck@cs.uni-salzburg.at 
 *
 * University Salzburg, www.uni-salzburg.at
 * Department of Computer Science, cs.uni-salzburg.at
 */

/*  
 *  This program is free software; you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation; either version 2 of the License, or
 *  (at your option) any later version.
 *
 *  This program is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 *
 *  You should have received a copy of the GNU General Public License
 *  along with this program; if not, write to the Free Software
 *  Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 *
 */
#ifndef _GNU_SOURCE
#define _GNU_SOURCE
#endif

//#ifndef _POSIX_SOURCE
//#define _POSIX_SOURCE
//#endif
#include "debug.h"
#include "threads_private.h"
#include "fd.h"
#include "config.h"
#include "process.h"
#include "profile.h"

#include <fcntl.h>
#include <errno.h>
#include <assert.h>

#include <libaio.h>             /* disc aio */
#include <sys/epoll.h>          /* new linux event polling */

// EPOLLONESHOT is sometimes(e.g. Debian) not defined
#ifndef EPOLLONESHOT
#define EPOLLONESHOT  (1<<30)
#endif


#include <sys/syscall.h>        /* syscall interface */
#include <sys/socket.h>         /* socket calls */
////#include <linux/net.h>

#define SYS_SOCKET  1   /* sys_socket(2)    */
#define SYS_BIND  2   /* sys_bind(2)      */
#define SYS_CONNECT 3   /* sys_connect(2)   */
#define SYS_LISTEN  4   /* sys_listen(2)    */
#define SYS_ACCEPT  5   /* sys_accept(2)    */
#define SYS_GETSOCKNAME 6   /* sys_getsockname(2)   */
#define SYS_GETPEERNAME 7   /* sys_getpeername(2)   */
#define SYS_SOCKETPAIR  8   /* sys_socketpair(2)    */
#define SYS_SEND  9   /* sys_send(2)      */
#define SYS_RECV  10    /* sys_recv(2)      */
#define SYS_SENDTO  11    /* sys_sendto(2)    */
#define SYS_RECVFROM  12    /* sys_recvfrom(2)    */
#define SYS_SHUTDOWN  13    /* sys_shutdown(2)    */
#define SYS_SETSOCKOPT  14    /* sys_setsockopt(2)    */
#define SYS_GETSOCKOPT  15    /* sys_getsockopt(2)    */
#define SYS_SENDMSG 16    /* sys_sendmsg(2)   */
#define SYS_RECVMSG 17    /* sys_recvmsg(2)   */


/* set the fd nonblocking */
static inline void fd_set_nb(int fd)
{
  int val = fcntl(fd, F_GETFL, 0);
  fcntl(fd, F_SETFL, val | O_NONBLOCK);
}

/* set the fd blocking */
static inline void fd_set_bl(int fd)
{
  int val = fcntl(fd, F_GETFL, 0);
  fcntl(fd, F_SETFL, val & ~O_NONBLOCK);
}

/*********************************************
 * internal wrappers for the socket system calls
 *********************************************/
#define __socketcall(call, args)	\
		syscall(SYS_socketcall, call, args)

static inline int _socket(int family, int type, int protocol)
{
  unsigned long args[3];

  args[0] = family;
  args[1] = type;
  args[2] = (unsigned long) protocol;
  return __socketcall(SYS_SOCKET, args);
}

static inline int _accept(int s, struct sockaddr *addr, socklen_t * addrlen)
{
  unsigned long args[3];

  args[0] = s;
  args[1] = (unsigned long) addr;
  args[2] = (unsigned long) addrlen;
  return __socketcall(SYS_ACCEPT, args);
}

static inline int _listen(int sockfd, int backlog)
{
  unsigned long args[2];

  args[0] = sockfd;
  args[1] = backlog;
  return __socketcall(SYS_LISTEN, args);
}

static inline int _bind(int sockfd, const struct sockaddr *myaddr,
                        socklen_t addrlen)
{
  unsigned long args[3];

  args[0] = sockfd;
  args[1] = (unsigned long) myaddr;
  args[2] = addrlen;
  return __socketcall(SYS_BIND, args);
}

static inline int _connect(int sockfd, const struct sockaddr *saddr,
                           socklen_t addrlen)
{
  unsigned long args[3];

  args[0] = sockfd;
  args[1] = (unsigned long) saddr;
  args[2] = addrlen;
  return __socketcall(SYS_CONNECT, args);
}

static inline int _getpeername(int sockfd, struct sockaddr *addr,
                               socklen_t * paddrlen)
{
  unsigned long args[3];

  args[0] = sockfd;
  args[1] = (unsigned long) addr;
  args[2] = (unsigned long) paddrlen;
  return __socketcall(SYS_GETPEERNAME, args);
}

static inline int _getsockname(int sockfd, struct sockaddr *addr,
                               socklen_t * paddrlen)
{
  unsigned long args[3];

  args[0] = sockfd;
  args[1] = (unsigned long) addr;
  args[2] = (unsigned long) paddrlen;
  return __socketcall(SYS_GETSOCKNAME, args);
}

static inline int _getsockopt(int fd, int level, int optname, __ptr_t optval,
                              socklen_t * optlen)
{
  unsigned long args[5];

  args[0] = fd;
  args[1] = level;
  args[2] = optname;
  args[3] = (unsigned long) optval;
  args[4] = (unsigned long) optlen;
  return (__socketcall(SYS_GETSOCKOPT, args));
}

static inline ssize_t _recv(int sockfd, __ptr_t buffer, size_t len, int flags)
{
  unsigned long args[4];

  args[0] = sockfd;
  args[1] = (unsigned long) buffer;
  args[2] = len;
  args[3] = flags;
  return (__socketcall(SYS_RECV, args));
}

static inline ssize_t _recvfrom(int sockfd, __ptr_t buffer, size_t len,
                                int flags, struct sockaddr *to,
                                socklen_t * tolen)
{
  unsigned long args[6];

  args[0] = sockfd;
  args[1] = (unsigned long) buffer;
  args[2] = len;
  args[3] = flags;
  args[4] = (unsigned long) to;
  args[5] = (unsigned long) tolen;
  return (__socketcall(SYS_RECVFROM, args));
}

static inline ssize_t _recvmsg(int sockfd, struct msghdr *msg, int flags)
{
  unsigned long args[3];

  args[0] = sockfd;
  args[1] = (unsigned long) msg;
  args[2] = flags;
  return (__socketcall(SYS_RECVMSG, args));
}

static inline ssize_t _send(int sockfd, const void *buffer, size_t len,
                            int flags)
{
  unsigned long args[4];

  args[0] = sockfd;
  args[1] = (unsigned long) buffer;
  args[2] = len;
  args[3] = flags;
  return (__socketcall(SYS_SEND, args));
}

static inline ssize_t _sendmsg(int sockfd, const struct msghdr *msg, int flags)
{
  unsigned long args[3];

  args[0] = sockfd;
  args[1] = (unsigned long) msg;
  args[2] = flags;
  return (__socketcall(SYS_SENDMSG, args));
}

static inline ssize_t _sendto(int sockfd, const void *buffer, size_t len,
                              int flags, const struct sockaddr *to,
                              socklen_t tolen)
{
  unsigned long args[6];

  args[0] = sockfd;
  args[1] = (unsigned long) buffer;
  args[2] = len;
  args[3] = flags;
  args[4] = (unsigned long) to;
  args[5] = tolen;
  return (__socketcall(SYS_SENDTO, args));
}

static inline int _setsockopt(int fd, int level, int optname,
                              const void *optval, socklen_t optlen)
{
  unsigned long args[5];

  args[0] = fd;
  args[1] = level;
  args[2] = optname;
  args[3] = (unsigned long) optval;
  args[4] = optlen;
  return (__socketcall(SYS_SETSOCKOPT, args));
}

static inline int _shutdown(int sockfd, int how)
{
  unsigned long args[2];

  args[0] = sockfd;
  args[1] = how;
  return __socketcall(SYS_SHUTDOWN, args);
}

static inline int _socketpair(int family, int type, int protocol,
                              int sockvec[2])
{
  unsigned long args[4];

  args[0] = family;
  args[1] = type;
  args[2] = protocol;
  args[3] = (unsigned long) sockvec;
  return __socketcall(SYS_SOCKETPAIR, args);
}

_fd_t *tap_open(const char *path, int flags, mode_t mode)
{
  _fd_t *fd;
  int osfd;
  int my_flags = O_DIRECT;

  internal(4, "open file %s", path);

  osfd = syscall(SYS_open, path, flags | my_flags, mode);
  if (osfd < 0)
  {
    internal(4, "ERROR open file: %d %s", errno, strerror(errno));
    return NULL;
  }

  fd = fd_create(osfd, FD_FILE);
  if (!fd)
  {
    osfd = syscall(SYS_close, osfd);
    return NULL;
  }

  return fd;
}

ssize_t tap_close(_fd_t * fd)
{

  ssize_t retval;

  retval = syscall(SYS_close, fd->osfd);
  fd_destroy(fd);
  return retval;
}

/********************************************************
 *                net IO
 ********************************************************/

static inline int submit_accept(_fd_t * s)
{
  int op;
  struct epoll_event *event;
  int ret, epfd;

  epfd = process_get_epoll_fd(get_id());
  event = &s->u.sock.event;
  event->data.ptr = s;
  event->events = EPOLLIN | EPOLLONESHOT | EPOLLERR | EPOLLHUP;

  if (!fd_submitted(s))
    op = EPOLL_CTL_ADD;
  else
    op = EPOLL_CTL_MOD;

  internal(4, "submit fd %d to epoll", s->osfd);
  ret = epoll_ctl(epfd, op, s->osfd, event);
	poll_count++;
  if (ret)
  {
    internal(4, " ERROR epoll_ctl %d: %d %s", ret, errno, strerror(errno));
    return -1;
  }
  fd_set_submitted(s);
  internal(4, "epoll_ctl returned %d", ret);
  fd_clear_done(s);
  return ret;
}

int tap_connect(tap_fd_t s, const struct sockaddr *saddr, socklen_t addrlen)
{
	return -1;
}

static inline int submit_next_accept(_fd_t *s)
{
  if (list_empty(&s->u.sock.accept_q))
  {                             /* no other threads are accepting */
	//	int epfd = process_get_epoll_fd(get_id());
	//	int ret;
		struct epoll_event *event;
    
		internal(4, "accept queue empty");
		
		event = &s->u.sock.event;
		event->events = 0;

    s->thread = NULL;
  }
  else
  {
    /* connect next thread with this fd */
    s->thread = list_entry(s->u.sock.accept_q.next, _thread_t, fd_list);
    list_del_init(&s->thread->fd_list);
    internal(4, "get next thread [%d] from accept queue", s->thread->tid);
    /* resubmit accept for the next thread */
		if(submit_accept(s))
			return -1;
  }

	return 0;
}

/*
 * blocks current thread
 */
_fd_t *tap_accept(_fd_t * s, struct sockaddr *addr, socklen_t * addrlen)
{
  _fd_t *retval;
  int new_socket;
  _thread_t *this = tap_thread_self();
	//struct netcb *ncb = &this->op.ncb;

  this->op.ncb.op = ACCEPT;

	this->flags |= TAP_READY;
	this->flags |= TAP_ON_NEXT_APP;
	list_del_init(&this->ready_q);
	list_del_init(&this->calendar);
	this->op.resource = TRES_NET;
	this->op.type = ACCEPT;

  _thread_reset_priority(this);

  assert(s->type == FD_SOCKET);

  internal(4, "in tap_accept, fd %d", s->osfd);

  if (!s->thread)
  {
    s->thread = this;
		internal(4," submit the accept");
    if(submit_accept(s))
			return NULL;
  }
  else
	{
		internal(4, "another thread [%d] is accepting, linking [%d] to list", s->thread->tid, this->tid);

    list_add(&s->u.sock.accept_q, &this->fd_list);
	}
__block:
  block(-1);

  if (sock_err(s))
  {
		printf("accept error\n");
    errno = ECONNABORTED;
    return NULL;
  }
 	
  /* do syscall, will not block */
  new_socket = _accept(s->osfd, addr, addrlen);

  if (new_socket == -1)
  {
    internal(4, "ERROR: systemcall accept failed: %d %s",
             errno, strerror(errno));
		if(errno == EAGAIN)
			goto __block;

		return NULL;
  }

	if(new_socket > 0 || errno != EAGAIN)
		submit_next_accept(s);
	
	
  fd_set_nb(new_socket);
  retval = fd_create(new_socket, FD_SOCKET);
  if (!retval)
  {
    internal(4, "create FD failed");
    syscall(SYS_close, new_socket);
    return NULL;
  }
  return retval;
}

/*
 * don't block
 */
int tap_listen(_fd_t * s, int backlog)
{
  return _listen(tap_osfd(s), backlog);
}

/*
 * don't block
 */
_fd_t *tap_socket(int domain, int type, int protocol)
{
  _fd_t *retval;
  int socket;

  socket = _socket(domain, type, protocol);
  if (socket == -1)
  {
    internal(4, "ERROR: syscall socket failed, %d %s", errno, strerror(errno));
    return NULL;
  }

  fd_set_nb(socket);
  retval = fd_create(socket, FD_SOCKET);
  if (!retval)
  {
    internal(4, "create FD failed");
    syscall(SYS_close, socket);
    return NULL;
  }

  return retval;
}

/*
 * don't block
 */
int tap_bind(_fd_t * s, const struct sockaddr *myaddr, socklen_t addrlen)
{
  return _bind(tap_osfd(s), myaddr, addrlen);
}


/***********************************************************
 *                      socket epoll                       *
 ***********************************************************/
/* called by tap_io_init()
 * which is called by main_init
 */
static inline void epoll_init(int id)
{
  internal(4, "epoll_init");
  int epfd = epoll_create(_EPOLL_QUEUE_SIZE);
  struct epoll_event *events =
    malloc(sizeof(struct epoll_event) * _EPOLL_MAX_EVENTS);

  process_set_epoll(id, epfd, events);
}

/* called by tap_io_destroy
 * which is called by main_exit
 */
static inline void epoll_destroy(int id)
{
  int epfd = process_get_epoll_fd(id);
  syscall(SYS_close, epfd);

  free(process_get_epoll_events(id));
}

static inline int epoll_cancel(int epfd, _fd_t * fd)
{
  struct epoll_event *event;
  int ret;
  internal(4, "epoll remove fd %d", fd->osfd);
  ret = epoll_ctl(epfd, EPOLL_CTL_DEL, fd->osfd, event);
  if (ret)
  {
    internal(4, " ERROR epoll_ctl %d: %d %s", ret, errno, strerror(errno));
    return -1;
  }

  return 0;
}

#ifdef EPOLL_ET                 /* use epoll edge triggered */
static inline int epoll_submit(_fd_t * fd)
{
  int op, epfd, retval;
  struct epoll_event *event;

  event = &fd->u.sock.event;
  op = EPOLL_CTL_ADD;           /* add fd to event list */
  event->data.ptr = fd;

  event->events = EPOLLIN | EPOLLOUT | EPOLLERR | EPOLLHUP | EPOLLET;

  epfd = process_get_epoll_fd(get_id());

  return epoll_ctl(epfd, op, fd->osfd, event);
}

static inline int epoll_block(_fd_t * fd, int interest, _thread_t * thread)
{
  int blocked = 0;
  /* connect thread to this fd */
  fd->thread = thread;
  while (!(fd->u.sock.ready & interest))
  {
    internal(4, "     socket not ready for this ");
    block(-1);
    blocked = 1;

    /*
     * FIXME: check if we timedout
     */
    if (thread->flags & TAP_TIMEDOUT)
    {
      thread->flags &= ~TAP_TIMEDOUT;
      internal(3, "timed out, delete fd from epoll");

      errno = EAGAIN;
      return -1;
    }
  }

  if (sock_err(fd))
  {
    internal(4, "       got an error on this socket");
    errno = EPIPE;
    return -1;
  }

  fd->thread = NULL;
  internal(4, "        socket ready");
  return blocked;
}

/*
 * called by tap_do_rw(...)
 * which is called by a user thread
 */
static ssize_t epoll_rw(tap_io_t type, _fd_t * fd, void *buf, size_t count)
{

  _thread_t *thread = tap_thread_self();
  ssize_t retval;
  int ret, blocked = 0;
  unsigned int interest = 0;
  struct netcb *ncb;

  /* get the event mask for this fd */

  /* check if fd was previously submitted */
  if (!fd_submitted(fd))
  {
    retval = epoll_submit(fd);
    internal(4, "send fd %d to epoll ctl", fd->osfd);
    if (retval)
    {
      internal(4, " ERROR epoll_submit %d: %d %s", retval, errno,
               strerror(errno));
      return -1;
    }
    fd_set_submitted(fd);
  }

  /* build cb */
  ncb = &thread->ncb;
  ncb->op = type;
  ncb->fd = fd->osfd;
  ncb->buf = buf;
  ncb->count = count;

  switch (type)
  {
  case READ:
  case PREAD:
    internal(4, "do epoll_rw READ, fd %p, osfd %d, buf %p, count %d",
             fd, fd->osfd, buf, count);
    retval = syscall(SYS_read, fd->osfd, buf, count);
    if (retval == -1 && errno == EAGAIN)
    {
      internal(4, "   got EAGAIN");
      sock_clear_in(fd);
    }
    else
      return retval;

    interest = SOCK_IN;
    break;
  case WRITE:
  case PWRITE:
    internal(4, "do epoll_rw WRITE, fd %p, osfd %d, buf %p, count %d",
             fd, fd->osfd, buf, count);
    retval = syscall(SYS_write, fd->osfd, buf, count);
    if (retval == -1 && errno == EAGAIN)
    {
      internal(4, "   got EAGAIN");
      sock_clear_out(fd);
    }
    else
      return retval;
    interest = SOCK_OUT;
    break;
  default:
    internal(4, " don't know io type ");
    errno = EINVAL;
    return -1;
  }

  interest |= SOCK_ERR;

  epoll_block(fd, interest, thread);

  return thread->ncb.result;

}

#else /* EPOLL_ET */
/*
 * called by tap_do_rw(...)
 * which is called by a user thread
 */
static ssize_t epoll_rw(tap_io_t type, _fd_t * fd, void *buf, size_t count)
{

  _thread_t *thread = tap_thread_self();
  struct epoll_event *event;
  int op;
  struct netcb *ncb;

  thread->op.resource = TRES_NET;
	thread->op.type = type;

  internal(4, "in epoll_rw fd %d", fd->osfd);

  /* connect thread to this fd */
  fd->thread = thread;
  /* get the event mask for this fd */
  event = &fd->u.sock.event;

  /* check if fd was previously submitted */
  if (fd_submitted(fd))
    op = EPOLL_CTL_MOD;         /* reactivate the fd  */
  else
  {
    op = EPOLL_CTL_ADD;         /* add fd to event list */
    event->data.ptr = fd;
  }
  /* is it input or output */
  if (type == READ)
    event->events = EPOLLIN;
  else
    event->events = EPOLLOUT;

  /* after the the event is collect
   * the fd is internally disabled */
  event->events |= EPOLLONESHOT | EPOLLERR | EPOLLHUP;
  
  /* build cb */
  ncb = &thread->op.ncb;
  ncb->op = type;
  ncb->fd = fd->osfd;
  ncb->buf = buf;
  ncb->count = count;
	ncb->event = event;
	ncb->epoll_op = op;

  fd_set_submitted(fd);
  fd_clear_done(fd);

#if 0 /* submit is done by the reactor */
  internal(4, "send fd %d to epoll ctl", fd->osfd);
	ret = epoll_ctl(epfd, op, fd->osfd, event);
  if (ret)
  {
    internal(4, " ERROR epoll_ctl %d: %d %s", ret, errno, strerror(errno));
    return -1;
  }
#endif

	thread->flags |= TAP_READY;
	if(thread->flags & TAP_ON_NEXT_APP)
		process_add_ready(thread);
	
  block(-1);

  /* on return io is done, if possible */

#if 0
  /*
   * FIXME: check if we timedout
   */
  if (thread->flags & TAP_TIMEDOUT)
  {
    thread->flags &= ~TAP_TIMEDOUT;
    internal(3, "timed out, delete fd from epoll");

    epoll_cancel(epfd, fd);

    errno = EAGAIN;
    return -1;
  }
#endif

  /* check error status of the fd */
  if (sock_err(fd))
  {
    errno = EPIPE;
    return -1;
  }

#if 0
  /* the fd is ready and we won't block
   * on these calls
   */
  switch (type)
  {
  case READ:
  case PREAD:
    internal(4, "do a syscall READ on socket");
    retval = syscall(SYS_read, fd->osfd, buf, count);
    break;
  case WRITE:
  case PWRITE:
    internal(4, "do a syscall WRITE on socket");
    retval = syscall(SYS_write, fd->osfd, buf, count);
    break;
  default:
    internal(4, "epoll io type not supported");
    return -1;
  }

  fd->thread->_errno = errno;
  internal(4, " socket syscall returned: %d ", retval);
  errno = fd->thread->_errno;
  fd->thread = NULL;
#endif
  return ncb->result;

}

#endif /* EPOLL_ET */

static inline ssize_t netcb_do_io(struct netcb *ncb)
{
  int op;
  switch (ncb->op)
  {
  case READ:
  case PREAD:
    op = SYS_read;
    break;
  case WRITE:
  case PWRITE:
    op = SYS_write;
    break;
  default:
    internal(4, " error parse event, unknown operation ");
    errno = EINVAL;
    return -1;
  }
  ncb->result = syscall(op, ncb->fd, ncb->buf, ncb->count);
  return ncb->result;
}

static inline _thread_t *epoll_parse_event(struct epoll_event *event)
{
  _fd_t *fd;
  _thread_t *thread;
  int events = event->events;

  fd = (_fd_t *) event->data.ptr;
  fd_set_done(fd);
  thread = fd->thread;
	internal(4, " epoll_parse_event got fd %d, and thread %d",
			fd->osfd, thread?thread->tid:-1);

  if (events & EPOLLIN || events & EPOLLPRI)
  {
    sock_set_in(fd);
    if (thread && thread->op.ncb.op == READ)
      netcb_do_io(&thread->op.ncb);
  }
  else
    sock_clear_in(fd);

  if (events & EPOLLOUT)
  {
    sock_set_out(fd);
    if (thread && thread->op.ncb.op == WRITE)
      netcb_do_io(&thread->op.ncb);
  }
  else
    sock_clear_out(fd);

  if (events & EPOLLERR || events & EPOLLHUP)
    sock_set_err(fd);
  else
    sock_clear_err(fd);

  if (thread)
    thread->_errno = errno;

  return thread;
}

long poll_count = 0;
static int epoll_poll(struct tap_list *list)
{
  int ready, i, count = 0;
  _thread_t *thread;
  int epfd = process_get_epoll_fd(get_id());
  struct epoll_event *_epoll_events = process_get_epoll_events(get_id());
  int timeout = 0;

  if (!process_pending(get_id()) && runq_empty(process_get_run_q(get_id())))
    timeout = -1;
		
	internal(4, "do epoll_wait");
  ready = epoll_wait(epfd, _epoll_events, _EPOLL_MAX_EVENTS, timeout);

  if (ready == -1)
	{
		perror("epoll_wait");
		exit(1);
	}

DOPROFILE(
		prof_avg_t events;
		events = prof_get(PROF_EPOLL);
		prof_add(events, ready);
		);

	poll_count -= ready;

  internal(4, "epoll poll, returned %d", ready);

  for (i = 0; i < ready; ++i)
  {
    thread = epoll_parse_event(_epoll_events + i);
    if (thread)
    {
			internal(4,"  add [%d] to io_q", thread->tid);

      list_add_tail(list, &thread->io_q);
			++count;
    }
    else
    {
#ifndef EPOLL_ET
      struct epoll_event *event;
      event = _epoll_events + i;
      _fd_t *fd = (_fd_t *) event->data.ptr;
      internal(4, "epoll remove fd %d", fd->osfd);
      epoll_cancel(epfd, fd);
#endif
    }
  }


  return count;
}

/***********************************************************
 *                      file AIO                           *
 ***********************************************************/

/* aio context must be global */
/*
 * FIXME for SMP support we have to synchronize 
 * the access
 */

static void aio_init(int id)
{
  int retval;
  io_context_t *_aio_ctx = process_get_aio_ctx(id);
  struct io_event *aio_events;

  internal(4, "init aio system, queue size: %d", _AIO_QUEUE_SIZE);
  memset(_aio_ctx, 0, sizeof(io_context_t));
  retval = io_setup(_AIO_QUEUE_SIZE, _aio_ctx);

  if (retval)
  {
    internal(4, "ERROR io_setup %d: ", retval);
    switch (-retval)
    {
    case EINVAL:
      internal(4,
               "EINVAL context no initialized, or nr_events exceeds internal limits");
      break;
    case EFAULT:
      internal(4, "EFAULT invalid pointer\n");
      break;
    case ENOMEM:
      internal(4, "ENOMEM insufficient kernel resources\n");
      break;
    case EAGAIN:
      internal(4, "EAGAIN nr_events exceeds the user's limit\n");
      break;
    case ENOSYS:
      internal(4, "ENOSYS not implemented on this architecture\n");
      break;
    }
		printf("retval of io_setup: %d %s\n", retval, strerror(-retval));
    exit(1);
  }
  aio_events = malloc(sizeof(struct io_event) * _AIO_MAX_EVENTS);
  process_set_aio(id, aio_events);
}

static inline void aio_destroy(int id)
{
  free(process_get_aio_events(id));
}

static inline int _aio_cancel(struct iocb *cb, int id)
{
  struct io_event ev;
  long ret;
  io_context_t *_aio_ctx = process_get_aio_ctx(id);
  internal(4, "io timedout cancel cb");

  ret = io_cancel(*_aio_ctx, cb, &ev);
  if (ret)
    internal(4, "ERRORRRRRRR in io_cancel: %ld %s", -ret, strerror(-ret));

  return 0;
}

/* 
 * submit async disc aio
 * called by tap_do_rw(...)
 * which is called by a user thread
 */
static inline long aio_submit_one(struct iocb *cb, int id)
{
  long retval;
  io_context_t *_aio_ctx = process_get_aio_ctx(id);
  struct iocb *cbs[1];

  cbs[0] = cb;

  process_increase_pending(id, 1);
  retval = io_submit(*_aio_ctx, 1, cbs);
  internal(4, " %s aio submit returned %ld", __FILE__, retval);

  return retval;
}

static ssize_t aio_rw(tap_io_t type, _fd_t * fd, void *buf, size_t count)
{
  ssize_t retval;
  int id = get_id();
  _thread_t *thread = get_thread(id);
  struct iocb *cb = &thread->op.cb;

  if (fd_canceled(fd))
  {
    errno = EAGAIN;
    return -1;
  }

  assert(!fd_submitted(fd));
  /* connect thread to fd */
  fd->thread = thread;
  thread->op.resource = TRES_DISC;
	thread->op.type = type;

  /* check io type, and prepare the fd */
  switch (type)
  {
  case READ:
    internal(4, "do aio_rw READ, fd %p, osfd %d, buf %p, count %d, offset %d", fd, fd->osfd, buf, count, fd->u.rw.off);
		
    io_prep_pread(cb, fd->osfd, buf, count, fd->u.rw.off);
    break;
  case WRITE:
    internal(4, "do aio_rw WRITE, fd %p, osfd %d, buf %p, count %d, offset %d", fd, fd->osfd, buf, count, fd->u.rw.off);

    io_prep_pwrite(cb, fd->osfd, buf, count, fd->u.rw.off);
    break;
  default:
    internal(4, "aio type %d not supported", type);
    return -1;
  }

  internal(4, " do aio submit");

  cb->data = fd;

	thread->flags |= TAP_READY;
	if(thread->flags & TAP_ON_NEXT_APP)
		process_add_ready(thread);

	
  /* block current thread */
  block(-1);

/********************************
 * thread continues when io done
 ********************************/

  /*
   * FIXME: check if we timedout
   */
  if (thread->flags & TAP_TIMEDOUT)
  {
    thread->flags &= ~TAP_TIMEDOUT;
    internal(3, "timed out, delete fd from aio");

    _aio_cancel(cb, id);

    errno = EAGAIN;
    return -1;
  }
  else
  {
    /* check status of filedescriptor 
     * and get the return value
     */
    retval = fd->u.rw.res;
  }

  if (retval < 0)
  {
    errno = -retval;
    retval = -1;
  }
  else
    /* set the offset in the file */
    fd->u.rw.off += retval;

  return retval;
}

/* get the fd of a aio cb */
#define _CB_GET_THREAD(__cb) ((_thread_t *)((char *)(__cb) - offsetof(_thread_t, op.cb)))
/*
 * parse the aio event and return the
 * waiting thread
 */
static inline _thread_t *aio_parse_event(struct io_event *event)
{
  struct iocb *cb;
  _thread_t *retval;
  _fd_t *fd;
  assert(event);
  cb = (struct iocb *) event->obj;
  fd = event->data;
  fd->u.rw.res = event->res;
  internal(4, " processed/event result %ld bytes", event->res);
  if (fd->u.rw.res < 0)
  {
    internal(4, "ERROR in aio_parse_event: event returned %d: %s",
             errno, strerror(-event->res));
  }

  fd_clear_submitted(fd);
  if (fd_canceled(fd))
  {
    fd_clear_canceled(fd);
  }

  fd_set_done(fd);
  retval = _CB_GET_THREAD(cb);
  assert(retval);
  return retval;
}

/*
 * poll for finished disc IO
 *
 * push ready threads into list
 * return number of ready threads
 */
extern long aio_count;
static int aio_poll(struct tap_list *list)
{
  int i, complete;
  _thread_t *thread;
  io_context_t *_aio_ctx = process_get_aio_ctx(get_id());
  struct io_event *_aio_events = process_get_aio_events(get_id());

	
  complete = io_getevents(*_aio_ctx, 0, _AIO_MAX_EVENTS, _aio_events, NULL);

DOPROFILE(
		prof_avg_t events;
		events = prof_get(PROF_GETEVENTS);
		prof_add(events, complete);
	);

  process_reduce_pending(get_id(), complete);

  internal(4, "aio poll returned %d", complete);
  /*
   * FIXME check for errors
   */
  /* build a list of finished threads */
  for (i = 0; i < complete; ++i)
  {
    thread = aio_parse_event(_aio_events + i);
    if (thread)
    {
			aio_count--;
			internal(4,"  add [%d] to io_q", thread->tid);

      list_add_tail(list, &thread->io_q);
    }

  }

	if(aio_count < 0)
	{
		printf("aio_count negativ !!!\n");
		exit(1);
	}


  return complete;
}

/***********************************************************
 *                  public io functions                    *
 ***********************************************************/
void tap_io_init(int id)
{
  aio_init(id);
  epoll_init(id);
}

void tap_io_destroy(int id)
{
  epoll_destroy(id);
  aio_destroy(id);
}

int tap_io_poll(struct tap_list *list)
{
  int retval;
  internal(4, "poll for finished threads");

  retval = epoll_poll(list);
  if (process_pending(get_id()))
    retval += aio_poll(list);
  return retval;
}

/*
 * the io multiplexer:
 *
 * push the threads in the io state machine
 * files -> aio
 * sockets/pipes -> epoll
 */
ssize_t tap_do_io(tap_io_t type, _fd_t * fd, void *buf, size_t count)
{
  ssize_t retval;
	_thread_t *thread = tap_thread_self();
  internal(4, "do IO");
  switch (fd->type)
  {
  case FD_SOCKET:
  case FD_PIPE:
    internal(4, " operation on socket/pipe ");
    retval = epoll_rw(type, fd, buf, count);
    break;
  case FD_FILE:
    internal(4, " operation on file ");
    retval = aio_rw(type, fd, buf, count);
    break;
  default:
    internal(4, "unkown file type");
    return -1;
  }

  fd->thread = NULL;
  _thread_inc_priority(thread);
  return retval;
}
/*
 * handels appointments
 */
ssize_t tap_read(tap_fd_t fd, void *buf, size_t count)
{
//      return tap_do_io(READ, fd, buf, count);
  ssize_t retval;
  retval = tap_do_io(READ, fd, buf, count);
  return retval;

}

ssize_t tap_write(tap_fd_t fd, const void *buf, size_t count)
{
  ssize_t retval;
  retval = tap_do_io(WRITE, fd, (void*)buf, count);
  return retval;
}
