
#include "profile.h"
#include "debug.h"

#include <stdio.h>

#ifdef PROFILE
struct prof_avg profiling[MAX_PROFILE];
static int next = PROF_LAST;

int prof_new(struct prof_avg **avg)
{
	*avg = profiling + next;
	return next++;
}


void prof_print()
{
	int i=0;
	for(i=0;i< next;i++)
	{
		internal(6," %d \t avg: %3.4f count: %d\n", i, 
				profiling[i].avg, profiling[i].n);
		printf(" %d %20s  avg: %3.4f count: %d\n", i,
				prof_name(i),	profiling[i].avg, profiling[i].n);
	}
}

char *prof_name(int id)
{
	char * retval = NULL;
	switch(id)
	{
		case PROF_SUBMITTED:
			retval = "aio submits";
			break;
		case PROF_GETEVENTS:
			retval = "aio events";
			break;
		case PROF_EPOLL:
			retval = "epoll waits";
			break;
		case PROF_RUNQ:
			retval = "run queue";
			break;
		case PROF_READY:
			retval = "ready queue";
			break;
		case PROF_NEXTREADY:
			retval = "on next appointment";
			break;
	}
	
	return retval;
}

#else

void prof_print()
{

}

char * prof_name(int id)
{
	return NULL;
}
#endif
