/* $Id: posix_io.c,v 1.14.2.2 2005/08/04 18:19:18 hroeck Exp $*/

/* 
 * Copyright (c) Petru Flueras petru.flueras@cs.uni-salzburg.at 
 *
 * University Salzburg, www.uni-salzburg.at
 * Department of Computer Science, cs.uni-salzburg.at
 */

/*  
 *  This program is free software; you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation; either version 2 of the License, or
 *  (at your option) any later version.
 *
 *  This program is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 *
 *  You should have received a copy of the GNU General Public License
 *  along with this program; if not, write to the Free Software
 *  Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 *
 */

#include "posix_io.h"
#include "hashtable.h"
#include "threads.h"
#include "pthread_private.h"
#include <stdarg.h>

static hashtable hash_fd;

/*
 * If the key exists in the kash return the value
 * otherwise return NULL
 */
static _posix_fd_t *posix_hash_get(hashtable * hash, int key)
{
  _posix_fd_t *current;
  unsigned hash_no = hash->get_hash(key);

  internal(7, "elem-%p- prev-%p- next-%p-",
           &(hash->hash_list[hash_no]),
           hash->hash_list[hash_no].prev, hash->hash_list[hash_no].next);

  internal(8, "key: -%d- value: -%u-", key, hash_no);
  if (hash_entry_empty(&(hash->hash_list[hash_no])))
    return NULL;

  list_for_each_entry(current, &(hash->hash_list[hash_no]), queue)
  {
    if (current->os_fd == key)
      return current;
  }

  return NULL;
}

static _posix_fd_t *posix_hash_rem(hashtable * hash, int key)
{
  _posix_fd_t *current;
  unsigned hash_no = hash->get_hash(key);

  internal(6, "Remove hash key (posix) -%u-", hash_no);
  current = posix_hash_get(hash, key);
  if (current)
    hash_rem(&current->queue);

  return current;
}

/*
 * Intialization and finalization area
 */
void posix_io_initialize()
{
  hash_init(&hash_fd, get_hash);
  internal(9, "posix io intialized successfull");
}

void posix_io_finalize()
{
  internal(9, "posix io finalized successfull");
}

/*
 * Override system calls
 */
int open(const char *path, int flags, ...)
{
  va_list ap;
  int os_fd;
  mode_t mode = 0;
  tap_fd_t tap_fd;
  _posix_fd_t *posix_fd;

  internal(9, "Executing open");
  // get the mode
  va_start(ap, flags);
  if (flags & O_CREAT)
    mode = (mode_t) va_arg(ap, mode_t);

  va_end(ap);

  tap_fd = tap_open(path, flags, mode);
  if (!tap_fd)
  {
    internal(9, "Error open");
    return -1;
  }

  os_fd = tap_osfd(tap_fd);
  posix_fd = (_posix_fd_t *) malloc(sizeof(_posix_fd_t));
  posix_fd->os_fd = os_fd;
  posix_fd->tap_fd = tap_fd;

  internal(9, "Got os_fd: -%d- Address: -%p-", os_fd, posix_fd);
  hash_put(&hash_fd, posix_fd->os_fd, &(posix_fd->queue));

  return os_fd;
}

int creat(const char *path, mode_t mode)
{
  open(path, O_CREAT | O_TRUNC | O_WRONLY, mode);
}

ssize_t read(int fd, void *buf, size_t count)
{
  _posix_fd_t *posix_fd;
  tap_fd_t tap_fd;

  internal(9, "Executing read");
  posix_fd = posix_hash_get(&hash_fd, fd);
  if (!posix_fd)
  {
    internal(9, "Error read. Get hash failed");
    return -1;
  }

  internal(9, "Read from fd: -%d- Address: -%p- Bytes %d", fd, posix_fd, count);
  return tap_read(posix_fd->tap_fd, buf, count);
}

ssize_t write(int fd, const void *buf, size_t count)
{
  _posix_fd_t *posix_fd;
  tap_fd_t tap_fd;

  internal(9, "Executing write");
  posix_fd = posix_hash_get(&hash_fd, fd);
  if (!posix_fd)
  {
    internal(9, "Error read. Get hash failed");
    return -1;
  }

  // FIXME warning: passing arg 2 discards types
  internal(9, "Write to fd: -%d- Address: -%p- Bytes %d", fd, posix_fd, count);
  return tap_write(posix_fd->tap_fd, buf, count);
}

int close(int filedes)
{
  _posix_fd_t *posix_fd;
  tap_fd_t tap_fd;

  internal(9, "Executing close");
  posix_fd = posix_hash_rem(&hash_fd, filedes);
  if (!posix_fd)
  {
    internal(9, "Error close. Rem hash failed");
    return -1;
  }
  else
  {
    tap_fd = posix_fd->tap_fd;
    free(posix_fd);
    return tap_close(tap_fd);
  }
}

/* ********** Socket routines ************ */

int accept(int s, struct sockaddr *addr, socklen_t * addrlen)
{
  _posix_fd_t *posix_fd, *new_posix_fd;
  tap_fd_t new_tap_fd;
  int new_os_fd;

  internal(9, "Executing accept");
  posix_fd = posix_hash_get(&hash_fd, s);
  if (!posix_fd)
  {
    internal(9, "Error accept. Get hash failed");
    return -1;
  }

  new_tap_fd = tap_accept(posix_fd->tap_fd, addr, addrlen);
	if(!new_tap_fd)
		return -1;

  new_os_fd = tap_osfd(new_tap_fd);
  new_posix_fd = (_posix_fd_t *) malloc(sizeof(_posix_fd_t));
  new_posix_fd->tap_fd = new_tap_fd;
  new_posix_fd->os_fd = new_os_fd;
  hash_put(&hash_fd, new_posix_fd->os_fd, &(new_posix_fd->queue));

  return new_os_fd;
}

int bind(int sockfd, const struct sockaddr *myaddr, socklen_t addrlen)
{
  _posix_fd_t *posix_fd;

  internal(9, "Executing bind");
  posix_fd = posix_hash_get(&hash_fd, sockfd);
  if (!posix_fd)
  {
    internal(9, "Error bind. Get hash failed");
    return -1;
  }

  return tap_bind(posix_fd->tap_fd, myaddr, addrlen);
}

int connect(int sockfd, const struct sockaddr *saddr, socklen_t addrlen)
{
  _posix_fd_t *posix_fd;

  internal(9, "Executing accept");
  posix_fd = posix_hash_get(&hash_fd, sockfd);
  if (!posix_fd)
  {
    internal(9, "Error accept. Get hash failed");
    return -1;
  }

  return tap_connect(posix_fd->tap_fd, saddr, addrlen);
}

/*int getpeername(int sockfd, struct sockaddr *addr, socklen_t * paddrlen)
{
}

int getsockname(int sockfd, struct sockaddr *addr, socklen_t * paddrlen)
{
}

int getsockopt(int fd, int level, int optname, __ptr_t optval,
			socklen_t * optlen)
{
}*/

int listen(int sockfd, int backlog)
{
  _posix_fd_t *posix_fd;
  tap_fd_t tap_fd;

  internal(9, "Executing listen");
  posix_fd = posix_hash_get(&hash_fd, sockfd);
  if (!posix_fd)
  {
    internal(9, "Error listen. Get hash failed");
    return -1;
  }

  return tap_listen(posix_fd->tap_fd, backlog);
}

ssize_t recv(int sockfd, __ptr_t buffer, size_t len, int flags)
{
}

ssize_t recvfrom(int sockfd, __ptr_t buffer, size_t len, int flags,
                 struct sockaddr *to, socklen_t * tolen)
{
}

ssize_t recvmsg(int sockfd, struct msghdr *msg, int flags)
{
}

ssize_t send(int sockfd, const void *buffer, size_t len, int flags)
{
}

ssize_t sendmsg(int sockfd, const struct msghdr *msg, int flags)
{
}

ssize_t sendto(int sockfd, const void *buffer, size_t len, int flags,
               const struct sockaddr *to, socklen_t tolen)
{
}

/*int setsockopt(int fd, int level, int optname, const void *optval,
               socklen_t optlen)
{
}

int shutdown(int sockfd, int how)
{
}*/

int socket(int family, int type, int protocol)
{
  _posix_fd_t *posix_fd;
  tap_fd_t tap_fd;
  int os_fd;

  internal(9, "Executing socket");

  tap_fd = tap_socket(family, type, protocol);
  if (!tap_fd)
  {
    internal(9, "Error socket");
    return -1;
  }

  os_fd = tap_osfd(tap_fd);
  posix_fd = (_posix_fd_t *) malloc(sizeof(_posix_fd_t));
  posix_fd->os_fd = os_fd;
  posix_fd->tap_fd = tap_fd;

  hash_put(&hash_fd, posix_fd->os_fd, &posix_fd->queue);

  return os_fd;
}

/*int socketpair(int family, int type, int protocol, int sockvec[2])
{
}*/
