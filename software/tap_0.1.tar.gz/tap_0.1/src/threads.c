/* $Id: threads.c,v 1.28.2.19 2005/10/14 14:30:12 hroeck Exp $ */

/* 
 * Copyright (c) Harald Roeck hroeck@cs.uni-salzburg.at 
 *
 * University Salzburg, www.uni-salzburg.at
 * Department of Computer Science, cs.uni-salzburg.at
 */

/*  
 *  This program is free software; you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation; either version 2 of the License, or
 *  (at your option) any later version.
 *
 *  This program is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 *
 *  You should have received a copy of the GNU General Public License
 *  along with this program; if not, write to the Free Software
 *  Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 *
 */

#include "threads_private.h"
#include "process.h"
#include "runq.h"
#include "stack.h"
#include "appointments.h"
#include "profile.h"

#include <stdlib.h>
#include <stdio.h>
#include <unistd.h>
#include <string.h>
#include <assert.h>
#include <syscall.h>

#define STK_SIZE (1024*512)

/* holds the main thread */
static _thread_t main_thread;

_thread_t *get_mainthread()
{
	return &main_thread;
}

/* the process vector */
process_t processes[MAX_PROC];

/* forward declarations */
/* start up routine for the reactor */
static void start_reactor(void *args);
/* the reactor itself */
static void react();
/* the scheduler */
static void sched(int id);
/* creates a thread object with a given stack size */
static _thread_t *create_thread_object(size_t stk_size);

static void thread_destroy(_thread_t * thr);

/* 
 * initialize a process
 * i.e. create a reactor, run queue and set 
 * the current thread
 */
static void process_init(int id, _thread_t * curr_thread)
{
  _thread_t *reactor;
  process_t *process = &processes[id];
  int i;
  /* zero the process vector */
  memset(process, 0, sizeof(process_t));
  /* init the first process */
  process->pid = getpid();

  runq_init(&process->run_q);
  runq_init(&process->zombie_q);

  /* create reactor */
  reactor = create_thread_object(STK_SIZE * 2);
  assert(reactor);
  internal(0, "reactor created!");

  if (ctx_create(&reactor->ctx, start_reactor, NULL, reactor->stk))
    tap_error("ctx_create");
  reactor->tid = -1;
  INIT_TAP_LIST(&reactor->queue);
  process->reactor = reactor;

  process->curr_thread = curr_thread;
  process->active_threads = 1;

  tq_init(&process->timeout_q);

  INIT_TAP_LIST(&process->app_next);
  INIT_TAP_LIST(&process->app_ready);
  INIT_TAP_LIST(&process->all_threads);

  /* malloc aio_cbs for batched io_submit */
  process->aio_cbs = malloc(_AIO_QUEUE_SIZE * sizeof(struct iocb *));
	if(!process->aio_cbs)
			perror("malloc aio_cbs");
	
	process->calendars = malloc(MAX_CALENDARS * sizeof(plist_t));
	if(!process->calendars)
			perror("malloc calendars");

  for (i = 0; i < MAX_CALENDARS; ++i)
    plist_init(process->calendars + i);


  internal(0, "reactor initialized");
  internal(0, "reactor at %p, queue at %p", process->reactor,
           &process->reactor->queue);
  internal(0, "runq at %p, list at %p", &process->run_q, &process->run_q.list);

}

void process_print_threads(int id)
{
	struct tap_list* threads = process_get_all_threads(id);

	_thread_t *thr;
	printf(" printing all threads:\n");
	list_for_each_entry(thr, threads, all_threads)
	{
		printf("[%d], in function: [%s], priority: [%d]\n", thr->tid, thr->curr_func, thr->priority);
	}
	
}

void process_print_ready(int id)
{
	struct tap_list* threads = process_get_app_ready(id);

	_thread_t *thr;
	printf(" printing ready queue:\n");
	list_for_each_entry(thr, threads, ready_q)
	{
		printf("[%d] %s\n", thr->tid, thr->curr_func);
	}
}

void process_print_next(int id)
{
	struct tap_list* threads = process_get_app_next(id);

	_thread_t *thr;
	printf(" printing next queue:\n");
	list_for_each_entry(thr, threads, ready_q)
	{
		printf("[%d] %s\n", thr->tid, thr->curr_func);
	}
}

/* FIXME: we don't destroy processes, yet!! */
static void process_destroy(int id)
{

}

/***********************************************************/
/*                 switching threads                       */
/***********************************************************/
/* switch to an other thread; */
static inline int switch_thread(_thread_t * from, _thread_t * to)
{
  return ctx_switch(&from->ctx, &to->ctx);
}

/*
 * stops thread "from" and resumes thread "to"
 *
 * checks threads and handles errno
 */
static inline void yield_to(_thread_t * from, _thread_t * to)
{
  assert(from);
  assert(to);
  internal(2, " yielding from %d to %d ...", from->tid, to->tid);

  from->_errno = errno;
  /* FIXME check for errors */
  switch_thread(from, to);
  errno = from->_errno;
}

/* insert current thread to a timeout */
int thread_timeout(tap_utime_t time)
{
  int id = get_id();
  tap_utime_t now = tap_utime();
  _thread_t *thread = get_thread(id);
  timeoutq_t *tq = process_get_timeoutq(id);

  if (!tq_empty(&thread->tq))
  {
    internal(4, "already a timeout installed");
    return -1;
  }

  internal(4, " WAITING til %lld", now + time);
  thread->tq.timeout = now + time;
  tq_push(tq, &thread->tq);

  return 0;
}

tap_utime_t __block(const char *function, tap_utime_t time)
{
  int id = get_id();
  tap_utime_t now = tap_utime();
  _thread_t *thread = get_thread(id);
  _thread_t *reactor = process_get_reactor(id);

	thread->curr_func = function;

  internal(4, " in block: timeout of %lld", time);
  if (time == 0)
  {
    internal(4, " timeout of 0 block immediatelly returns");
    yield_to(thread, reactor);
    return now;
  }
  if (time > 0)
  {
    thread_timeout(time);
    thread->state = WAITING;
  }
  else
  {
    internal(4, " BLOCKED");
    thread->state = BLOCKED;
  }

  processes[id].curr_thread = NULL;
  yield_to(thread, reactor);

	thread->curr_func = NULL;

  internal(4, " resumes after BLOCKED ");

  if (time > 0 && thread->flags & TAP_TIMEDOUT)
  {
    internal(4, " remove from timeout queue ");
    tq_pop(&thread->tq);
  }

  return tap_utime();
}

static inline void hold_thread(_thread_t * thread, int id)
{
  _thread_t *reactor = process_get_reactor(id);
  thread->state = HOLD;
  processes[id].curr_thread = NULL;

  yield_to(thread, reactor);
}

void tap_thread_hold_to_release(_thread_t * thread)
{
  thread->state = HOLD;
}

/*
 * yields to the reactor
 */
static inline void yield()
{
  int id = get_id();
  _thread_t *curr_thread = get_thread(id);
  _thread_t *reactor = process_get_reactor(id);

  yield_to(curr_thread, reactor);

  assert(curr_thread->state == RUNNING);
}

/* 
 * public yield
 */
void tap_yield()
{
  yield();
}

void tap_yield_thread(_thread_t * thread)
{
  _thread_t *reactor = process_get_reactor(get_id());

  yield_to(thread, reactor);
}

/*
 *	public function returns reference 
 *	to currently running thread
 */
_thread_t *tap_thread_self()
{
  return get_thread(get_id());
}

/* return thread id of the current thread */
int tap_getid()
{
  return get_thread(get_id())->tid;
}

/* get thread id of thread thr */
int tap_thread_getid(_thread_t * thr)
{
  internal(5, "thr is %p", thr);
  if (thr)
    return thr->tid;

  return -1;
}

#if 0
/*
 * override system errno location function
 * FIXME check other systems and libs, than linux & glibc 2.3
 */
int *__errno_location()
{
      return &get_thread(get_id())->_errno;
}
#endif
/********************************************************
 *                   RSP modell
 ********************************************************/
/* start function for the reactor */
static void start_reactor(void *args)
{
  react();                      /* returns when all threads are gone */
  /*
   * switch back to the main thread to do
   * the final clean up
   */
  internal(1, " no more threads; switch back to main thread ...");
  ctx_resume(&main_thread.ctx);
}

/***************************************
 * do the batched syscalls
 ***************************************/
#ifdef AIO_NO_BATCH
static inline int submit_disk_io(int id)
{
	return 0;
}
#else
/* submit disk io */
long aio_count = 0;
static inline int submit_disk_io(int id)
{
  struct iocb **cbs = processes[id].aio_cbs;
  int count = processes[id].active_cbs;
  int retval;
	prof_avg_t prof_submitted;

  if (count == 0)
    return 0;

  io_context_t *_aio_ctx = process_get_aio_ctx(id);

  internal(3, "submit %d aio cbs", count);

  retval = io_submit(*_aio_ctx, count, cbs);

	DOPROFILE(
		prof_submitted = prof_get(PROF_SUBMITTED);
		prof_add(prof_submitted, retval);
	);
	
  internal(3, " %s io_submit returned %d", __FILE__, retval);
  if (retval < 0)
    return -1;

  assert(retval == count);
	if(retval != count)
		printf(" io_submit different retval than count\n");

	aio_count += retval;

  process_increase_pending(id, retval);
  processes[id].active_cbs = 0;
  return retval;
}
#endif

/* submit network io */
static inline int submit_epoll_io(int id)
{
/* already submitted can't batch net io */
		return 0;
}

/*
 * in parameter: op -- operation to perform
 * 	             id -- process id
 * output parameter: app -- next appointment of the thread
 */
static inline int do_io_op(struct thread_io_op *op, appointment_t *app, int id)
{
	int retval, ret =0;
	/* do the operation */
	internal(5,"\t \t in do_io_op");
	switch(op->resource)
	{
			case TRES_DISC:
				internal(5, "\t \t access to disc");
				ret = process_aio_submit(&op->cb, id);
				app->resource = RES_DISC; /*     next appoinment for disc     */
				op->resource = TRES_CPU;  /* next operation will be a release */
				retval = TRES_DISC;
				break;
			case TRES_NET:
				internal(5, "\t \t access to net");
				if(op->type != ACCEPT) /* accept is handled elsewhere */
					ret = process_epoll_submit(&op->ncb, id);

				if(!ret)
				{
					app->resource = RES_NET;
					op->resource = TRES_CPU;
					retval = TRES_NET;
					break;
				}
				else
				{
					op->ncb.result = ret;
					printf("\t \t error in process_epoll_submit\n");
				}
				break;
			case TRES_CPU: 
				internal(5, "\t \t access to cpu");
				/* the thread wants to run */
				retval = TRES_CPU;
				app->resource = RES_CPU;
				app->type = APP_COMMIT;
				/* thread is released on return */
				return retval;
				break;
			default:
				printf("\t \t error in do_io_op: unkown resource");
				exit(1);
	}
	switch(op->type)
	{
			case READ:
				app->type = APP_READ;
				break;
			case WRITE:
				app->type = APP_WRITE;
				break;
			case ACCEPT:
				app->type = APP_ACCEPT;
				break;
			default:
				printf("\t \t error in do_io_op: unkown type");
				exit(1);
	}

	return retval;
}
/* walk through the ready threads
 * calculate the next appoinments 
 * for these threads
 */
static void handle_ready(struct tap_list *ready, int id)
{
	_thread_t *p;
	int ret;
	appointment_t app;
	int count = 0;
	prof_avg_t r;
	

	internal(5," handle ready ");
	while(!list_empty(ready))
	{
		p = list_entry(ready->next, _thread_t, ready_q);
	
		++count;
		internal(5," do_io_op of thread [%d]", p->tid);
		/* get the type of the next appointment */
		ret = do_io_op(&p->op, &app, id);

		if(ret == TRES_CPU)
		{
			/* the thread wants to run */
			p->state = RELEASED;
      p->flags &= ~TAP_TIMEDOUT;
			process_release(p);
		}

		
		/* clear ready flag */
		if(p->op.type != ACCEPT)
		{
			p->flags &= ~TAP_READY;
			p->flags &= ~TAP_ON_NEXT_APP;
		}

		p->curr_func = __FUNCTION__;
		/* make the next appointment */
		tap_get_appointment(p, &app);
		list_del_init(&p->ready_q);
	}
	internal(5, "handled %d ready threads", count);

	DOPROFILE(
		r=prof_get(PROF_READY);
		prof_add(r, count);
	);
	
}
/* all threads for the current appointments are
 * ready. 
 * 1) update time
 * 2) process all threads of this appointment
 * 3) get threads for next appointment
 */
static inline tap_utime_t app_tick(int id)
{
		tap_list_t *ready = process_get_app_ready(id);
		tap_list_t *nready = process_get_app_next(id);
		
		internal(3,"Appointment Tick !!!!!!!");
		/* update internal time */
		clock_tick();

		/* process the threads for this appoinment */
		handle_ready(ready, id);

		/* get the threads for the next appointments */
		next_ready(ready, nready, id);
		
		/* do the batched syscalls */
		submit_disk_io(id);
		submit_epoll_io(id);

		return tap_utime();
}

/*
 * The Reactor
 */
static void react()
{
  int id;
  runq_t *run_q, *zombie_q;
  _thread_t *curr_thread;
  _thread_t *reactor;
  timeoutq_t *timeoutq;
//  tap_utime_t now;
  struct tap_list *app_ready;
  struct tap_list *app_next;

  id = get_id();
  run_q = process_get_run_q(id);
  zombie_q = process_get_zombie_q(id);
  reactor = process_get_reactor(id);
  timeoutq = process_get_timeoutq(id);

  app_ready = process_get_app_ready(id);
  app_next = process_get_app_next(id);

  /* 
   * run while the run queue is not empty and 
   * the current thread is valid 
   */
  while (process_get_active_threads(id))
  {
    /* get the current_thread */
    curr_thread = get_thread(id);

    internal(1, "reactor ..., current_thread %p", curr_thread);

    /*
     * update clock
    clock_tick();
    now = tap_utime();
     */

    /* if there is a valid current thread
     * append it to the end of the run queue 
     * b/c it wants to run but it got interrupted
     */
    if (curr_thread)
    {
      /* if current thread was running, 
       * push it in released queue
       */
      if (curr_thread->state == RUNNING)
      {
        curr_thread->state = RELEASED;
				process_release(curr_thread);
      }
    }                           /* else it is blocked somewhere */

    /* check for zombies */
    if (!runq_empty(zombie_q))
    {
      _thread_t *thr;
      internal(1, "destroying zombies");
      while (!runq_empty(zombie_q))
      {
        thr = runq_next(zombie_q);
        thread_destroy(thr);
      }
    }


    /* as long as threads are released 
		 * let them run
     */
    while (runq_empty(run_q))
    {
      _thread_t *thr;
      int count = 0, finished = 0;
      TAP_LIST(finished_q);


#ifndef NDEBUG
			if(!list_empty(app_next))
			{
				_thread_t *thr;
				internal(3, " ******************** app_next list: ********************");
				list_for_each_entry(thr, app_next, ready_q)
					internal(3, " -*-*-> [ %d ]", thr->tid);
			}

			if(!list_empty(app_ready))
			{
				_thread_t *thr;
				internal(3, " ------------------- app_ready list: -------------------");
				list_for_each_entry(thr, app_ready, ready_q)
					internal(3, " -----> [ %d ]", thr->tid);
			}
#endif /* NDEBUG */

			/*
			 * check if threads are ready for there appointment
			 */
			if(list_empty(app_next) && !list_empty(app_ready))
			{
				app_tick(id);
				if(!runq_empty(run_q))
					break;
			}
#ifndef NDEBUG
			else
			{
				internal(3," no appointments ready ");
				if(!list_empty(app_next))
				{
					internal(3, " app_next not empty: ");
				}
				if(list_empty(app_ready))
					internal(3, " app_ready is empty ");
			}
#endif /* NDEBUG */

      internal(1, " check for finished io");
      finished += tap_io_poll(&finished_q);
      if (finished)
      {
        list_for_each_entry(thr, &finished_q, io_q)
        {
					internal(1, " got thread [%d] from io_q", thr->tid);

					thr->flags |= TAP_READY;

					if(thr->flags & TAP_ON_NEXT_APP)
					{
						list_del_init(&thr->ready_q);
						process_add_ready(thr);
					}

		/* push thread 
     * directly into the runq
          runq_append(run_q, thr);
		 */
        }
        internal(1, "got %d threads from io_poll", count);
      }

#if 0   /* check for timeout threads   */

      internal(1, " check timeout queue ");
      if (!tq_empty(timeoutq) && tq_gettime(timeoutq) < now)
      {
        _thread_t *thr;
        internal(1, " timeout queue time %lld", tq_gettime(timeoutq));

        do
        {
          thr = tq_entry(tq_next(timeoutq), _thread_t, tq);
          internal(1, " thread %d timedout", thr->tid);
          tq_pop(&thr->tq);

          assert(thr->tq.timeout <= now);

          thr->state = TIMEDOUT;
          thr->flags |= TAP_TIMEDOUT;
          runq_append(run_q, thr);
        }
        while (!tq_empty(timeoutq) && tq_gettime(timeoutq) < now);
      }

      if (runq_empty(run_q))
      {
        /* wait a few microseconds */
        tap_utime_t t = 1000;
        if (!tq_empty(timeoutq))
          t = tq_gettime(timeoutq) - now;

        internal(1, " run queue still empty, sleep for %lld usecs", t);
        tap_usleep(t);
      }
#endif /* check for time out threads */

			/*
			 * check if threads are ready for there appointment
			 */
			if(list_empty(app_next) && !list_empty(app_ready))
			{
				app_tick(id);
			}
    }

    /* print the run_queue */
    runq_print(run_q);

    /* start the scheduler for this process */
    sched(id);
  }
	/* end reactor loop */
}

/*
 *	the Scheduler
 *
 *	runq must not be empty
 */
static void sched(int id)
{
  runq_t *run_q = &processes[id].run_q;
  _thread_t *curr_thread = get_thread(id);
  _thread_t *reactor = process_get_reactor(id);
	prof_avg_t r;

	r = prof_get(PROF_RUNQ);

	prof_add(r, runq_length(run_q));

  internal(1, "scheduler ...");
  /* get next thread */
  curr_thread = runq_next(run_q);
  assert(curr_thread);
  assert(curr_thread->state == RELEASED || curr_thread->state == TIMEDOUT);

  curr_thread->state = RUNNING;
  processes[id].curr_thread = curr_thread;

  switch_thread(reactor, curr_thread);
  internal(1, " return to reactor");
}

/*****************************************************
 *                Library routines
 *****************************************************/

static inline void _init_thread_lists(_thread_t * new_thread)
{
  INIT_TAP_LIST(&new_thread->queue);
  INIT_TAP_LIST(&new_thread->io_q);
  INIT_TAP_LIST(&new_thread->calendar);
	list_add_tail(process_get_all_threads(0), &new_thread->all_threads);
  INIT_TAP_LIST(&new_thread->childs);
  INIT_TAP_LIST(&new_thread->siblings);
  INIT_TAP_LIST(&new_thread->ready_q);
  INIT_TAP_LIST(&new_thread->fd_list);

}

/*
 * Library initialisierung
 *
 * called by the compiler before main()
 */
void sighandler(int sig)
{
  printf("got SIGINT, exiting ...\n");
	tap_kill(NULL);
  exit(0);
}

void main_init()
{
  clock_tick();
	signal(SIGINT, sighandler);

  /* init the output */
  debug_init();

  /* init the first process */
  process_init(0, &main_thread);

  /* set main as current thread */
  memset(&main_thread, 0, sizeof(_thread_t));
	
  
	ctx_init(&main_thread.ctx);
	
	main_thread.tid = 0;
  _init_thread_lists(&main_thread);

  tap_io_init(0);


  main_thread.state = RUNNING;
  internal(0, "main at %p, queue at %p", &main_thread, &main_thread.queue);

	
  pthread_initialize();
	
	prof_init();
	
}

void tap_kill(_thread_t * thr)
{
  ctx_resume(&main_thread.ctx);
}

/*
 * called by the compiler after main returns
 */
extern long poll_count;
void main_exit()
{
  int id = get_id();
  runq_t *zombie_q;
  _thread_t *thr;
	int i;

  assert(processes[id].curr_thread == &main_thread);

  internal(1, " stop main thread id %d", id);
  processes[id].curr_thread = NULL;
  process_dec_threads(id);

	list_del(&main_thread.queue);
	list_del(&main_thread.io_q);
  /* 
   * FIXME be sure to remove main thread from all queues
   */
  /*
   * reactor will reactivate the main thread on exit
   * hence switch back to reactor
   */
  switch_thread(&main_thread, process_get_reactor(id));

  internal(0, "back in main thread");

	process_print_calendars(id);
	process_print(id);

  pthread_finalize();

  /* 
   * FIXME do some final clean up 
   * like: delete reactor thread, close files ...
   *
   * join other processes if SMP is activated
   */

  /* destroy zombies */
  zombie_q = process_get_zombie_q(id);
  runq_foreach(zombie_q, thr)
  {
    thread_destroy(thr);
  }

  internal(0, "destroy io system");
  tap_io_destroy(0);

  internal(0, "destroy reactor");
  /* destroy reactor thread */
  thread_destroy(process_get_reactor(id));

	prof_print();
	
  debug_exit();

	printf("aio_count: %ld\n", aio_count);
	printf("poll_count: %ld\n", poll_count);

  exit(0);
}

/*********************************************************
 *                Thread handling
 *********************************************************/

/*
 * create a thread stub with stack
 * but no context
 * returned thread object is zeroed
 * and the stack pointer is set
 */
static _thread_t *create_thread_object(size_t stk_size)
{
  _thread_t *retval;
  tap_stack_t *stk;

  /* allocate and init stack */
  stk = stack_create(stk_size);
  if (!stk)
    return NULL;

  retval = (_thread_t *) stack_shift(stk, sizeof(_thread_t));

  memset(retval, 0, sizeof(_thread_t));
  retval->stk = stk;

  return retval;
}

/*
 * delete thread object and the stack
 *
 * checks for NULL pointers
 */
static void thread_destroy(_thread_t * thr)
{
  if (thr == NULL)
    return;

  internal(0, " %p id %d going to be destroyed", thr, thr->tid);
  thr->state = DESTROYED;
  stack_destroy(thr->stk);
}

/*
 * start function for new threads
 * entry point of new thread
 */

static void dump_stack(_thread_t * thread)
{
  tap_stack_t *stk = thread->stk;
  char *p = (char *) stk->top;

  printf(" thread at %p, stk %p at %p, p %p at %p\n", thread, stk, &stk, p, &p);

  while (p > (char *) stk->top - 250)   //(char*)thread + sizeof(*thread))
  {
    printf("   %p  %p\n", p, *(long *) p);
    p -= 4;
  }

}

static void starter(void *arg)
{
  void *retval;
  _thread_t *this = (_thread_t *) arg;

  /*
     long x;
     asm("movl %%ebp, %0;"
     :"=r"(x)
     :
     : "%ebp"
     );
     memset((void *)x, 0, 4);

     asm("movl $0,%eax;\n movl %eax,(%ebp);");
   */
  /* stop backtraking here  */
  /* clean top of stack */
  memset((char *) &this + 4, 0, (char *) this->stk->top - (char *) &this - 1);
  //dump_stack(this);

  internal(2, " %p start user function %p args %p",
           this, this->start_func, this->start_data);
  retval = this->start_func(this->start_data);

  tap_thread_exit(retval);
}

/*
 * get next thread id
 * FIXME: recycle old thread ids
 */
static int next_tid()
{
  static int last_tid = 1;

  return last_tid++;
}

/*
 * thread creation
 *
 * creates a thread which executes 
 * the start function with arguments arg
 */
_thread_t *tap_thread_create(void *(*start) (void *arg), void *arg)
{
  _thread_t *new_thread, *this;
  runq_t *run_q;
  int id;
  assert(start);

  id = get_id();

  /* get run queue */
  run_q = process_get_run_q(id);
  this = get_thread(id);

  internal(2, " create thread ");
  /* create a thread object */
  new_thread = create_thread_object(STK_SIZE);
  if (!new_thread)
    return NULL;

  /* get a new context */
  if (ctx_create(&new_thread->ctx, starter, (void *) new_thread,
                 new_thread->stk))
  {
    internal(0, " ctx_create failed !");
    thread_destroy(new_thread);
    return NULL;
  }
  /* init thread structure */
  new_thread->tid = next_tid();
  new_thread->start_func = start;
  new_thread->start_data = arg;
  new_thread->parent = this;
  /* init lists */
  _init_thread_lists(new_thread);
  list_add_tail(&this->childs, &new_thread->siblings);

  /* make thread runnable and insert it into the runqueue */
  new_thread->state = RELEASED;
//  runq_append(run_q, new_thread);
	process_release(new_thread);
  process_inc_threads(id);

  internal(0, "new thread %p, start %p, args %p", new_thread,
           new_thread->start_func, new_thread->start_data);

  /* give the new thread a chance to run */
  yield();

  return new_thread;
}

/*
 * exit the current thread
 * and destroy all data
 */
void tap_thread_exit(void *retval)
{
  int id = get_id();
  _thread_t *curr_thread = get_thread(id);
  _thread_t *reactor = process_get_reactor(id);
  internal(2, " exiting ...");

	if(curr_thread == &main_thread)
		main_exit();

  curr_thread->retval = retval;
  curr_thread->state = ZOMBIE;

  list_del(&curr_thread->calendar);
  list_del(&curr_thread->ready_q);
	list_del(&curr_thread->all_threads);

  /* update family tree */
  list_del(&curr_thread->siblings);
  /* 
   * FIXME: move all childs to main thread 
   * 
   */

  processes[id].curr_thread = NULL;
  process_dec_threads(id);

  /* check for a joining thread */
  if (curr_thread->joining_thread)
  {
    _thread_t *jthr = curr_thread->joining_thread;
    switch_thread(curr_thread, jthr);
  }
  else
  {
    /* move thread to a finished queue */
    if (curr_thread != &main_thread)
      runq_append(&processes[id].zombie_q, curr_thread);

    switch_thread(curr_thread, reactor);
  }
}

/*
 *	public thread functions 
 *	not implemented/tested yet
 */
int tap_thread_join(_thread_t * thread, void **value)
{
  _thread_t *this = tap_thread_self();
  if (!thread)
  {
    errno = EINVAL;
    return -1;
  }

  if (thread->state == DESTROYED || thread->state == ZOMBIE)
  {
    errno = EINVAL;
    return -1;
  }

  if (thread->joining_thread)
  {
    errno = EINVAL;
    return -1;
  }

  if (thread == this)
  {
    errno = EDEADLK;
    return -1;
  }
  thread->joining_thread = this;

  block(-1);

  *value = thread->retval;
  thread_destroy(thread);

  return 0;
}

int tap_thread_cancel(_thread_t * thread)
{
  if (!thread)
  {
    errno = EINVAL;
    return -1;
  }

  thread->flags |= TAP_CANCELED;
  return 0;
}

void tap_thread_testcancel()
{
  _thread_t *this = tap_thread_self();

  if (this->flags & TAP_CANCELED)
  {
    internal(3, "exit b/c of canceled");
    tap_thread_exit(TAP_RETURN_CANCELED);
  }
}

