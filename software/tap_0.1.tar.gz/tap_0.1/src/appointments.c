/* $Id: appointments.c,v 1.1.2.8 2005/10/14 14:30:12 hroeck Exp $ */

/* 
 * Copyright (c) Harald Roeck hroeck@cs.uni-salzburg.at 
 *
 * University Salzburg, www.uni-salzburg.at
 * Department of Computer Science, cs.uni-salzburg.at
 */

/*  
 *  This program is free software; you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation; either version 2 of the License, or
 *  (at your option) any later version.
 *
 *  This program is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 *
 *  You should have received a copy of the GNU General Public License
 *  along with this program; if not, write to the Free Software
 *  Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 *
 */


#include "threads_private.h"
#include "process.h"
#include "debug.h"
#include "profile.h"


static int limits[MAX_CALENDARS] = {5, 5, 5, 5};


int tap_set_limit(int calendar, int limit)
{
	int oldval;

	if(calendar < 0 || calendar > MAX_CALENDARS)
		return -1;

	oldval = limits[calendar];
	limits[calendar] = limit;

	return oldval;
}

/*
 * make an appointment for a thread
 * input params: thread, app
 *
 * writes thread context and adds 
 * the thread to a calendar
 */
void tap_get_appointment(_thread_t *thread, appointment_t *app)
{
	int id = thread->cpu_id;
	plist_t *calendar = process_get_calendar(id, app->resource);

	internal(5, "new appoinment for thread [%d], res %d, type %d", thread->tid, app->resource, app->type);

	/* set appoinment in the thread context */
	memcpy(&thread->app, app, sizeof(*app));

	/* insert thread to the correct calendar */
	plist_append(calendar, thread);
}

/*
 * get the threads for the next appointment
 *
 * output params: *) ready: list of threads ready for the next app
 *                *) nready: threads not ready for next app
 * input params: *) id: process id
 */
int next_ready(tap_list_t *ready, tap_list_t *nready, int id)
{
	plist_t *calendar;
	_thread_t *thread;
	int i, count =0, cready =0, cnready=0;
	prof_avg_t r;
	int j;

	assert(list_empty(ready));
	assert(list_empty(nready));
	/* get a thread from every calendar */
	for(i=0;i<MAX_CALENDARS;++i)
	{
		calendar = process_get_calendar(id, i);
		thread = plist_next(calendar);
		
		j =1;
		while(thread)
		{
			thread->flags |= TAP_ON_NEXT_APP;
			thread->curr_func = __FUNCTION__;
			++count;
			if(thread->flags & TAP_READY)
			{
				internal(3, " thread [%d] from calendar %d is on ready app", thread->tid, i);
				
				list_add_tail(ready, &thread->ready_q);
				cready++;
			}
			else
			{
				internal(3, " thread [%d] from calendar %d is on next app", thread->tid, i);
				list_add_tail(nready, &thread->ready_q);
				cnready++;
			}

			if(++j > limits[i])
				break;
			thread = plist_next(calendar);
		}
	}

	r = prof_get(PROF_NEXTREADY);
	prof_add(r, count);
	
	internal(3, " got %d threads for next appoinment", count);
	
	/*
	if(!count)
		printf("no new threads in next_ready\n");
	
	if(!cready)
		printf("no new ready threads\n");
	
	if(!cnready)
		printf("no new not ready threads\n");
	*/
	return count;
}
